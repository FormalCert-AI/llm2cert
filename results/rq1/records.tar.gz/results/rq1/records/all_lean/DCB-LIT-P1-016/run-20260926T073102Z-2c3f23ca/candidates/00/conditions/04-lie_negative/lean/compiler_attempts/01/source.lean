import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: d90c9a14ce2cc865c33196a91ced7372a3ad361f1546973261d6b32a84bc7083
noncomputable def barrier_d90c9a14ce2c (x : LeanBarrier.State 6) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2))
@[simp] theorem barrier_unfold_d90c9a14ce2c (x : LeanBarrier.State 6) : barrier_d90c9a14ce2c x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2)) := by
  rfl
def violationSet_lie_negative_d90c9a14ce2c : Set (LeanBarrier.State 6) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (x 3 ≥ (-1 : ℝ)) ∧ (x 3 ≤ (1 : ℝ)) ∧ (x 4 ≥ (-1 : ℝ)) ∧ (x 4 ≤ (1 : ℝ)) ∧ (x 5 ≥ (-1 : ℝ)) ∧ (x 5 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * (((-x 0) + (((1 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 4 ^ 2)))) + ((2 : ℝ) * x 1 * ((((-1 : ℝ) / (2 : ℝ)) * x 0) - x 1)) + ((2 : ℝ) * x 2 * (((-x 2) + (((1 : ℝ) / (2 : ℝ)) * x 3)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)))) + ((2 : ℝ) * x 3 * ((((-1 : ℝ) / (2 : ℝ)) * x 2) - x 3)) + ((2 : ℝ) * x 4 * ((-x 4) + (((1 : ℝ) / (2 : ℝ)) * x 5))) + ((2 : ℝ) * x 5 * (((((-1 : ℝ) / (2 : ℝ)) * x 4) - x 5) + (((1 : ℝ) / (10 : ℝ)) * (x 1 ^ 2))))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_d90c9a14ce2c (hV : ContDiff ℝ 1 barrier_d90c9a14ce2c) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_lie_negative_d90c9a14ce2c := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_lie_negative_d90c9a14ce2c] at hx
  rcases hx with ⟨h0l, h0u, h1l, h1u, h2l, h2u, h3l, h3u,
    h4l, h4u, h5l, h5u, hpos, hder⟩
  have hR0 : 0 ≤ (1 + x 2) * (x 0) ^ 2 := by
    exact mul_nonneg (by linarith) (sq_nonneg (x 0))
  have hR1 : 0 ≤ (1 - x 5) * (x 1) ^ 2 := by
    exact mul_nonneg (by linarith) (sq_nonneg (x 1))
  have hR4 : 0 ≤ (1 + x 0) * (x 4) ^ 2 := by
    exact mul_nonneg (by linarith) (sq_nonneg (x 4))
  have hR :
      0 ≤ (1 + x 2) * (x 0) ^ 2 +
          (1 - x 5) * (x 1) ^ 2 +
          (1 + x 0) * (x 4) ^ 2 := by
    nlinarith [hR0, hR1, hR4]
  have hB : 0 ≤ (x 2) ^ 2 + (x 3) ^ 2 + (x 5) ^ 2 := by
    positivity
  nlinarith [hR, hB]

#print axioms verify_lie_negative_d90c9a14ce2c

end LeanBarrier.Generated
