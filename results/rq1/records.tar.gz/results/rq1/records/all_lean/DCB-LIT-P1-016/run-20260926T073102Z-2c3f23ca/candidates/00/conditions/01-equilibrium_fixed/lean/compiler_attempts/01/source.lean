import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: d90c9a14ce2cc865c33196a91ced7372a3ad361f1546973261d6b32a84bc7083
noncomputable def barrier_d90c9a14ce2c (x : LeanBarrier.State 6) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2))
@[simp] theorem barrier_unfold_d90c9a14ce2c (x : LeanBarrier.State 6) : barrier_d90c9a14ce2c x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_d90c9a14ce2c : Set (LeanBarrier.State 6) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (x 3 = (0 : ℝ)) ∧ (x 4 = (0 : ℝ)) ∧ (x 5 = (0 : ℝ)) ∧ ((((((-x 0) + (((1 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 4 ^ 2))) > (0 : ℝ))) ∨ (((((-x 0) + (((1 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 4 ^ 2))) < (0 : ℝ))) ∨ ((((((-1 : ℝ) / (2 : ℝ)) * x 0) - x 1) > (0 : ℝ))) ∨ ((((((-1 : ℝ) / (2 : ℝ)) * x 0) - x 1) < (0 : ℝ))) ∨ (((((-x 2) + (((1 : ℝ) / (2 : ℝ)) * x 3)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 2))) > (0 : ℝ))) ∨ (((((-x 2) + (((1 : ℝ) / (2 : ℝ)) * x 3)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 2))) < (0 : ℝ))) ∨ ((((((-1 : ℝ) / (2 : ℝ)) * x 2) - x 3) > (0 : ℝ))) ∨ ((((((-1 : ℝ) / (2 : ℝ)) * x 2) - x 3) < (0 : ℝ))) ∨ ((((-x 4) + (((1 : ℝ) / (2 : ℝ)) * x 5)) > (0 : ℝ))) ∨ ((((-x 4) + (((1 : ℝ) / (2 : ℝ)) * x 5)) < (0 : ℝ))) ∨ (((((((-1 : ℝ) / (2 : ℝ)) * x 4) - x 5) + (((1 : ℝ) / (10 : ℝ)) * (x 1 ^ 2))) > (0 : ℝ))) ∨ (((((((-1 : ℝ) / (2 : ℝ)) * x 4) - x 5) + (((1 : ℝ) / (10 : ℝ)) * (x 1 ^ 2))) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_d90c9a14ce2c (hV : ContDiff ℝ 1 barrier_d90c9a14ce2c) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_equilibrium_fixed_d90c9a14ce2c := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, hbad⟩
  simp [h0, h1, h2, h3, h4, h5] at hbad

#print axioms verify_equilibrium_fixed_d90c9a14ce2c

end LeanBarrier.Generated
