import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: b1d547ef52b053d194a64f3313cccb630599a482ae8d4e9b1b9d03b8c3ecced3
noncomputable def barrier_b1d547ef52b0 (x : LeanBarrier.State 8) : ℝ := ((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ))
@[simp] theorem barrier_unfold_b1d547ef52b0 (x : LeanBarrier.State 8) : barrier_b1d547ef52b0 x = ((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ)) := by
  rfl
def violationSet_initial_containment_b1d547ef52b0 : Set (LeanBarrier.State 8) := {x | ((x 0 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 4 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 4 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 5 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 5 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 6 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 6 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 7 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 7 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ)) < (0 : ℝ)))}
def unsafeSet_b1d547ef52b0 : Set (LeanBarrier.State 8) := {x | ((x 0 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((-9 : ℝ) / (5 : ℝ))))}
def initialSet_b1d547ef52b0 : Set (LeanBarrier.State 8) := {x | ((x 0 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 4 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 4 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 5 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 5 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 6 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 6 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 7 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 7 ≤ ((11 : ℝ) / (10 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_initial_containment_b1d547ef52b0 (hV : ContDiff ℝ 1 barrier_b1d547ef52b0) : ¬ ∃ x : LeanBarrier.State 8, x ∈ violationSet_initial_containment_b1d547ef52b0 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_initial_containment_b1d547ef52b0, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0wlo, hx0whi, hx1wlo, hx1whi, hx2wlo, hx2whi,
    hx3wlo, hx3whi, hx4wlo, hx4whi, hx5wlo, hx5whi, hx6wlo, hx6whi,
    hx7wlo, hx7whi, hx0lo, hx0hi, hx1lo, hx1hi, hx2lo, hx2hi,
    hx3lo, hx3hi, hx4lo, hx4hi, hx5lo, hx5hi, hx6lo, hx6hi,
    hx7lo, hx7hi, hneg⟩
  linarith [hx0lo, hx1lo, hx2lo, hx3lo, hx4lo, hx5lo, hx6lo, hx7lo]

#print axioms verify_initial_containment_b1d547ef52b0

end LeanBarrier.Generated
