import LeanBarrier

#check Real.sin
#check Real.neg_one_le_sin
