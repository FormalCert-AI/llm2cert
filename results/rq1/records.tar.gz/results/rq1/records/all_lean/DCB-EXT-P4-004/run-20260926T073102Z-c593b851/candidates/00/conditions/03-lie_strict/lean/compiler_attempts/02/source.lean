import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: b1d547ef52b053d194a64f3313cccb630599a482ae8d4e9b1b9d03b8c3ecced3
noncomputable def barrier_b1d547ef52b0 (x : LeanBarrier.State 8) : ℝ := ((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ))
@[simp] theorem barrier_unfold_b1d547ef52b0 (x : LeanBarrier.State 8) : barrier_b1d547ef52b0 x = ((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ)) := by
  rfl
def violationSet_lie_strict_b1d547ef52b0 (x : LeanBarrier.State 8) (omega : ℝ) : Prop := ((omega ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (omega ≤ (2 : ℝ)) ∧ (x 0 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((11 : ℝ) / (5 : ℝ))) ∧ (((((60 : ℝ) * x 0) + ((257 : ℝ) * x 1) + ((463 : ℝ) * x 2) + ((464 : ℝ) * x 3) + ((286 : ℝ) * x 4) + ((113 : ℝ) * x 5) + ((30 : ℝ) * x 6) + x 7) - (100 : ℝ)) = (0 : ℝ)) ∧ ((((60 : ℝ) * x 1) + ((257 : ℝ) * x 2) + ((463 : ℝ) * x 3) + ((464 : ℝ) * x 4) + ((286 : ℝ) * x 5) + ((113 : ℝ) * x 6) + ((30 : ℝ) * x 7) + ((-20 : ℝ) * x 7) + ((170 : ℝ) * x 6) + ((800 : ℝ) * x 5) + ((2273 : ℝ) * x 4) + ((3980 : ℝ) * x 3) + ((4180 : ℝ) * x 2) + ((2400 : ℝ) * x 1) + ((576 : ℝ) * x 0) + Real.sin ((omega * x 0))) ≤ (0 : ℝ)))
def unsafeSet_b1d547ef52b0 : Set (LeanBarrier.State 8) := {x | ((x 0 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((-9 : ℝ) / (5 : ℝ))))}
def initialSet_b1d547ef52b0 : Set (LeanBarrier.State 8) := {x | ((x 0 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 4 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 4 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 5 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 5 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 6 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 6 ≤ ((11 : ℝ) / (10 : ℝ))) ∧ (x 7 ≥ ((9 : ℝ) / (10 : ℝ))) ∧ (x 7 ≤ ((11 : ℝ) / (10 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_b1d547ef52b0 (hV : ContDiff ℝ 1 barrier_b1d547ef52b0) : ¬ ∃ x : LeanBarrier.State 8, ∃ omega : ℝ, violationSet_lie_strict_b1d547ef52b0 x omega := by
  rintro ⟨x, omega, h⟩
  unfold violationSet_lie_strict_b1d547ef52b0 at h
  rcases h with ⟨hωlo, hωhi,
    hx0lo, hx0hi, hx1lo, hx1hi, hx2lo, hx2hi, hx3lo, hx3hi,
    hx4lo, hx4hi, hx5lo, hx5hi, hx6lo, hx6hi, hx7lo, hx7hi,
    hB, hLf⟩
  have hs : -(1 : ℝ) ≤ Real.sin (omega * x 0) :=
    Real.neg_one_le_sin _
  linarith only [hB, hLf, hx0lo, hx1lo, hx2lo, hx3lo, hx4lo,
    hx5lo, hx6hi, hx7lo, hs]

#print axioms verify_lie_strict_b1d547ef52b0

end LeanBarrier.Generated
