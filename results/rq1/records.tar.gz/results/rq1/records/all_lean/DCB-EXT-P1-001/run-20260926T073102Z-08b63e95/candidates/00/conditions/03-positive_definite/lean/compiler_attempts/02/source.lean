import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_96dae1d24041 : Set (LeanBarrier.State 2) := {x | ((((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_96dae1d24041 := by
  rintro ⟨x, hx⟩
  change
    ((x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ)) ∧
      (x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) + x 1 ^ 2 ≤ (0 : ℝ))) at hx
  rcases hx with ⟨hpos, hnonpos⟩
  have hexp : 0 < Real.exp ((2 : ℝ) * x 1) := Real.exp_pos _
  have hprod : 0 ≤ x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) :=
    mul_nonneg (sq_nonneg (x 0)) (le_of_lt hexp)
  have hx1sq : x 1 ^ 2 = 0 := by
    nlinarith [sq_nonneg (x 1)]
  have hprod0 : x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) = 0 := by
    nlinarith [sq_nonneg (x 1)]
  have hx0sq : x 0 ^ 2 = 0 :=
    (mul_eq_zero.mp hprod0).resolve_right (ne_of_gt hexp)
  nlinarith

#print axioms verify_positive_definite_96dae1d24041

end LeanBarrier.Generated
