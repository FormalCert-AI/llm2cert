import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_96dae1d24041 : Set (LeanBarrier.State 2) := {x | ((((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * Real.exp (((2 : ℝ) * x 1)) * ((-x 0) + (x 0 * x 1))) + ((((2 : ℝ) * (x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + ((2 : ℝ) * x 1)) * (-x 1))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_96dae1d24041 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hpos, hder⟩
  have hexp : 0 < Real.exp ((2 : ℝ) * x 1) := Real.exp_pos _
  have hrewrite :
      ((2 : ℝ) * x 0 * Real.exp ((2 : ℝ) * x 1) *
          (-x 0 + x 0 * x 1) +
        (((2 : ℝ) * (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) +
            (2 : ℝ) * x 1) * (-x 1))) =
        -(2 : ℝ) * ((x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1)) -
          2 * (x 1 ^ 2) := by
    ring
  rw [hrewrite] at hder
  have hprod_nonneg :
      0 ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
    mul_nonneg (sq_nonneg _) (le_of_lt hexp)
  have hsquare_nonneg : 0 ≤ x 1 ^ 2 := sq_nonneg _
  have hprod : (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) = 0 := by
    nlinarith
  have hx1 : x 1 ^ 2 = 0 := by
    nlinarith
  have hx0 : x 0 ^ 2 = 0 :=
    (mul_eq_zero.mp hprod).resolve_right (ne_of_gt hexp)
  nlinarith

#print axioms verify_lie_negative_96dae1d24041

end LeanBarrier.Generated
