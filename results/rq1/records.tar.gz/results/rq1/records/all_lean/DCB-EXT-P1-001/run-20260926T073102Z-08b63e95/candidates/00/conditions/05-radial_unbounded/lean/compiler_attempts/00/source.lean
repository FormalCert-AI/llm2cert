import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl

#print axioms barrier_unfold_96dae1d24041

end LeanBarrier.Generated
