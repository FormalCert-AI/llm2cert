import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl

theorem barrier_sublevel_bound_96dae1d24041 (C : ℝ) (x : LeanBarrier.State 2)
    (h : barrier_96dae1d24041 x ≤ C) :
    (∑ i, (x i) ^ 2) ≤ C + C * Real.exp ((2 : ℝ) * (|C| + 1)) := by
  rw [barrier_unfold_96dae1d24041] at h
  let t : ℝ := |C| + 1
  have ht : 0 < t := by
    dsimp [t]
    nlinarith [abs_nonneg C]
  have hterm : 0 ≤ (x 0) ^ 2 * Real.exp ((2 : ℝ) * x 1) :=
    mul_nonneg (sq_nonneg (x 0)) (le_of_lt (Real.exp_pos _))
  have hb2 : (x 1) ^ 2 ≤ C := by
    nlinarith
  have hb : -t ≤ x 1 := by
    by_contra hnt
    have hlt : x 1 < -t := lt_of_not_ge hnt
    have hneg : 0 ≤ -(x 1 + t) := by
      linarith
    have hmul : 0 ≤ (-(x 1 + t)) * t :=
      mul_nonneg hneg (le_of_lt ht)
    have hsq : t ^ 2 ≤ (x 1) ^ 2 := by
      nlinarith [sq_nonneg (x 1 + t), hmul]
    have htC : C < t ^ 2 := by
      dsimp [t]
      nlinarith [abs_nonneg C, le_abs_self C, sq_nonneg (|C|)]
    nlinarith
  have hlin : 0 ≤ (2 : ℝ) * x 1 + 2 * t := by
    nlinarith
  have hexpge :
      1 ≤ Real.exp ((2 : ℝ) * x 1) * Real.exp ((2 : ℝ) * t) := by
    calc
      1 = Real.exp 0 := by rw [Real.exp_zero]
      _ ≤ Real.exp ((2 : ℝ) * x 1 + 2 * t) := Real.exp_le_exp.mpr hlin
      _ = Real.exp ((2 : ℝ) * x 1) * Real.exp ((2 : ℝ) * t) := by
        rw [Real.exp_add]
  have hxp :
      (x 0) ^ 2 ≤
        ((x 0) ^ 2 * Real.exp ((2 : ℝ) * x 1)) * Real.exp ((2 : ℝ) * t) := by
    have hm := mul_le_mul_of_nonneg_left hexpge (sq_nonneg (x 0))
    simpa [mul_assoc] using hm
  have hprod : (x 0) ^ 2 * Real.exp ((2 : ℝ) * x 1) ≤ C := by
    nlinarith [sq_nonneg (x 1)]
  have hscaled :
      ((x 0) ^ 2 * Real.exp ((2 : ℝ) * x 1)) * Real.exp ((2 : ℝ) * t) ≤
        C * Real.exp ((2 : ℝ) * t) :=
    mul_le_mul_of_nonneg_right hprod (le_of_lt (Real.exp_pos _))
  have hx02 : (x 0) ^ 2 ≤ C * Real.exp ((2 : ℝ) * t) :=
    le_trans hxp hscaled
  rw [Fin.sum_univ_two]
  dsimp [t] at hx02
  nlinarith

set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_96dae1d24041 := by
  unfold LeanBarrier.Lyapunov.RadiallyUnbounded
  rintro ⟨x, hC⟩
  obtain ⟨i, hi⟩ := hC (1 : ℚ) (by norm_num)
  let c : ℝ := (x i : ℝ) + 1
  let D : ℝ := c + c * Real.exp ((2 : ℝ) * (|c| + 1))
  obtain ⟨n, hn⟩ := exists_nat_gt |D|
  let j : ℕ := max i n
  have hij : i ≤ j := le_max_left i n
  have hnj : n ≤ j := le_max_right i n
  have hclose := hi j hij
  obtain ⟨y, hy1, hy2⟩ := (x j).property
  have hxsub : barrier_96dae1d24041 y ≤ c := by
    dsimp [c]
    norm_num at hclose
    nlinarith [hy2, le_abs_self ((x j : ℝ) - (x i : ℝ))]
  have hb := barrier_sublevel_bound_96dae1d24041 c y hxsub
  have hbD : (∑ k, (y k) ^ 2) ≤ D := by
    simpa [D] using hb
  have hnjR : (n : ℝ) ≤ (j : ℝ) := by
    exact_mod_cast hnj
  have hjD : D < (j : ℝ) := by
    nlinarith [le_abs_self D]
  nlinarith [hy1]

#print axioms verify_radial_unbounded_96dae1d24041

end LeanBarrier.Generated
