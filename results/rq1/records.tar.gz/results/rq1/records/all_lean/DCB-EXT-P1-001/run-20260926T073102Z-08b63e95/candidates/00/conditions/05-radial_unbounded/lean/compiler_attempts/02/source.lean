import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl



set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_96dae1d24041 := by
  unfold LeanBarrier.Lyapunov.RadiallyUnbounded
  rintro ⟨C, hC⟩
  obtain ⟨x, hxrad, hxV⟩ := hC (C * Real.exp (2 * (C + 1)) + C + 1)
  rw [barrier_unfold_96dae1d24041] at hxV
  have hs0 : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have hs1 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  have hepos : 0 < Real.exp (2 * x 1) := Real.exp_pos _
  have hprodC : x 0 ^ 2 * Real.exp (2 * x 1) ≤ C := by
    nlinarith
  have hx1sq : x 1 ^ 2 ≤ C := by
    nlinarith [mul_nonneg hs0 (le_of_lt hepos)]
  have hC0 : 0 ≤ C := by
    nlinarith
  have hx1lower : -(C + 1) ≤ x 1 := by
    by_contra hn
    have hlt : x 1 < -(C + 1) := lt_of_not_ge hn
    have hp : 0 < (-x 1 - (C + 1)) * (-x 1 + (C + 1)) := by
      apply mul_pos
      · linarith
      · linarith
    nlinarith
  have hexple : Real.exp (-2 * (C + 1)) ≤ Real.exp (2 * x 1) := by
    apply Real.exp_le_exp.mpr
    linarith
  have hlowC : x 0 ^ 2 * Real.exp (-2 * (C + 1)) ≤ C := by
    exact le_trans (mul_le_mul_of_nonneg_left hexple hs0) hprodC
  have hexpid :
      Real.exp (-2 * (C + 1)) * Real.exp (2 * (C + 1)) = 1 := by
    rw [← Real.exp_add]
    convert Real.exp_zero using 1 <;> ring
  have hscaled :
      (x 0 ^ 2 * Real.exp (-2 * (C + 1))) * Real.exp (2 * (C + 1)) ≤
        C * Real.exp (2 * (C + 1)) := by
    exact mul_le_mul_of_nonneg_right hlowC (le_of_lt (Real.exp_pos _))
  have hx0sq : x 0 ^ 2 ≤ C * Real.exp (2 * (C + 1)) := by
    calc
      x 0 ^ 2 = (x 0 ^ 2 * Real.exp (-2 * (C + 1))) * Real.exp (2 * (C + 1)) := by
        rw [mul_assoc, hexpid, mul_one]
      _ ≤ C * Real.exp (2 * (C + 1)) := hscaled
  have hxrad' :
      C * Real.exp (2 * (C + 1)) + C + 1 ≤ x 0 ^ 2 + x 1 ^ 2 := by
    simpa [Fin.sum_univ_two] using hxrad
  nlinarith

#print axioms verify_radial_unbounded_96dae1d24041

end LeanBarrier.Generated
