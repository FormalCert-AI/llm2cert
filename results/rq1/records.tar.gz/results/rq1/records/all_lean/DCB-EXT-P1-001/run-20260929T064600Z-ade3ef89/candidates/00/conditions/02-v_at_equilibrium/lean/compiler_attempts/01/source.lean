import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 96dae1d240415c13bf52041820c69689704f671bd8bb64390ce9736965e519a9
noncomputable def barrier_96dae1d24041 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_96dae1d24041 (x : LeanBarrier.State 2) : barrier_96dae1d24041 x = (((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_96dae1d24041 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ ((((((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) > (0 : ℝ))) ∨ (((((x 0 ^ 2) * Real.exp (((2 : ℝ) * x 1))) + (x 1 ^ 2)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_96dae1d24041 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_96dae1d24041] at hx
  rcases hx with ⟨hx0, hx1, hbad⟩
  simp [hx0, hx1] at hbad

#print axioms verify_v_at_equilibrium_96dae1d24041

end LeanBarrier.Generated
