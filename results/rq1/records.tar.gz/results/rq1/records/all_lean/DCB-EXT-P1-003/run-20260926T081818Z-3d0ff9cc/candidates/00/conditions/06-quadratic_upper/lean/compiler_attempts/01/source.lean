import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 764d2fbfe83243d270c42627dda2c57fc1664370ca89848d37569537faf8a8bf
noncomputable def barrier_764d2fbfe832 (x : LeanBarrier.State 2) : ℝ := (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_764d2fbfe832 (x : LeanBarrier.State 2) : barrier_764d2fbfe832 x = (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_quadratic_upper_764d2fbfe832 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ ((((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) > ((5 : ℝ) * ((x 0 ^ 2) + (x 1 ^ 2)))))}



set_option maxHeartbeats 1000000 in
theorem verify_quadratic_upper_764d2fbfe832 (hV : ContDiff ℝ 1 barrier_764d2fbfe832) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_quadratic_upper_764d2fbfe832 := by
  rintro ⟨x, hx⟩
  change
    (x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧
      (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧
      (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧
      ((((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) >
        ((5 : ℝ) * ((x 0 ^ 2) + (x 1 ^ 2)))) at hx
  rcases hx with ⟨_, _, _, _, _, hbad⟩
  have hs : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  nlinarith

#print axioms verify_quadratic_upper_764d2fbfe832

end LeanBarrier.Generated
