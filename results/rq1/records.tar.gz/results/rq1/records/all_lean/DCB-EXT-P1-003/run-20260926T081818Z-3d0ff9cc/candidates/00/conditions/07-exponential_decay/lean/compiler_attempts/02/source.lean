import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 764d2fbfe83243d270c42627dda2c57fc1664370ca89848d37569537faf8a8bf
noncomputable def barrier_764d2fbfe832 (x : LeanBarrier.State 2) : ℝ := (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_764d2fbfe832 (x : LeanBarrier.State 2) : barrier_764d2fbfe832 x = (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_exponential_decay_764d2fbfe832 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ ((((10 : ℝ) * x 0 * (x 1 + ((-x 1) - ((4 : ℝ) * x 0)))) + ((2 : ℝ) * x 1 * (((-5 : ℝ) * x 1) + (((80 : ℝ) / (3 : ℝ)) * ((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (10 : ℝ)) * x 1))))) + ((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) > (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_exponential_decay_764d2fbfe832 (hV : ContDiff ℝ 1 barrier_764d2fbfe832) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_exponential_decay_764d2fbfe832 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_exponential_decay_764d2fbfe832, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hball, hpos⟩
  have hsin : |Real.sin (x 0)| ≤ |x 0| :=
    Real.abs_sin_le_abs (x 0)
  have hab : x 1 * Real.sin (x 0) ≤ |x 0 * x 1| := by
    calc
      x 1 * Real.sin (x 0) ≤ |x 1 * Real.sin (x 0)| := le_abs_self _
      _ = |x 1| * |Real.sin (x 0)| := by rw [abs_mul]
      _ ≤ |x 1| * |x 0| :=
        mul_le_mul_of_nonneg_left hsin (abs_nonneg (x 1))
      _ = |x 0 * x 1| := by
        rw [abs_mul]
        ac_rfl
  have hscaled :
      ((981 : ℝ) / 25) * (x 1 * Real.sin (x 0)) ≤
        ((981 : ℝ) / 25) * |x 0 * x 1| := by
    exact mul_le_mul_of_nonneg_left hab (by norm_num)
  have habound :
      ((981 : ℝ) / 25) * |x 0 * x 1| ≤
        30 * (x 0) ^ 2 + 13 * (x 1) ^ 2 := by
    by_cases hp : 0 ≤ x 0 * x 1
    · rw [abs_of_nonneg hp]
      have hs :
          0 ≤ (30 : ℝ) * (x 0 - ((327 : ℝ) / 500) * x 1) ^ 2 +
            ((4213 : ℝ) / 25000) * (x 1) ^ 2 := by
        positivity
      nlinarith [hs]
    · have hp' : x 0 * x 1 ≤ 0 := le_of_not_ge hp
      rw [abs_of_nonpos hp']
      have hs :
          0 ≤ (30 : ℝ) * (x 0 + ((327 : ℝ) / 500) * x 1) ^ 2 +
            ((4213 : ℝ) / 25000) * (x 1) ^ 2 := by
        positivity
      nlinarith [hs]
  have hprod :
      ((981 : ℝ) / 25) * (x 1 * Real.sin (x 0)) ≤
        30 * (x 0) ^ 2 + 13 * (x 1) ^ 2 :=
    hscaled.trans habound
  ring_nf at hpos
  nlinarith [hprod, sq_nonneg (x 0), sq_nonneg (x 1)]

#print axioms verify_exponential_decay_764d2fbfe832

end LeanBarrier.Generated
