import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 764d2fbfe83243d270c42627dda2c57fc1664370ca89848d37569537faf8a8bf
noncomputable def barrier_764d2fbfe832 (x : LeanBarrier.State 2) : ℝ := (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_764d2fbfe832 (x : LeanBarrier.State 2) : barrier_764d2fbfe832 x = (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_764d2fbfe832 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ ((((x 1 + ((-x 1) - ((4 : ℝ) * x 0))) > (0 : ℝ))) ∨ (((x 1 + ((-x 1) - ((4 : ℝ) * x 0))) < (0 : ℝ))) ∨ (((((-5 : ℝ) * x 1) + (((80 : ℝ) / (3 : ℝ)) * ((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (10 : ℝ)) * x 1)))) > (0 : ℝ))) ∨ (((((-5 : ℝ) * x 1) + (((80 : ℝ) / (3 : ℝ)) * ((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (10 : ℝ)) * x 1)))) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_764d2fbfe832 (hV : ContDiff ℝ 1 barrier_764d2fbfe832) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_764d2fbfe832 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  norm_num [hx0, hx1] at hbad

#print axioms verify_equilibrium_fixed_764d2fbfe832

end LeanBarrier.Generated
