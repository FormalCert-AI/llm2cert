import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 764d2fbfe83243d270c42627dda2c57fc1664370ca89848d37569537faf8a8bf
noncomputable def barrier_764d2fbfe832 (x : LeanBarrier.State 2) : ℝ := (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_764d2fbfe832 (x : LeanBarrier.State 2) : barrier_764d2fbfe832 x = (((5 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_control_admissible_764d2fbfe832 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((((-x 1) - ((4 : ℝ) * x 0)) < (-5 : ℝ))) ∨ ((((-x 1) - ((4 : ℝ) * x 0)) > (5 : ℝ))) ∨ ((((-5 : ℝ) * x 1) < (-5 : ℝ))) ∨ ((((-5 : ℝ) * x 1) > (5 : ℝ)))))}

#print axioms barrier_unfold_764d2fbfe832

end LeanBarrier.Generated
