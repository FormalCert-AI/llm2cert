import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c6ceabff07cb68829a659fcaebaad331b79225adcc64a997288648b27bb37f6a
noncomputable def barrier_c6ceabff07cb (x : LeanBarrier.State 6) : ℝ := (((2 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2) + ((2 : ℝ) * (x 2 ^ 2)) + (x 3 ^ 2) + ((5 : ℝ) * (x 4 ^ 2)) + (x 5 ^ 2) + (((1 : ℝ) / (100 : ℝ)) * ((x 0 * x 1) + (x 2 * x 3) + (x 4 * x 5))))
@[simp] theorem barrier_unfold_c6ceabff07cb (x : LeanBarrier.State 6) : barrier_c6ceabff07cb x = (((2 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2) + ((2 : ℝ) * (x 2 ^ 2)) + (x 3 ^ 2) + ((5 : ℝ) * (x 4 ^ 2)) + (x 5 ^ 2) + (((1 : ℝ) / (100 : ℝ)) * ((x 0 * x 1) + (x 2 * x 3) + (x 4 * x 5)))) := by
  rfl
def violationSet_lie_negative_c6ceabff07cb : Set (LeanBarrier.State 6) := {x | ((x 0 ≥ (-3 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ (-3 : ℝ)) ∧ (x 2 ≤ (3 : ℝ)) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (3 : ℝ)) ∧ (x 4 ≥ (-3 : ℝ)) ∧ (x 4 ≤ (3 : ℝ)) ∧ (x 5 ≥ (-3 : ℝ)) ∧ (x 5 ≤ (3 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2)) > (0 : ℝ)) ∧ ((((((4 : ℝ) * x 0) + (((1 : ℝ) / (100 : ℝ)) * x 1)) * x 1) + ((((2 : ℝ) * x 1) + (((1 : ℝ) / (100 : ℝ)) * x 0)) * ((((((-3 : ℝ) / (2 : ℝ)) * x 5 * x 3) - ((2 : ℝ) * x 0)) - (((5 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (2 : ℝ)) * x 3 * Real.sin (x 1) * Real.cos (x 3)))) + ((((4 : ℝ) * x 2) + (((1 : ℝ) / (100 : ℝ)) * x 3)) * x 3) + ((((2 : ℝ) * x 3) + (((1 : ℝ) / (100 : ℝ)) * x 2)) * ((((((3 : ℝ) / (2 : ℝ)) * x 5 * x 1) - ((2 : ℝ) * x 2)) - ((10 : ℝ) * x 3)) + (((1 : ℝ) / (2 : ℝ)) * x 1 * Real.sin (x 1) * Real.cos (x 3)))) + ((((10 : ℝ) * x 4) + (((1 : ℝ) / (100 : ℝ)) * x 5)) * x 5) + ((((2 : ℝ) * x 5) + (((1 : ℝ) / (100 : ℝ)) * x 4)) * (((-5 : ℝ) * x 4) - (((4 : ℝ) / (5 : ℝ)) * x 5)))) ≥ (0 : ℝ)))}

theorem lie_negative_a_sq_c6ceabff07cb
    (z t q : ℝ) (hzl : (-3 : ℝ) ≤ z) (hzu : z ≤ (3 : ℝ)) :
    ((((3 : ℝ) / 2) * z +
      ((1 : ℝ) / 2) * Real.sin t * Real.cos q) ^ 2) ≤ (25 : ℝ) := by
  have hsL : (-1 : ℝ) ≤ Real.sin t := Real.neg_one_le_sin t
  have hsU : Real.sin t ≤ (1 : ℝ) := Real.sin_le_one t
  have hcL : (-1 : ℝ) ≤ Real.cos q := Real.neg_one_le_cos q
  have hcU : Real.cos q ≤ (1 : ℝ) := Real.cos_le_one q
  have hsprod : 0 ≤ (Real.sin t + 1) * (1 - Real.sin t) := by
    apply mul_nonneg <;> linarith
  have hcprod : 0 ≤ (Real.cos q + 1) * (1 - Real.cos q) := by
    apply mul_nonneg <;> linarith
  have hs_sq : (Real.sin t) ^ 2 ≤ (1 : ℝ) := by
    nlinarith [hsprod]
  have hc_sq : (Real.cos q) ^ 2 ≤ (1 : ℝ) := by
    nlinarith [hcprod]
  have hsc_sq : (Real.sin t * Real.cos q) ^ 2 ≤ (1 : ℝ) := by
    calc
      (Real.sin t * Real.cos q) ^ 2 =
          (Real.sin t) ^ 2 * (Real.cos q) ^ 2 := by ring
      _ ≤ 1 * (Real.cos q) ^ 2 :=
        mul_le_mul_of_nonneg_right hs_sq (sq_nonneg (Real.cos q))
      _ ≤ 1 * 1 := mul_le_mul_of_nonneg_left hc_sq (by norm_num)
      _ = 1 := by norm_num
  have hscL : (-1 : ℝ) ≤ Real.sin t * Real.cos q := by
    nlinarith [hsc_sq, sq_nonneg (Real.sin t * Real.cos q + 1)]
  have hscU : Real.sin t * Real.cos q ≤ (1 : ℝ) := by
    nlinarith [hsc_sq, sq_nonneg (Real.sin t * Real.cos q - 1)]
  have haL : (-5 : ℝ) ≤
      ((3 : ℝ) / 2) * z + ((1 : ℝ) / 2) * Real.sin t * Real.cos q := by
    nlinarith
  have haU :
      ((3 : ℝ) / 2) * z + ((1 : ℝ) / 2) * Real.sin t * Real.cos q ≤
        (5 : ℝ) := by
    nlinarith
  have hp : 0 ≤
      ((3 : ℝ) / 2) * z + ((1 : ℝ) / 2) * Real.sin t * Real.cos q + 5 := by
    linarith
  have hm : 0 ≤ 5 -
      (((3 : ℝ) / 2) * z + ((1 : ℝ) / 2) * Real.sin t * Real.cos q) := by
    linarith
  nlinarith [mul_nonneg hp hm]

theorem lie_negative_group_nonneg_c6ceabff07cb
    (x0 x1 x2 x3 x4 x5 s c : ℝ)
    (h :
      ((((4 : ℝ) * x0 + ((1 : ℝ) / 100) * x1) * x1) +
       (((2 : ℝ) * x1 + ((1 : ℝ) / 100) * x0) *
        (((((-3 : ℝ) / 2) * x5 * x3 - 2 * x0) - ((5 : ℝ) / 2) * x1) -
          ((1 : ℝ) / 2) * x3 * s * c)) +
       (((4 : ℝ) * x2 + ((1 : ℝ) / 100) * x3) * x3) +
       (((2 : ℝ) * x3 + ((1 : ℝ) / 100) * x2) *
        (((((3 : ℝ) / 2) * x5 * x1 - 2 * x2) - 10 * x3) +
          ((1 : ℝ) / 2) * x1 * s * c)) +
       (((10 : ℝ) * x4 + ((1 : ℝ) / 100) * x5) * x5) +
       (((2 : ℝ) * x5 + ((1 : ℝ) / 100) * x4) *
        ((-5 : ℝ) * x4 - ((4 : ℝ) / 5) * x5)) ≥ 0) :
    -(5 : ℝ) * x1 ^ 2 - 20 * x3 ^ 2 - ((8 : ℝ) / 5) * x5 ^ 2 +
      ((1 : ℝ) / 100) *
        (x1 ^ 2 + x3 ^ 2 + x5 ^ 2 - 2 * x0 ^ 2 - 2 * x2 ^ 2 -
          5 * x4 ^ 2 - ((5 : ℝ) / 2) * (x0 * x1) -
          10 * (x2 * x3) - ((4 : ℝ) / 5) * (x4 * x5) +
          (((3 : ℝ) / 2) * x5 + ((1 : ℝ) / 2) * s * c) *
            (x2 * x1 - x0 * x3)) ≥ 0 := by
  convert h using 1 <;> ring

theorem lie_negative_upper_c6ceabff07cb
    (x0 x1 x2 x3 x4 x5 a : ℝ) (ha : a ^ 2 ≤ (25 : ℝ)) :
    -(5 : ℝ) * x1 ^ 2 - 20 * x3 ^ 2 - ((8 : ℝ) / 5) * x5 ^ 2 +
      ((1 : ℝ) / 100) *
        (x1 ^ 2 + x3 ^ 2 + x5 ^ 2 - 2 * x0 ^ 2 - 2 * x2 ^ 2 -
          5 * x4 ^ 2 - ((5 : ℝ) / 2) * (x0 * x1) -
          10 * (x2 * x3) - ((4 : ℝ) / 5) * (x4 * x5) +
          a * (x2 * x1 - x0 * x3)) ≤
      -((1 : ℝ) / 100) * x0 ^ 2 - ((3867 : ℝ) / 800) * x1 ^ 2 -
      ((1 : ℝ) / 100) * x2 ^ 2 - ((3873 : ℝ) / 200) * x3 ^ 2 -
      ((9 : ℝ) / 200) * x4 ^ 2 - ((3967 : ℝ) / 2500) * x5 ^ 2 := by
  have h01 :
      -((5 : ℝ) / 2) * (x0 * x1) ≤
        ((1 : ℝ) / 2) * x0 ^ 2 + ((25 : ℝ) / 8) * x1 ^ 2 := by
    nlinarith [sq_nonneg (2 * x0 + 5 * x1)]
  have h23 :
      -(10 : ℝ) * (x2 * x3) ≤
        ((1 : ℝ) / 2) * x2 ^ 2 + 50 * x3 ^ 2 := by
    nlinarith [sq_nonneg (x2 + 10 * x3)]
  have h45 :
      -((4 : ℝ) / 5) * (x4 * x5) ≤
        ((1 : ℝ) / 2) * x4 ^ 2 + ((8 : ℝ) / 25) * x5 ^ 2 := by
    nlinarith [sq_nonneg (5 * x4 + 4 * x5)]
  have ha1 : a ^ 2 * x1 ^ 2 ≤ 25 * x1 ^ 2 :=
    mul_le_mul_of_nonneg_right ha (sq_nonneg x1)
  have ha3 : a ^ 2 * x3 ^ 2 ≤ 25 * x3 ^ 2 :=
    mul_le_mul_of_nonneg_right ha (sq_nonneg x3)
  have h21 :
      a * (x2 * x1) ≤
        ((1 : ℝ) / 2) * x2 ^ 2 + ((25 : ℝ) / 2) * x1 ^ 2 := by
    nlinarith [sq_nonneg (x2 - a * x1), ha1]
  have h03 :
      -(a * (x0 * x3)) ≤
        ((1 : ℝ) / 2) * x0 ^ 2 + ((25 : ℝ) / 2) * x3 ^ 2 := by
    nlinarith [sq_nonneg (x0 + a * x3), ha3]
  nlinarith [h01, h23, h45, h21, h03]

theorem lie_negative_squares_contra_c6ceabff07cb
    (x0 x1 x2 x3 x4 x5 D : ℝ)
    (hpos : x0 ^ 2 + x1 ^ 2 + x2 ^ 2 + x3 ^ 2 + x4 ^ 2 + x5 ^ 2 > 0)
    (hD : D ≥ 0)
    (hupper : D ≤
      -((1 : ℝ) / 100) * x0 ^ 2 - ((3867 : ℝ) / 800) * x1 ^ 2 -
      ((1 : ℝ) / 100) * x2 ^ 2 - ((3873 : ℝ) / 200) * x3 ^ 2 -
      ((9 : ℝ) / 200) * x4 ^ 2 - ((3967 : ℝ) / 2500) * x5 ^ 2) : False := by
  nlinarith [sq_nonneg x0, sq_nonneg x1, sq_nonneg x2,
    sq_nonneg x3, sq_nonneg x4, sq_nonneg x5]

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_c6ceabff07cb (hV : ContDiff ℝ 1 barrier_c6ceabff07cb) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_lie_negative_c6ceabff07cb := by
  rintro ⟨x, hx⟩
  unfold violationSet_lie_negative_c6ceabff07cb at hx
  simp only [Set.mem_setOf_eq] at hx
  rcases hx with
    ⟨hx0l, hx0u, hx1l, hx1u, hx2l, hx2u, hx3l, hx3u,
      hx4l, hx4u, hx5l, hx5u, hpos, hlie⟩
  let a : ℝ := ((3 : ℝ) / 2) * x 5 +
    ((1 : ℝ) / 2) * Real.sin (x 1) * Real.cos (x 3)
  have ha : a ^ 2 ≤ (25 : ℝ) := by
    simpa [a] using lie_negative_a_sq_c6ceabff07cb
      (x 5) (x 1) (x 3) hx5l hx5u
  let D : ℝ :=
    -(5 : ℝ) * (x 1) ^ 2 - 20 * (x 3) ^ 2 - ((8 : ℝ) / 5) * (x 5) ^ 2 +
      ((1 : ℝ) / 100) * ((x 1) ^ 2 + (x 3) ^ 2 + (x 5) ^ 2 -
        2 * (x 0) ^ 2 - 2 * (x 2) ^ 2 - 5 * (x 4) ^ 2 -
        ((5 : ℝ) / 2) * (x 0 * x 1) - 10 * (x 2 * x 3) -
        ((4 : ℝ) / 5) * (x 4 * x 5) + a * (x 2 * x 1 - x 0 * x 3))
  have hD : D ≥ 0 := by
    simpa [D, a] using lie_negative_group_nonneg_c6ceabff07cb
      (x 0) (x 1) (x 2) (x 3) (x 4) (x 5)
      (Real.sin (x 1)) (Real.cos (x 3)) hlie
  have hupper := lie_negative_upper_c6ceabff07cb
    (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) a ha
  apply lie_negative_squares_contra_c6ceabff07cb
    (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) D hpos hD
  simpa [D] using hupper

#print axioms verify_lie_negative_c6ceabff07cb

end LeanBarrier.Generated
