import LeanBarrier

#check Real.sin
#check Real.cos
#check Real.neg_one_le_sin
#check Real.sin_le_one
#check Real.neg_one_le_cos
#check Real.cos_le_one
