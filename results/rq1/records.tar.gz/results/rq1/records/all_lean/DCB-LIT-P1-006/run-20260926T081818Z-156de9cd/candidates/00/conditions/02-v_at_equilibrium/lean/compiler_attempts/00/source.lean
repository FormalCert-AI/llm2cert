import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: fefec43774fd30498a59870a97e61a3a7653fd6cd6842a1da3a96c2e894dac36
noncomputable def barrier_fefec43774fd (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2)))
@[simp] theorem barrier_unfold_fefec43774fd (x : LeanBarrier.State 3) : barrier_fefec43774fd x = ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) := by
  rfl
def violationSet_v_at_equilibrium_fefec43774fd : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) < (0 : ℝ)))))}

#print axioms barrier_unfold_fefec43774fd

end LeanBarrier.Generated
