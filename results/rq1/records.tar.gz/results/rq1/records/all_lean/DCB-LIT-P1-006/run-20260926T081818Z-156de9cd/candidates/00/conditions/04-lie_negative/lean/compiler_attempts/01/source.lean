import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fefec43774fd30498a59870a97e61a3a7653fd6cd6842a1da3a96c2e894dac36
noncomputable def barrier_fefec43774fd (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2)))
@[simp] theorem barrier_unfold_fefec43774fd (x : LeanBarrier.State 3) : barrier_fefec43774fd x = ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) := by
  rfl
def violationSet_lie_negative_fefec43774fd : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-10 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (-10 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (-10 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * ((-(x 0 ^ 3)) - (x 0 * (x 2 ^ 2)))) + ((2 : ℝ) * x 1 * ((-x 1) - ((x 0 ^ 2) * x 1))) + (((2 : ℝ) / (3 : ℝ)) * x 2 * (((-x 2) + ((3 : ℝ) * (x 0 ^ 2) * x 2)) - ((3 : ℝ) * x 2)))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_fefec43774fd (hV : ContDiff ℝ 1 barrier_fefec43774fd) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_fefec43774fd := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_fefec43774fd, Set.mem_setOf_eq] at hx
  rcases hx with ⟨_, _, _, _, _, _, _, hpos, hderiv⟩
  ring_nf at hderiv
  have h0 : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have h1 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  have h2 : 0 ≤ x 2 ^ 2 := sq_nonneg (x 2)
  have h0four_nonneg : 0 ≤ x 0 ^ 4 := by positivity
  have hcross : 0 ≤ (x 0 ^ 2) * (x 1 ^ 2) := mul_nonneg h0 h1
  have hx0four : x 0 ^ 4 = 0 := by
    nlinarith
  have hx1sq : x 1 ^ 2 = 0 := by
    nlinarith
  have hx2sq : x 2 ^ 2 = 0 := by
    nlinarith
  have hx0prod : (x 0 ^ 2) * (x 0 ^ 2) = 0 := by
    calc
      (x 0 ^ 2) * (x 0 ^ 2) = x 0 ^ 4 := by ring
      _ = 0 := hx0four
  have hx0sq : x 0 ^ 2 = 0 := by
    rcases mul_eq_zero.mp hx0prod with h | h
    · exact h
    · exact h
  nlinarith

#print axioms verify_lie_negative_fefec43774fd

end LeanBarrier.Generated
