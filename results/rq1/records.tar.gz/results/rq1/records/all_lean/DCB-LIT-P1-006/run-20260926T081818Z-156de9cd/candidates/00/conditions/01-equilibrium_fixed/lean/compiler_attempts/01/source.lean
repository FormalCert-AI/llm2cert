import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fefec43774fd30498a59870a97e61a3a7653fd6cd6842a1da3a96c2e894dac36
noncomputable def barrier_fefec43774fd (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2)))
@[simp] theorem barrier_unfold_fefec43774fd (x : LeanBarrier.State 3) : barrier_fefec43774fd x = ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) := by
  rfl
def violationSet_equilibrium_fixed_fefec43774fd : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((((-(x 0 ^ 3)) - (x 0 * (x 2 ^ 2))) > (0 : ℝ))) ∨ ((((-(x 0 ^ 3)) - (x 0 * (x 2 ^ 2))) < (0 : ℝ))) ∨ ((((-x 1) - ((x 0 ^ 2) * x 1)) > (0 : ℝ))) ∨ ((((-x 1) - ((x 0 ^ 2) * x 1)) < (0 : ℝ))) ∨ (((((-x 2) + ((3 : ℝ) * (x 0 ^ 2) * x 2)) - ((3 : ℝ) * x 2)) > (0 : ℝ))) ∨ (((((-x 2) + ((3 : ℝ) * (x 0 ^ 2) * x 2)) - ((3 : ℝ) * x 2)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_fefec43774fd (hV : ContDiff ℝ 1 barrier_fefec43774fd) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_fefec43774fd := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx2, hbad⟩
  simp [hx0, hx1, hx2] at hbad

#print axioms verify_equilibrium_fixed_fefec43774fd

end LeanBarrier.Generated
