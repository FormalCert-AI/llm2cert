import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fefec43774fd30498a59870a97e61a3a7653fd6cd6842a1da3a96c2e894dac36
noncomputable def barrier_fefec43774fd (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2)))
@[simp] theorem barrier_unfold_fefec43774fd (x : LeanBarrier.State 3) : barrier_fefec43774fd x = ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) := by
  rfl
def violationSet_positive_definite_fefec43774fd : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-10 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (-10 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (-10 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (3 : ℝ)) * (x 2 ^ 2))) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_fefec43774fd (hV : ContDiff ℝ 1 barrier_fefec43774fd) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_fefec43774fd := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_positive_definite_fefec43774fd] at hx
  rcases hx with ⟨hx0lo, hx0hi, hx1lo, hx1hi, hx2lo, hx2hi, hbound, hpos, hnonpos⟩
  have hs0 : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have hs1 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  have hs2 : 0 ≤ x 2 ^ 2 := sq_nonneg (x 2)
  nlinarith

#print axioms verify_positive_definite_fefec43774fd

end LeanBarrier.Generated
