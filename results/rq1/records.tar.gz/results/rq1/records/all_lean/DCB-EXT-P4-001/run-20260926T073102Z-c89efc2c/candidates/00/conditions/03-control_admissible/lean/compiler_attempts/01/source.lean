import LeanBarrier

#check Real.sqrt
#check Real.sqrt_pos
#check Real.sq_sqrt
