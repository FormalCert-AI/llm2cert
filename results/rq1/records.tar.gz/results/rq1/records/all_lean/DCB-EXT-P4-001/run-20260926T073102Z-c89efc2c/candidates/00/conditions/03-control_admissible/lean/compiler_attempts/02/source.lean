import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: a7ad635fb2383c3d1c93d38488a758eeaa0a2966dc98154eb49136d3d266af7f
noncomputable def barrier_a7ad635fb238 (x : LeanBarrier.State 4) : ℝ := ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2))
@[simp] theorem barrier_unfold_a7ad635fb238 (x : LeanBarrier.State 4) : barrier_a7ad635fb238 x = ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) := by
  rfl
def violationSet_control_admissible_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | (((((((-3 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (1 : ℝ))))) < (-5 : ℝ))) ∨ (((((-3 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (1 : ℝ))))) > (5 : ℝ))) ∨ (((((-3 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 1 ^ 2) + (1 : ℝ))))) < (-5 : ℝ))) ∨ (((((-3 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 1 ^ 2) + (1 : ℝ))))) > (5 : ℝ))) ∨ (((((-3 : ℝ) * x 2) / ((2 : ℝ) * Real.sqrt (((x 2 ^ 2) + (1 : ℝ))))) < (-5 : ℝ))) ∨ (((((-3 : ℝ) * x 2) / ((2 : ℝ) * Real.sqrt (((x 2 ^ 2) + (1 : ℝ))))) > (5 : ℝ))) ∨ (((((-3 : ℝ) * x 3) / ((2 : ℝ) * Real.sqrt (((x 3 ^ 2) + (1 : ℝ))))) < (-5 : ℝ))) ∨ (((((-3 : ℝ) * x 3) / ((2 : ℝ) * Real.sqrt (((x 3 ^ 2) + (1 : ℝ))))) > (5 : ℝ)))))}
def unsafeSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≥ ((25 : ℝ) / (4 : ℝ))))}
def initialSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≤ ((9 : ℝ) / (100 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_control_admissible_a7ad635fb238 (hV : ContDiff ℝ 1 barrier_a7ad635fb238) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_control_admissible_a7ad635fb238 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_control_admissible_a7ad635fb238, Set.mem_setOf_eq] at hx
  have hbound (t : ℝ) :
      (-5 : ℝ) ≤ ((-3 : ℝ) * t) / ((2 : ℝ) * Real.sqrt (t ^ 2 + 1)) ∧
        ((-3 : ℝ) * t) / ((2 : ℝ) * Real.sqrt (t ^ 2 + 1)) ≤ (5 : ℝ) := by
    have harg : 0 ≤ t ^ 2 + 1 := by
      nlinarith [sq_nonneg t]
    have hargpos : 0 < t ^ 2 + 1 := by
      nlinarith [sq_nonneg t]
    have hspos : 0 < Real.sqrt (t ^ 2 + 1) := Real.sqrt_pos.2 hargpos
    have hsq : (Real.sqrt (t ^ 2 + 1)) ^ 2 = t ^ 2 + 1 :=
      Real.sq_sqrt harg
    have ht_upper : t ≤ Real.sqrt (t ^ 2 + 1) := by
      by_contra hn
      have hdiff : 0 < t - Real.sqrt (t ^ 2 + 1) :=
        sub_pos.mpr (lt_of_not_ge hn)
      have hsum : 0 < t + Real.sqrt (t ^ 2 + 1) := by
        linarith
      have hprod :
          0 < (t - Real.sqrt (t ^ 2 + 1)) *
            (t + Real.sqrt (t ^ 2 + 1)) :=
        mul_pos hdiff hsum
      nlinarith
    have ht_lower : -Real.sqrt (t ^ 2 + 1) ≤ t := by
      by_contra hn
      have hlt : t < -Real.sqrt (t ^ 2 + 1) := lt_of_not_ge hn
      have hdiff : 0 < -t - Real.sqrt (t ^ 2 + 1) := by
        linarith
      have hsum : 0 < -t + Real.sqrt (t ^ 2 + 1) := by
        linarith
      have hprod :
          0 < (-t - Real.sqrt (t ^ 2 + 1)) *
            (-t + Real.sqrt (t ^ 2 + 1)) :=
        mul_pos hdiff hsum
      nlinarith
    have hden : 0 < (2 : ℝ) * Real.sqrt (t ^ 2 + 1) := by
      positivity
    constructor
    · apply (le_div_iff₀ hden).2
      nlinarith
    · apply (div_le_iff₀ hden).2
      nlinarith
  have h0 := hbound (x 0)
  have h1 := hbound (x 1)
  have h2 := hbound (x 2)
  have h3 := hbound (x 3)
  rcases hx with hx | hx | hx | hx | hx | hx | hx | hx
  · linarith [h0.1]
  · linarith [h0.2]
  · linarith [h1.1]
  · linarith [h1.2]
  · linarith [h2.1]
  · linarith [h2.2]
  · linarith [h3.1]
  · linarith [h3.2]

#print axioms verify_control_admissible_a7ad635fb238

end LeanBarrier.Generated
