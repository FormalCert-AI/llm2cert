import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: a7ad635fb2383c3d1c93d38488a758eeaa0a2966dc98154eb49136d3d266af7f
noncomputable def barrier_a7ad635fb238 (x : LeanBarrier.State 4) : ℝ := ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2))
@[simp] theorem barrier_unfold_a7ad635fb238 (x : LeanBarrier.State 4) : barrier_a7ad635fb238 x = ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) := by
  rfl
def violationSet_lie_strict_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * (x 1 + (((-3 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 1)) * (((((-19 : ℝ) / (20 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (50 : ℝ)) * x 1)) + (((1 : ℝ) / (100 : ℝ)) * x 2) + (((-3 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 1 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 2)) * ((((-1 : ℝ) / (10 : ℝ)) * x 2) + (((1 : ℝ) / (50 : ℝ)) * x 0) + (((-3 : ℝ) * x 2) / ((2 : ℝ) * Real.sqrt (((x 2 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 3)) * ((((-3 : ℝ) / (100 : ℝ)) * x 3) + (((1 : ℝ) / (100 : ℝ)) * x 1) + (((-3 : ℝ) * x 3) / ((2 : ℝ) * Real.sqrt (((x 3 ^ 2) + (1 : ℝ)))))))) ≤ (0 : ℝ)))}
def unsafeSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≥ ((25 : ℝ) / (4 : ℝ))))}
def initialSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≤ ((9 : ℝ) / (100 : ℝ))))}

lemma lie_q_bound_a7ad635fb238 (a b c d : ℝ) :
    a * b - ((19 : ℝ) / 20) * b * Real.sin a
        - ((1 : ℝ) / 50) * b ^ 2
        + ((1 : ℝ) / 100) * b * c
        - ((1 : ℝ) / 10) * c ^ 2
        + ((1 : ℝ) / 50) * a * c
        - ((3 : ℝ) / 100) * d ^ 2
        + ((1 : ℝ) / 100) * b * d
      ≤ ((197 : ℝ) / 200) * (a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2) := by
  have young (u v : ℝ) : |u * v| ≤ (u ^ 2 + v ^ 2) / 2 := by
    by_cases huv : 0 ≤ u * v
    · rw [abs_of_nonneg huv]
      nlinarith [sq_nonneg (u - v)]
    · have huv' : u * v ≤ 0 := le_of_not_ge huv
      rw [abs_of_nonpos huv']
      nlinarith [sq_nonneg (u + v)]
  have hab : a * b ≤ (a ^ 2 + b ^ 2) / 2 :=
    le_trans (le_abs_self (a * b)) (young a b)
  have hbc : b * c ≤ (b ^ 2 + c ^ 2) / 2 :=
    le_trans (le_abs_self (b * c)) (young b c)
  have hac : a * c ≤ (a ^ 2 + c ^ 2) / 2 :=
    le_trans (le_abs_self (a * c)) (young a c)
  have hbd : b * d ≤ (b ^ 2 + d ^ 2) / 2 :=
    le_trans (le_abs_self (b * d)) (young b d)
  have htrig0 : -(b * Real.sin a) ≤ (a ^ 2 + b ^ 2) / 2 := by
    calc
      -(b * Real.sin a) ≤ |b * Real.sin a| := neg_le_abs _
      _ = |b| * |Real.sin a| := abs_mul b (Real.sin a)
      _ ≤ |b| * |a| :=
        mul_le_mul_of_nonneg_left (Real.abs_sin_le_abs a) (abs_nonneg b)
      _ = |b * a| := (abs_mul b a).symm
      _ ≤ (b ^ 2 + a ^ 2) / 2 := young b a
      _ = (a ^ 2 + b ^ 2) / 2 := by ring
  have htrig :
      -((19 : ℝ) / 20) * b * Real.sin a
        ≤ ((19 : ℝ) / 40) * (a ^ 2 + b ^ 2) := by
    nlinarith [htrig0]
  nlinarith [hab, hbc, hac, hbd, htrig, sq_nonneg a, sq_nonneg b,
    sq_nonneg c, sq_nonneg d]

lemma lie_radial_lower_a7ad635fb238 (a b c d : ℝ)
    (hr2 : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (5 : ℝ) / 4) :
    (5 : ℝ) / 6 ≤
      a ^ 2 / Real.sqrt (a ^ 2 + 1) +
      b ^ 2 / Real.sqrt (b ^ 2 + 1) +
      c ^ 2 / Real.sqrt (c ^ 2 + 1) +
      d ^ 2 / Real.sqrt (d ^ 2 + 1) := by
  have hterm (u : ℝ) (hu : u ^ 2 ≤ (5 : ℝ) / 4) :
      ((2 : ℝ) / 3) * u ^ 2 ≤ u ^ 2 / Real.sqrt (u ^ 2 + 1) := by
    have hp : 0 < Real.sqrt (u ^ 2 + 1) :=
      Real.sqrt_pos.2 (by nlinarith [sq_nonneg u])
    have hs : (Real.sqrt (u ^ 2 + 1)) ^ 2 = u ^ 2 + 1 :=
      Real.sq_sqrt (by nlinarith [sq_nonneg u])
    have hle : Real.sqrt (u ^ 2 + 1) ≤ (3 : ℝ) / 2 := by
      nlinarith [hs, hu, le_of_lt hp]
    apply (le_div_iff₀ hp).2
    have hm := mul_le_mul_of_nonneg_left hle (sq_nonneg u)
    nlinarith
  have ha : a ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr2, sq_nonneg b, sq_nonneg c, sq_nonneg d]
  have hb : b ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr2, sq_nonneg a, sq_nonneg c, sq_nonneg d]
  have hc : c ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr2, sq_nonneg a, sq_nonneg b, sq_nonneg d]
  have hd : d ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr2, sq_nonneg a, sq_nonneg b, sq_nonneg c]
  nlinarith [hterm a ha, hterm b hb, hterm c hc, hterm d hd]

lemma lie_algebra_a7ad635fb238 (x : LeanBarrier.State 4)
    (hx : x ∈ violationSet_lie_strict_a7ad635fb238) :
    3 * (x 0 ^ 2 / Real.sqrt (x 0 ^ 2 + 1) +
         x 1 ^ 2 / Real.sqrt (x 1 ^ 2 + 1) +
         x 2 ^ 2 / Real.sqrt (x 2 ^ 2 + 1) +
         x 3 ^ 2 / Real.sqrt (x 3 ^ 2 + 1))
      - 2 * (x 0 * x 1
        - ((19 : ℝ) / 20) * x 1 * Real.sin (x 0)
        - ((1 : ℝ) / 50) * (x 1) ^ 2
        + ((1 : ℝ) / 100) * x 1 * x 2
        - ((1 : ℝ) / 10) * (x 2) ^ 2
        + ((1 : ℝ) / 50) * x 0 * x 2
        - ((3 : ℝ) / 100) * (x 3) ^ 2
        + ((1 : ℝ) / 100) * x 1 * x 3) ≤ 0 := by
  rcases hx with ⟨_, hL⟩
  ring_nf at hL ⊢
  exact hL

lemma lie_violation_false_a7ad635fb238 (x : LeanBarrier.State 4)
    (hx : x ∈ violationSet_lie_strict_a7ad635fb238) : False := by
  have hB := hx.1
  have hr2 : x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 + x 3 ^ 2 = (5 : ℝ) / 4 := by
    nlinarith [hB]
  have hs := lie_radial_lower_a7ad635fb238 (x 0) (x 1) (x 2) (x 3) hr2
  have hq := lie_q_bound_a7ad635fb238 (x 0) (x 1) (x 2) (x 3)
  have hder := lie_algebra_a7ad635fb238 x hx
  nlinarith [hr2, hs, hq, hder]

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_a7ad635fb238 (hV : ContDiff ℝ 1 barrier_a7ad635fb238) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_a7ad635fb238 := by
  rintro ⟨x, hx⟩
  exact lie_violation_false_a7ad635fb238 x hx

#print axioms verify_lie_strict_a7ad635fb238

end LeanBarrier.Generated
