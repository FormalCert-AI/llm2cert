import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 25de0385df9539649b4867a06b67542475bf56341e74cdb694a4c93951fa7a27
noncomputable def barrier_25de0385df95 (x : LeanBarrier.State 2) : ℝ := (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4)))
@[simp] theorem barrier_unfold_25de0385df95 (x : LeanBarrier.State 2) : barrier_25de0385df95 x = (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) := by
  rfl
def violationSet_control_admissible_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((((((-x 0) / ((x 0 ^ 2) + (1 : ℝ))) < (-1 : ℝ))) ∨ ((((-x 0) / ((x 0 ^ 2) + (1 : ℝ))) > (1 : ℝ))) ∨ ((((-x 1) / ((x 1 ^ 2) + (1 : ℝ))) < (-1 : ℝ))) ∨ ((((-x 1) / ((x 1 ^ 2) + (1 : ℝ))) > (1 : ℝ)))))}
def unsafeSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (1 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (1 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ ((((x 0 - (2 : ℝ)) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2)) ≤ (1 : ℝ)))}
def initialSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_control_admissible_25de0385df95 (hV : ContDiff ℝ 1 barrier_25de0385df95) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_control_admissible_25de0385df95 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_control_admissible_25de0385df95, Set.mem_setOf_eq] at hx
  have hbound : ∀ z : ℝ, (-1 : ℝ) ≤ (-z) / (z ^ 2 + 1) ∧ (-z) / (z ^ 2 + 1) ≤ 1 := by
    intro z
    have hden : 0 < z ^ 2 + 1 := by
      nlinarith [sq_nonneg z]
    constructor
    · apply (le_div_iff₀ hden).2
      nlinarith [sq_nonneg (z - (1 / 2 : ℝ))]
    · apply (div_le_iff₀ hden).2
      nlinarith [sq_nonneg (z + (1 / 2 : ℝ))]
  obtain ⟨h0_lower, h0_upper⟩ := hbound (x 0)
  obtain ⟨h1_lower, h1_upper⟩ := hbound (x 1)
  rcases hx with hx | hx | hx | hx
  · exact (not_lt_of_ge h0_lower) hx
  · exact (not_lt_of_ge h0_upper) hx
  · exact (not_lt_of_ge h1_lower) hx
  · exact (not_lt_of_ge h1_upper) hx

#print axioms verify_control_admissible_25de0385df95

end LeanBarrier.Generated
