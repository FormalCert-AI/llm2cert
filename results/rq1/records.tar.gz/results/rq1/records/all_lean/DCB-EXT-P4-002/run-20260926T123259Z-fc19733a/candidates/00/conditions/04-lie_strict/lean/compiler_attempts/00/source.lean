import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 25de0385df9539649b4867a06b67542475bf56341e74cdb694a4c93951fa7a27
noncomputable def barrier_25de0385df95 (x : LeanBarrier.State 2) : ℝ := (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4)))
@[simp] theorem barrier_unfold_25de0385df95 (x : LeanBarrier.State 2) : barrier_25de0385df95 x = (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) := by
  rfl
def violationSet_lie_strict_25de0385df95 : Set (LeanBarrier.State 2) := {x | (((((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) = (0 : ℝ)) ∧ (((((-(((3 : ℝ) / (10 : ℝ)) * x 0)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 3))) * (x 1 + ((-x 0) / ((x 0 ^ 2) + (1 : ℝ))))) + ((-x 1) * ((((((-3 : ℝ) / (10 : ℝ)) * x 0) - (((1 : ℝ) / (5 : ℝ)) * (Real.cos (x 0) + (1 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 3))) + ((-x 1) / ((x 1 ^ 2) + (1 : ℝ)))))) ≤ (0 : ℝ)))}
def unsafeSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (1 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (1 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ ((((x 0 - (2 : ℝ)) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2)) ≤ (1 : ℝ)))}
def initialSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}

#print axioms barrier_unfold_25de0385df95

end LeanBarrier.Generated
