import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 25de0385df9539649b4867a06b67542475bf56341e74cdb694a4c93951fa7a27
noncomputable def barrier_25de0385df95 (x : LeanBarrier.State 2) : ℝ := (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4)))
@[simp] theorem barrier_unfold_25de0385df95 (x : LeanBarrier.State 2) : barrier_25de0385df95 x = (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) := by
  rfl
def violationSet_lie_strict_25de0385df95 : Set (LeanBarrier.State 2) := {x | (((((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) = (0 : ℝ)) ∧ (((((-(((3 : ℝ) / (10 : ℝ)) * x 0)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 3))) * (x 1 + ((-x 0) / ((x 0 ^ 2) + (1 : ℝ))))) + ((-x 1) * ((((((-3 : ℝ) / (10 : ℝ)) * x 0) - (((1 : ℝ) / (5 : ℝ)) * (Real.cos (x 0) + (1 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 3))) + ((-x 1) / ((x 1 ^ 2) + (1 : ℝ)))))) ≤ (0 : ℝ)))}
def unsafeSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (1 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (1 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ ((((x 0 - (2 : ℝ)) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2)) ≤ (1 : ℝ)))}
def initialSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_25de0385df95 (hV : ContDiff ℝ 1 barrier_25de0385df95) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_strict_25de0385df95 := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_lie_strict_25de0385df95] at hx
  rcases hx with ⟨hB, hL⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  change
    ((-((3 : ℝ) / 10 * a) - (1 : ℝ) / 10 * a ^ 3) *
          (b + (-a) / (a ^ 2 + 1)) +
      (-b) *
          ((((-3 : ℝ) / 10 * a -
                (1 : ℝ) / 5 * (Real.cos a + 1) * b) -
              (1 : ℝ) / 10 * a ^ 3) +
            (-b) / (b ^ 2 + 1))) ≤ 0 at hL
  have hda : 0 < a ^ 2 + 1 := by positivity
  have hdb : 0 < b ^ 2 + 1 := by positivity
  have hcos : 0 ≤ Real.cos a + 1 := by
    have hc := Real.neg_one_le_cos a
    linarith
  have hdecomp :
      ((-((3 : ℝ) / 10 * a) - (1 : ℝ) / 10 * a ^ 3) *
            (b + (-a) / (a ^ 2 + 1)) +
        (-b) *
            ((((-3 : ℝ) / 10 * a -
                  (1 : ℝ) / 5 * (Real.cos a + 1) * b) -
                (1 : ℝ) / 10 * a ^ 3) +
              (-b) / (b ^ 2 + 1))) =
        (((3 : ℝ) / 10 * a ^ 2 + (1 : ℝ) / 10 * a ^ 4) /
              (a ^ 2 + 1) +
            (1 : ℝ) / 5 * (Real.cos a + 1) * b ^ 2 +
          b ^ 2 / (b ^ 2 + 1)) := by
    ring
  rw [hdecomp] at hL
  have hA :
      0 ≤ ((3 : ℝ) / 10 * a ^ 2 + (1 : ℝ) / 10 * a ^ 4) /
        (a ^ 2 + 1) := by
    apply div_nonneg
    · positivity
    · exact le_of_lt hda
  have hD :
      0 ≤ (1 : ℝ) / 5 * (Real.cos a + 1) * b ^ 2 := by
    exact mul_nonneg (mul_nonneg (by norm_num) hcos) (sq_nonneg b)
  have hC : 0 ≤ b ^ 2 / (b ^ 2 + 1) := by
    exact div_nonneg (sq_nonneg b) (le_of_lt hdb)
  have ha : a = 0 := by
    by_contra hane
    have ha2 : 0 < a ^ 2 := by positivity
    have ha4 : 0 ≤ a ^ 4 := by positivity
    have hnum :
        0 < (3 : ℝ) / 10 * a ^ 2 + (1 : ℝ) / 10 * a ^ 4 := by
      nlinarith
    have hAp :
        0 < ((3 : ℝ) / 10 * a ^ 2 + (1 : ℝ) / 10 * a ^ 4) /
          (a ^ 2 + 1) :=
      div_pos hnum hda
    linarith
  have hb : b = 0 := by
    by_contra hbne
    have hb2 : 0 < b ^ 2 := by positivity
    have hCp : 0 < b ^ 2 / (b ^ 2 + 1) := div_pos hb2 hdb
    linarith
  have hx0 : x 0 = 0 := by
    simpa [a] using ha
  have hx1 : x 1 = 0 := by
    simpa [b] using hb
  norm_num [hx0, hx1] at hB

#print axioms verify_lie_strict_25de0385df95

end LeanBarrier.Generated
