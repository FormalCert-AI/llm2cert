import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 25de0385df9539649b4867a06b67542475bf56341e74cdb694a4c93951fa7a27
noncomputable def barrier_25de0385df95 (x : LeanBarrier.State 2) : ℝ := (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4)))
@[simp] theorem barrier_unfold_25de0385df95 (x : LeanBarrier.State 2) : barrier_25de0385df95 x = (((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) := by
  rfl
def violationSet_initial_containment_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))) ∧ ((((((2 : ℝ) / (3 : ℝ)) - (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2))) - (((3 : ℝ) / (20 : ℝ)) * (x 0 ^ 2))) - (((1 : ℝ) / (40 : ℝ)) * (x 0 ^ 4))) < (0 : ℝ)))}
def unsafeSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (1 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (1 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ ((((x 0 - (2 : ℝ)) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2)) ≤ (1 : ℝ)))}
def initialSet_25de0385df95 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_initial_containment_25de0385df95 (hV : ContDiff ℝ 1 barrier_25de0385df95) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_initial_containment_25de0385df95 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_initial_containment_25de0385df95, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0lo, hx0hi, hx1lo, hx1hi, hball, hneg⟩
  have h0sq : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have h1sq : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  have ht : x 0 ^ 2 ≤ (9 : ℝ) / 25 := by
    nlinarith [hball, h1sq]
  have hquart : x 0 ^ 4 ≤ ((9 : ℝ) / 25) * (x 0 ^ 2) := by
    calc
      x 0 ^ 4 = x 0 ^ 2 * x 0 ^ 2 := by ring
      _ ≤ ((9 : ℝ) / 25) * (x 0 ^ 2) :=
        mul_le_mul_of_nonneg_right ht h0sq
  have hbar :
      (73 : ℝ) / 150 ≤
        (((((2 : ℝ) / 3) - (((1 : ℝ) / 2) * (x 1 ^ 2))) -
            (((3 : ℝ) / 20) * (x 0 ^ 2))) -
          (((1 : ℝ) / 40) * (x 0 ^ 4))) := by
    nlinarith [hball, hquart, h0sq]
  linarith

#print axioms verify_initial_containment_25de0385df95

end LeanBarrier.Generated
