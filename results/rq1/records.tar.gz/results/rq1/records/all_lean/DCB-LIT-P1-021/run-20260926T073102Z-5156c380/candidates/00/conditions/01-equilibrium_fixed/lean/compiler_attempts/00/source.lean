import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 4d3ace7a9d1526d657accd9fe018e63e783f67ecf0173afbad3983122a0320ee
noncomputable def barrier_4d3ace7a9d15 (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) + (x 1 ^ 2)) * Real.exp ((((-10 : ℝ) * x 0 * x 1) / ((x 0 ^ 2) + (x 1 ^ 2)))))
@[simp] theorem barrier_unfold_4d3ace7a9d15 (x : LeanBarrier.State 2) : barrier_4d3ace7a9d15 x = (((x 0 ^ 2) + (x 1 ^ 2)) * Real.exp ((((-10 : ℝ) * x 0 * x 1) / ((x 0 ^ 2) + (x 1 ^ 2))))) := by
  rfl
def violationSet_equilibrium_fixed_4d3ace7a9d15 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ ((((((((4 : ℝ) * (x 0 ^ 3)) - ((x 0 ^ 2) * x 1)) - ((6 : ℝ) * x 0 * (x 1 ^ 2))) - (x 1 ^ 3)) > (0 : ℝ))) ∨ (((((((4 : ℝ) * (x 0 ^ 3)) - ((x 0 ^ 2) * x 1)) - ((6 : ℝ) * x 0 * (x 1 ^ 2))) - (x 1 ^ 3)) < (0 : ℝ))) ∨ (((((x 0 ^ 3) + ((4 : ℝ) * (x 0 ^ 2) * x 1) + (x 0 * (x 1 ^ 2))) - ((6 : ℝ) * (x 1 ^ 3))) > (0 : ℝ))) ∨ (((((x 0 ^ 3) + ((4 : ℝ) * (x 0 ^ 2) * x 1) + (x 0 * (x 1 ^ 2))) - ((6 : ℝ) * (x 1 ^ 3))) < (0 : ℝ)))))}

#print axioms barrier_unfold_4d3ace7a9d15

end LeanBarrier.Generated
