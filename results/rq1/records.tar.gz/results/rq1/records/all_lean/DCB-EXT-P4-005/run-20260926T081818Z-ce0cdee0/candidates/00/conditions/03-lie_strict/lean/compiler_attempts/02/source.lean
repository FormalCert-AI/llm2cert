import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 76e060f5155150b826c7805005717daa6fd4339f09496f768f9db927d1810210
noncomputable def barrier_76e060f51551 (x : LeanBarrier.State 10) : ℝ := ((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3))
@[simp] theorem barrier_unfold_76e060f51551 (x : LeanBarrier.State 10) : barrier_76e060f51551 x = ((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3)) := by
  rfl
def violationSet_lie_strict_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 9 ≥ (-1 : ℝ)) ∧ (x 9 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (x 3 ≥ (-1 : ℝ)) ∧ (x 3 ≤ (1 : ℝ)) ∧ (x 4 ≥ (-1 : ℝ)) ∧ (x 4 ≤ (1 : ℝ)) ∧ (x 5 ≥ (-1 : ℝ)) ∧ (x 5 ≤ (1 : ℝ)) ∧ (x 6 ≥ (-1 : ℝ)) ∧ (x 6 ≤ (1 : ℝ)) ∧ (x 7 ≥ (-1 : ℝ)) ∧ (x 7 ≤ (1 : ℝ)) ∧ (x 8 ≥ (-1 : ℝ)) ∧ (x 8 ≤ (1 : ℝ)) ∧ (((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3)) = (0 : ℝ)) ∧ ((((-1 : ℝ) * ((((-x 0) + (((1 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 8 ^ 2))) + Real.sin (x 1))) + ((-((3 : ℝ) * (x 1 ^ 2))) * ((((-1 : ℝ) / (2 : ℝ)) * x 0) - x 1))) ≤ (0 : ℝ)))}
def unsafeSet_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ ((9 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 9 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 9 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-1 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((1 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≤ ((2 : ℝ) / (5 : ℝ))))}
def initialSet_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 9 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 9 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 1 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 1 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 2 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 3 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 3 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 4 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 4 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 5 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 5 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 6 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 6 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 7 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 7 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 8 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 8 ≤ ((7 : ℝ) / (20 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_76e060f51551 (hV : ContDiff ℝ 1 barrier_76e060f51551) : ¬ ∃ x : LeanBarrier.State 10, x ∈ violationSet_lie_strict_76e060f51551 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_strict_76e060f51551, Set.mem_setOf_eq] at hx
  rcases hx with
    ⟨hx0lo, hx0hi, hx9lo, hx9hi, hslo, hshi,
      hx2lo, hx2hi, hx3lo, hx3hi, hx4lo, hx4hi,
      hx5lo, hx5hi, hx6lo, hx6hi, hx7lo, hx7hi,
      hzlo, hzhi, hb, hd⟩
  let s : ℝ := x 1
  let z : ℝ := x 8
  change (-1 : ℝ) ≤ s at hslo
  change s ≤ (1 : ℝ) at hshi
  have hx0 : x 0 = (2 : ℝ) / 5 - s ^ 3 := by
    dsimp [s]
    nlinarith [hb]
  have hbad :
      (2 : ℝ) / 5 - s / 2 - Real.sin s + (3 : ℝ) / 5 * s ^ 2
          + 2 * s ^ 3 - (3 : ℝ) / 2 * s ^ 5 + z ^ 2 / 10 ≤ 0 := by
    rw [hx0] at hd
    dsimp [s, z] at hd ⊢
    nlinarith [hd]
  have hq :
      0 < (2 : ℝ) / 5 - s / 2 - Real.sin s + (3 : ℝ) / 5 * s ^ 2
          + 2 * s ^ 3 - (3 : ℝ) / 2 * s ^ 5 := by
    by_cases hsneg : s < 0
    · let t : ℝ := -s
      have ht0 : 0 ≤ t := by
        dsimp [t]
        linarith
      have ht1 : t ≤ 1 := by
        dsimp [t]
        linarith
      have htpi : t ≤ Real.pi := by
        have hpi := Real.pi_gt_three
        linarith
      have hsint : 0 ≤ Real.sin t :=
        Real.sin_nonneg_of_nonneg_of_le_pi ht0 htpi
      have hsins : Real.sin s ≤ 0 := by
        dsimp [t] at hsint
        rw [Real.sin_neg] at hsint
        linarith
      have hpoly :
          0 < (2 : ℝ) / 5 + t / 2 + (3 : ℝ) / 5 * t ^ 2
              - 2 * t ^ 3 + (3 : ℝ) / 2 * t ^ 5 := by
        by_cases ht : t ≤ (3 : ℝ) / 4
        · have hgap : 0 ≤ (3 : ℝ) / 4 - t := by linarith
          have ha : 0 ≤ t ^ 2 * ((3 : ℝ) / 4 - t) :=
            mul_nonneg (sq_nonneg t) hgap
          have hb' : 0 ≤ t * ((3 : ℝ) / 4 - t) :=
            mul_nonneg ht0 hgap
          have hpow5 : 0 ≤ t ^ 5 := pow_nonneg ht0 5
          nlinarith [ha, hb', hpow5]
        · have ht' : (3 : ℝ) / 4 < t := lt_of_not_ge ht
          have ha : 0 ≤ (t - (3 : ℝ) / 4) * (t + (3 : ℝ) / 4) :=
            mul_nonneg (by linarith) (by linarith)
          have ht2 : (9 : ℝ) / 16 ≤ t ^ 2 := by
            nlinarith [ha]
          have hpow3 : 0 ≤ t ^ 3 := pow_nonneg ht0 3
          have hrel5 : 0 ≤ t ^ 3 * (t ^ 2 - (9 : ℝ) / 16) :=
            mul_nonneg hpow3 (by linarith)
          have hone : 0 ≤ (1 - t) * (1 + t) :=
            mul_nonneg (by linarith) (by linarith)
          have ht3le : t ^ 3 ≤ t := by
            have hrel : 0 ≤ t * (1 - t ^ 2) :=
              mul_nonneg ht0 (by nlinarith [hone])
            nlinarith [hrel]
          have ht2lin : (3 : ℝ) / 4 * t ≤ t ^ 2 := by
            have hrel : 0 ≤ t * (t - (3 : ℝ) / 4) :=
              mul_nonneg ht0 (by linarith)
            nlinarith [hrel]
          nlinarith [hrel5, ht3le, ht2lin]
      dsimp [t] at hpoly
      nlinarith [hpoly, hsins]
    · have hs0 : 0 ≤ s := le_of_not_gt hsneg
      by_cases hs_eq : s = 0
      · subst s
        norm_num
      · have hspos : 0 < s := lt_of_le_of_ne hs0 (Ne.symm hs_eq)
        have hsinlt : Real.sin s < s := Real.sin_lt hspos
        have hQ :
            0 < 15 * s ^ 4 + 15 * s ^ 3 - 5 * s ^ 2 - 11 * s + 4 := by
          let y : ℝ := s - (2 : ℝ) / 5
          have hsrepr : s = y + (2 : ℝ) / 5 := by
            dsimp [y]
            ring
          have hylo : -(2 : ℝ) / 5 ≤ y := by
            dsimp [y]
            linarith
          by_cases hy : y ≤ 0
          · have ha : 0 ≤ y ^ 2 * (y + (2 : ℝ) / 5) :=
              mul_nonneg (sq_nonneg y) (by linarith)
            have hy4 : 0 ≤ y ^ 4 := pow_nonneg (sq_nonneg y) 2
            rw [hsrepr]
            nlinarith [ha, sq_nonneg y, hy4]
          · have hy0 : 0 ≤ y := le_of_not_gt hy
            have hsquare : 0 ≤ (1370 * y - 99) ^ 2 :=
              sq_nonneg (1370 * y - 99)
            have hy3 : 0 ≤ y ^ 3 := pow_nonneg hy0 3
            have hy4 : 0 ≤ y ^ 4 := pow_nonneg hy0 4
            rw [hsrepr]
            nlinarith [hsquare, hy3, hy4]
        have hfac :
            0 ≤ (1 - s) *
              (15 * s ^ 4 + 15 * s ^ 3 - 5 * s ^ 2 - 11 * s + 4) :=
          mul_nonneg (by linarith) (le_of_lt hQ)
        nlinarith [hfac, hsinlt]
  nlinarith [hbad, hq, sq_nonneg z]

#print axioms verify_lie_strict_76e060f51551

end LeanBarrier.Generated
