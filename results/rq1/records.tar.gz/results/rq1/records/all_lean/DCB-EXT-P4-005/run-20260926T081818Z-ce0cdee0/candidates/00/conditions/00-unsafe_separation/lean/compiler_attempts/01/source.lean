import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 76e060f5155150b826c7805005717daa6fd4339f09496f768f9db927d1810210
noncomputable def barrier_76e060f51551 (x : LeanBarrier.State 10) : ℝ := ((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3))
@[simp] theorem barrier_unfold_76e060f51551 (x : LeanBarrier.State 10) : barrier_76e060f51551 x = ((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3)) := by
  rfl
def violationSet_unsafe_separation_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 9 ≥ (-1 : ℝ)) ∧ (x 9 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (x 3 ≥ (-1 : ℝ)) ∧ (x 3 ≤ (1 : ℝ)) ∧ (x 4 ≥ (-1 : ℝ)) ∧ (x 4 ≤ (1 : ℝ)) ∧ (x 5 ≥ (-1 : ℝ)) ∧ (x 5 ≤ (1 : ℝ)) ∧ (x 6 ≥ (-1 : ℝ)) ∧ (x 6 ≤ (1 : ℝ)) ∧ (x 7 ≥ (-1 : ℝ)) ∧ (x 7 ≤ (1 : ℝ)) ∧ (x 8 ≥ (-1 : ℝ)) ∧ (x 8 ≤ (1 : ℝ)) ∧ (x 0 ≥ ((9 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 9 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 9 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-1 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((1 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (((((2 : ℝ) / (5 : ℝ)) - x 0) - (x 1 ^ 3)) ≥ (0 : ℝ)))}
def unsafeSet_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ ((9 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 9 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 9 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-1 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((1 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 5 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 6 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 7 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 8 ≤ ((2 : ℝ) / (5 : ℝ))))}
def initialSet_76e060f51551 : Set (LeanBarrier.State 10) := {x | ((x 0 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 9 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 9 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 1 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 1 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 2 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 3 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 3 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 4 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 4 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 5 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 5 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 6 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 6 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 7 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 7 ≤ ((7 : ℝ) / (20 : ℝ))) ∧ (x 8 ≥ ((-7 : ℝ) / (20 : ℝ))) ∧ (x 8 ≤ ((7 : ℝ) / (20 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_unsafe_separation_76e060f51551 (hV : ContDiff ℝ 1 barrier_76e060f51551) : ¬ ∃ x : LeanBarrier.State 10, x ∈ violationSet_unsafe_separation_76e060f51551 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_unsafe_separation_76e060f51551, Set.mem_setOf_eq] at hx
  have hcore :
      x 0 ≥ ((9 : ℝ) / 20) ∧
      x 1 ≥ ((-1 : ℝ) / 5) ∧
      (((2 : ℝ) / 5 - x 0) - x 1 ^ 3) ≥ 0 := by
    aesop
  rcases hcore with ⟨hx0, hx1, hb⟩
  have hfac : 0 ≤ x 1 + (1 : ℝ) / 5 := by
    linarith
  have hquad :
      0 ≤ x 1 ^ 2 - x 1 / 5 + (1 : ℝ) / 25 := by
    nlinarith [sq_nonneg (x 1 - (1 : ℝ) / 10)]
  have hprod :
      0 ≤ (x 1 + (1 : ℝ) / 5) *
        (x 1 ^ 2 - x 1 / 5 + (1 : ℝ) / 25) :=
    mul_nonneg hfac hquad
  have hcube : ((-1 : ℝ) / 125) ≤ x 1 ^ 3 := by
    nlinarith [hprod]
  nlinarith

#print axioms verify_unsafe_separation_76e060f51551

end LeanBarrier.Generated
