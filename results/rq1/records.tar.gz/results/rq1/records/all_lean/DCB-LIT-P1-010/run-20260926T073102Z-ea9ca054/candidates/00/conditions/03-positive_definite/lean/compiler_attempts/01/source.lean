import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fcd4d2914585dc23dc85123d1cd4bd0f95bc5282d83f5ebd76946bdf37a53bba
noncomputable def barrier_fcd4d2914585 (x : LeanBarrier.State 2) : ℝ := (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_fcd4d2914585 (x : LeanBarrier.State 2) : barrier_fcd4d2914585 x = (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_fcd4d2914585 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_fcd4d2914585 (hV : ContDiff ℝ 1 barrier_fcd4d2914585) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_fcd4d2914585 := by
  rintro ⟨x, hx⟩
  change
    x 0 ≥ (-1 : ℝ) ∧ x 0 ≤ (1 : ℝ) ∧
    x 1 ≥ (-1 : ℝ) ∧ x 1 ≤ (1 : ℝ) ∧
    x 0 ^ 2 + x 1 ^ 2 ≤ (1 : ℝ) ∧
    x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ) ∧
    (40 : ℝ) * x 0 ^ 2 + x 1 ^ 2 ≤ (0 : ℝ) at hx
  rcases hx with ⟨_, _, _, _, _, hpos, hnonpos⟩
  have hsq0 : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have hsq1 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  nlinarith

#print axioms verify_positive_definite_fcd4d2914585

end LeanBarrier.Generated
