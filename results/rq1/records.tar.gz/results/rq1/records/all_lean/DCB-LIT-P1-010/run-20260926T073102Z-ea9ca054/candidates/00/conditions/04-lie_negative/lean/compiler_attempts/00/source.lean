import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: fcd4d2914585dc23dc85123d1cd4bd0f95bc5282d83f5ebd76946bdf37a53bba
noncomputable def barrier_fcd4d2914585 (x : LeanBarrier.State 2) : ℝ := (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_fcd4d2914585 (x : LeanBarrier.State 2) : barrier_fcd4d2914585 x = (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_fcd4d2914585 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((80 : ℝ) * x 0 * (x 1 + ((-x 0) - x 1))) + (((160 : ℝ) / (3 : ℝ)) * x 1 * ((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (10 : ℝ)) * x 1)))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_fcd4d2914585

end LeanBarrier.Generated
