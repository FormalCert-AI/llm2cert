import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fcd4d2914585dc23dc85123d1cd4bd0f95bc5282d83f5ebd76946bdf37a53bba
noncomputable def barrier_fcd4d2914585 (x : LeanBarrier.State 2) : ℝ := (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_fcd4d2914585 (x : LeanBarrier.State 2) : barrier_fcd4d2914585 x = (((40 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_fcd4d2914585 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((80 : ℝ) * x 0 * (x 1 + ((-x 0) - x 1))) + (((160 : ℝ) / (3 : ℝ)) * x 1 * ((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (10 : ℝ)) * x 1)))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_fcd4d2914585 (hV : ContDiff ℝ 1 barrier_fcd4d2914585) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_fcd4d2914585 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_fcd4d2914585, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0lo, hx0hi, hx1lo, hx1hi, hball, hpos, hLie⟩
  have hs : |Real.sin (x 0)| ≤ |x 0| := Real.abs_sin_le_abs
  have hprod : x 1 * Real.sin (x 0) ≤ |(x 0) * (x 1)| := by
    calc
      x 1 * Real.sin (x 0) ≤ |x 1 * Real.sin (x 0)| := le_abs_self _
      _ = |x 1| * |Real.sin (x 0)| := abs_mul _ _
      _ ≤ |x 1| * |x 0| := mul_le_mul_of_nonneg_left hs (abs_nonneg _)
      _ = |(x 0) * (x 1)| := by
        rw [abs_mul]
        ring
  have hyoung : |(x 0) * (x 1)| ≤ 2 * (x 0) ^ 2 + (x 1) ^ 2 / 8 := by
    by_cases hab : 0 ≤ (x 0) * (x 1)
    · rw [abs_of_nonneg hab]
      nlinarith [sq_nonneg (4 * (x 0) - (x 1))]
    · have hab' : (x 0) * (x 1) ≤ 0 := le_of_not_ge hab
      rw [abs_of_nonpos hab']
      nlinarith [sq_nonneg (4 * (x 0) + (x 1))]
  have hbs : x 1 * Real.sin (x 0) ≤ 2 * (x 0) ^ 2 + (x 1) ^ 2 / 8 :=
    le_trans hprod hyoung
  ring_nf at hLie
  nlinarith only [hLie, hbs, hpos, sq_nonneg (x 0), sq_nonneg (x 1)]

#print axioms verify_lie_negative_fcd4d2914585

end LeanBarrier.Generated
