import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 7249bb5eadf69f3e4c64ca253681cb01f22407799a45b9312cb3c1f52e13bf4c
noncomputable def barrier_7249bb5eadf6 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_7249bb5eadf6 (x : LeanBarrier.State 2) : barrier_7249bb5eadf6 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_7249bb5eadf6 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_7249bb5eadf6 (hV : ContDiff ℝ 1 barrier_7249bb5eadf6) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_7249bb5eadf6 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_positive_definite_7249bb5eadf6, Set.mem_setOf_eq] at hx
  rcases hx with ⟨_, _, _, _, _, hpos, hnonpos⟩
  linarith

#print axioms verify_positive_definite_7249bb5eadf6

end LeanBarrier.Generated
