import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af26935702e76f407aa3e2acaf26ccb9dfbb1ee68554c99dc7923032c9812968
noncomputable def barrier_af26935702e7 (x : LeanBarrier.State 4) : ℝ := ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2))))
@[simp] theorem barrier_unfold_af26935702e7 (x : LeanBarrier.State 4) : barrier_af26935702e7 x = ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) := by
  rfl
def violationSet_unsafe_separation_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (3 : ℝ)) ∧ (((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) ≥ (0 : ℝ)) ∧ (((x 0 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (2 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (2 : ℝ)) ∧ (x 3 ≤ (3 : ℝ))) ∨ ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (-2 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (-2 : ℝ)))))}
def unsafeSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (3 : ℝ)) ∧ (((x 0 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (2 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (2 : ℝ)) ∧ (x 3 ≤ (3 : ℝ))) ∨ ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (-2 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (-2 : ℝ)))))}
def initialSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (5 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_unsafe_separation_af26935702e7 (hV : ContDiff ℝ 1 barrier_af26935702e7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_unsafe_separation_af26935702e7 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_unsafe_separation_af26935702e7, Set.mem_setOf_eq] at hx
  rcases hx with ⟨h0lo, h0hi, h1lo, h1hi, h2lo, h2hi, h3lo, h3hi, hbad, hunsafe⟩
  rcases hunsafe with hpos | hneg
  · rcases hpos with ⟨hp0, _, hp1, _, hp2, _, hp3, _⟩
    have hx0 : 0 ≤ x 0 := by linarith
    have hx1 : 0 ≤ x 1 := by linarith
    have hx2 : 0 ≤ x 2 := by linarith
    have hx3 : 0 ≤ x 3 := by linarith
    have hlarge : (25 : ℝ) / 4 ≤ x 0 ^ 2 := by
      nlinarith [sq_nonneg (x 0 - (5 : ℝ) / 2)]
    have h01 : 0 ≤ x 0 * x 1 := mul_nonneg hx0 hx1
    have h11 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
    have h22 : 0 ≤ x 2 ^ 2 := sq_nonneg (x 2)
    have h23 : 0 ≤ x 2 * x 3 := mul_nonneg hx2 hx3
    have h33 : 0 ≤ x 3 ^ 2 := sq_nonneg (x 3)
    nlinarith [hlarge, h01, h11, h22, h23, h33]
  · rcases hneg with ⟨_, hn0, _, hn1, _, hn2, _, hn3⟩
    have hx0 : x 0 ≤ 0 := by linarith
    have hx1 : x 1 ≤ 0 := by linarith
    have hx2 : x 2 ≤ 0 := by linarith
    have hx3 : x 3 ≤ 0 := by linarith
    have hlarge : (25 : ℝ) / 4 ≤ x 0 ^ 2 := by
      nlinarith [sq_nonneg (x 0 + (5 : ℝ) / 2)]
    have h01 : 0 ≤ x 0 * x 1 := mul_nonneg_of_nonpos_of_nonpos hx0 hx1
    have h11 : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
    have h22 : 0 ≤ x 2 ^ 2 := sq_nonneg (x 2)
    have h23 : 0 ≤ x 2 * x 3 := mul_nonneg_of_nonpos_of_nonpos hx2 hx3
    have h33 : 0 ≤ x 3 ^ 2 := sq_nonneg (x 3)
    nlinarith [hlarge, h01, h11, h22, h23, h33]

#print axioms verify_unsafe_separation_af26935702e7

end LeanBarrier.Generated
