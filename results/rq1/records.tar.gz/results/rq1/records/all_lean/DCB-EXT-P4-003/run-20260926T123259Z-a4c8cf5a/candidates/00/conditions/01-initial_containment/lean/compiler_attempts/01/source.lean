import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af26935702e76f407aa3e2acaf26ccb9dfbb1ee68554c99dc7923032c9812968
noncomputable def barrier_af26935702e7 (x : LeanBarrier.State 4) : ℝ := ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2))))
@[simp] theorem barrier_unfold_af26935702e7 (x : LeanBarrier.State 4) : barrier_af26935702e7 x = ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) := by
  rfl
def violationSet_initial_containment_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) < (0 : ℝ)))}
def unsafeSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (3 : ℝ)) ∧ (((x 0 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (2 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (2 : ℝ)) ∧ (x 3 ≤ (3 : ℝ))) ∨ ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (-2 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (-2 : ℝ)))))}
def initialSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (5 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_initial_containment_af26935702e7 (hV : ContDiff ℝ 1 barrier_af26935702e7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_initial_containment_af26935702e7 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_initial_containment_af26935702e7, Set.mem_setOf_eq] at hx
  rcases hx with ⟨haL, haU, hbL, hbU, hcL, hcU, hdL, hdU, hneg⟩
  have ha0 : 0 ≤ x 0 := by linarith
  have hb0 : 0 ≤ x 1 := by linarith
  have hc0 : 0 ≤ x 2 := by linarith
  have hd0 : 0 ≤ x 3 := by linarith
  have ha_sq : (x 0) ^ 2 ≤ (16 : ℝ) / 25 := by
    nlinarith [mul_nonneg ha0 (sub_nonneg.mpr haU)]
  have hb_sq : (x 1) ^ 2 ≤ (9 : ℝ) / 25 := by
    nlinarith [mul_nonneg hb0 (sub_nonneg.mpr hbU)]
  have hc_sq : (x 2) ^ 2 ≤ (16 : ℝ) / 25 := by
    nlinarith [mul_nonneg hc0 (sub_nonneg.mpr hcU)]
  have hd_sq : (x 3) ^ 2 ≤ (9 : ℝ) / 25 := by
    nlinarith [mul_nonneg hd0 (sub_nonneg.mpr hdU)]
  have hab : x 0 * x 1 ≤ (12 : ℝ) / 25 := by
    nlinarith [mul_nonneg ha0 (sub_nonneg.mpr hbU)]
  have hcd : x 2 * x 3 ≤ (12 : ℝ) / 25 := by
    nlinarith [mul_nonneg hc0 (sub_nonneg.mpr hdU)]
  nlinarith [ha_sq, hb_sq, hc_sq, hd_sq, hab, hcd]

#print axioms verify_initial_containment_af26935702e7

end LeanBarrier.Generated
