import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af26935702e76f407aa3e2acaf26ccb9dfbb1ee68554c99dc7923032c9812968
noncomputable def barrier_af26935702e7 (x : LeanBarrier.State 4) : ℝ := ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2))))
@[simp] theorem barrier_unfold_af26935702e7 (x : LeanBarrier.State 4) : barrier_af26935702e7 x = ((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) := by
  rfl
def violationSet_lie_strict_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((((8 : ℝ) - ((((27 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)) + (x 0 * x 1) + (((5 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((35 : ℝ) / (12 : ℝ)) * (x 2 ^ 2)) + (((5 : ℝ) / (3 : ℝ)) * x 2 * x 3) + (((40 : ℝ) / (9 : ℝ)) * (x 3 ^ 2)))) = (0 : ℝ)) ∧ ((((-((((27 : ℝ) / (5 : ℝ)) * x 0) + x 1)) * x 1) + ((-(x 0 + ((5 : ℝ) * x 1))) * (((-x 0) - (((2 : ℝ) / (5 : ℝ)) * x 1)) + (((3 : ℝ) / (20 : ℝ)) * Real.sin (x 2)) + (((-3 : ℝ) / (20 : ℝ)) * Real.sin (x 2)))) + ((-((((35 : ℝ) / (6 : ℝ)) * x 2) + (((5 : ℝ) / (3 : ℝ)) * x 3))) * x 3) + ((-((((5 : ℝ) / (3 : ℝ)) * x 2) + (((80 : ℝ) / (9 : ℝ)) * x 3))) * ((((-3 : ℝ) / (5 : ℝ)) * x 2) - (((3 : ℝ) / (10 : ℝ)) * x 3)))) ≤ (0 : ℝ)))}
def unsafeSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (3 : ℝ)) ∧ (((x 0 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (2 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ (x 2 ≥ ((5 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (2 : ℝ)) ∧ (x 3 ≤ (3 : ℝ))) ∨ ((x 0 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ (-2 : ℝ)) ∧ (x 2 ≥ ((-7 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((-5 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ (-3 : ℝ)) ∧ (x 3 ≤ (-2 : ℝ)))))}
def initialSet_af26935702e7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (5 : ℝ))))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_af26935702e7 (hV : ContDiff ℝ 1 barrier_af26935702e7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_af26935702e7 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_strict_af26935702e7, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hB, hL⟩
  ring_nf at hL
  have h0 : x 0 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have h1 : x 1 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have h2 : x 2 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have h3 : x 3 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  norm_num [h0, h1, h2, h3] at hB

#print axioms verify_lie_strict_af26935702e7

end LeanBarrier.Generated
