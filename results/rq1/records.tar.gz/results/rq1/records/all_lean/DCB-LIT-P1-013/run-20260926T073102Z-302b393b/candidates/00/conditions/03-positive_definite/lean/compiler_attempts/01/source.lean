import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 09bc47b62ee48d22c391eb1655d7cc78d982599ed1b492141b9279b243ebfb11
noncomputable def barrier_09bc47b62ee4 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_09bc47b62ee4 (x : LeanBarrier.State 3) : barrier_09bc47b62ee4 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_positive_definite_09bc47b62ee4 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_09bc47b62ee4 (hV : ContDiff ℝ 1 barrier_09bc47b62ee4) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_09bc47b62ee4 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx₀l, hx₀u, hx₁l, hx₁u, hx₂l, hx₂u, hpos, hnonpos⟩
  exact (not_lt_of_ge hnonpos) hpos

#print axioms verify_positive_definite_09bc47b62ee4

end LeanBarrier.Generated
