-- candidate-sha256: 09bc47b62ee48d22c391eb1655d7cc78d982599ed1b492141b9279b243ebfb11
noncomputable def barrier_09bc47b62ee4 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_09bc47b62ee4 (x : LeanBarrier.State 3) : barrier_09bc47b62ee4 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_09bc47b62ee4 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((((((-3 : ℝ) * (x 0 ^ 3)) + ((3 : ℝ) * x 0 * x 2)) - ((9 : ℝ) * x 0)) > (0 : ℝ))) ∨ ((((((-3 : ℝ) * (x 0 ^ 3)) + ((3 : ℝ) * x 0 * x 2)) - ((9 : ℝ) * x 0)) < (0 : ℝ))) ∨ (((((-(x 0 ^ 3)) - ((5 : ℝ) * x 1)) + ((5 : ℝ) * (x 2 ^ 3))) > (0 : ℝ))) ∨ (((((-(x 0 ^ 3)) - ((5 : ℝ) * x 1)) + ((5 : ℝ) * (x 2 ^ 3))) < (0 : ℝ))) ∨ ((((-9 : ℝ) * (x 2 ^ 3)) > (0 : ℝ))) ∨ ((((-9 : ℝ) * (x 2 ^ 3)) < (0 : ℝ)))))}

theorem verify_equilibrium_fixed_09bc47b62ee4 (hV : ContDiff ℝ 1 barrier_09bc47b62ee4) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_09bc47b62ee4
