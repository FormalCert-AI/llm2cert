import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 09bc47b62ee48d22c391eb1655d7cc78d982599ed1b492141b9279b243ebfb11
noncomputable def barrier_09bc47b62ee4 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_09bc47b62ee4 (x : LeanBarrier.State 3) : barrier_09bc47b62ee4 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_lie_negative_09bc47b62ee4 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * ((((-3 : ℝ) * (x 0 ^ 3)) + ((3 : ℝ) * x 0 * x 2)) - ((9 : ℝ) * x 0))) + ((2 : ℝ) * x 1 * (((-(x 0 ^ 3)) - ((5 : ℝ) * x 1)) + ((5 : ℝ) * (x 2 ^ 3)))) + ((-18 : ℝ) * x 2 * (x 2 ^ 3))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_09bc47b62ee4

end LeanBarrier.Generated
