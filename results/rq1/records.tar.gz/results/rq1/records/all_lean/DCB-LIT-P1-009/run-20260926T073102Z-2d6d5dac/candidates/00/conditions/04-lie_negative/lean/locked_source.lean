-- candidate-sha256: c6a6753ccfc6e476b4cc5c9c011c4648964c7382658c2282b3be19bf3e93ca41
noncomputable def barrier_c6a6753ccfc6 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + ((3 : ℝ) * (x 1 ^ 2)))
@[simp] theorem barrier_unfold_c6a6753ccfc6 (x : LeanBarrier.State 2) : barrier_c6a6753ccfc6 x = ((x 0 ^ 2) + ((3 : ℝ) * (x 1 ^ 2))) := by
  rfl
def violationSet_lie_negative_c6a6753ccfc6 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-10 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (-10 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (100 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * ((-x 0) - (((3 : ℝ) / (2 : ℝ)) * (x 0 ^ 2) * (x 1 ^ 3)))) + ((6 : ℝ) * x 1 * ((-(x 1 ^ 3)) + (((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 3) * (x 1 ^ 2))))) ≥ (0 : ℝ)))}

theorem verify_lie_negative_c6a6753ccfc6 (hV : ContDiff ℝ 1 barrier_c6a6753ccfc6) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_c6a6753ccfc6
