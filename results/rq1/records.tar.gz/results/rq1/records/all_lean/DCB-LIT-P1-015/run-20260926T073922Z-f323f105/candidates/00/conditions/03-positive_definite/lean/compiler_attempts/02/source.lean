import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af420dcfc7754c005e7d32030041586a14f4e246851590a4ddec1f0a09a3ba6a
noncomputable def barrier_af420dcfc775 (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2)))
@[simp] theorem barrier_unfold_af420dcfc775 (x : LeanBarrier.State 3) : barrier_af420dcfc775 x = (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) := by
  rfl
def violationSet_positive_definite_af420dcfc775 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ (-2 : ℝ)) ∧ (x 2 ≤ (2 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_af420dcfc775 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨_, _, _, _, _, _, hnorm, hnonpos⟩
  have hcos : 0 ≤ (1 : ℝ) - Real.cos (x 0) :=
    sub_nonneg.mpr (Real.cos_le_one (x 0))
  have hq_sq : 0 ≤ (x 0) ^ 2 := sq_nonneg (x 0)
  have hcombo_sq : 0 ≤ (x 1 - x 2 + x 0 / 2) ^ 2 :=
    sq_nonneg (x 1 - x 2 + x 0 / 2)
  have hsum_sq : 0 ≤ (x 1 + x 2) ^ 2 :=
    sq_nonneg (x 1 + x 2)
  have hq_nonpos : (x 0) ^ 2 ≤ 0 := by
    nlinarith [hcos, hq_sq, hcombo_sq, hsum_sq]
  have hcombo_nonpos : (x 1 - x 2 + x 0 / 2) ^ 2 ≤ 0 := by
    nlinarith [hcos, hq_sq, hcombo_sq, hsum_sq]
  have hsum_nonpos : (x 1 + x 2) ^ 2 ≤ 0 := by
    nlinarith [hcos, hq_sq, hcombo_sq, hsum_sq]
  have hq : x 0 = 0 := by
    nlinarith [hq_sq, hq_nonpos]
  have hcombo : x 1 - x 2 + x 0 / 2 = 0 := by
    nlinarith [hcombo_sq, hcombo_nonpos]
  have hsum : x 1 + x 2 = 0 := by
    nlinarith [hsum_sq, hsum_nonpos]
  have hdiff : x 1 - x 2 = 0 := by
    linarith
  have hx1 : x 1 = 0 := by
    linarith
  have hx2 : x 2 = 0 := by
    linarith
  nlinarith

#print axioms verify_positive_definite_af420dcfc775

end LeanBarrier.Generated
