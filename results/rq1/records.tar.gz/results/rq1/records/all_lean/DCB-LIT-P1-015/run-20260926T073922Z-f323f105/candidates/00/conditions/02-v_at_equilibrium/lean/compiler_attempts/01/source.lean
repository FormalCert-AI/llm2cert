import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af420dcfc7754c005e7d32030041586a14f4e246851590a4ddec1f0a09a3ba6a
noncomputable def barrier_af420dcfc775 (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2)))
@[simp] theorem barrier_unfold_af420dcfc775 (x : LeanBarrier.State 3) : barrier_af420dcfc775 x = (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) := by
  rfl
def violationSet_v_at_equilibrium_af420dcfc775 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ ((((((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) > (0 : ℝ))) ∨ (((((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_v_at_equilibrium_af420dcfc775 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_af420dcfc775, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0, hx1, hx2, hbad⟩
  norm_num [hx0, hx1, hx2] at hbad

#print axioms verify_v_at_equilibrium_af420dcfc775

end LeanBarrier.Generated
