import LeanBarrier

#check Real.sin
#check Real.sin_bound
#check Real.one_sub_cos_le
