import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af420dcfc7754c005e7d32030041586a14f4e246851590a4ddec1f0a09a3ba6a
noncomputable def barrier_af420dcfc775 (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2)))
@[simp] theorem barrier_unfold_af420dcfc775 (x : LeanBarrier.State 3) : barrier_af420dcfc775 x = (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) := by
  rfl
def violationSet_lie_negative_af420dcfc775 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ (-2 : ℝ)) ∧ (x 2 ≤ (2 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((Real.sin (x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 - x 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0)) * (x 1 - x 2)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) + (((1 : ℝ) / (2 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 + x 2))) * ((((-1 : ℝ) - ((2 : ℝ) * x 1)) - Real.sin (x 0)) + Real.cos (x 0))) + (((1 : ℝ) / (2 : ℝ)) * (((-1 : ℝ) * (x 1 - x 2)) + (((-1 : ℝ) / (2 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 + x 2))) * (((-1 : ℝ) - ((2 : ℝ) * x 2)) + Real.sin (x 0) + Real.cos (x 0)))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_af420dcfc775 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_af420dcfc775, Set.mem_setOf_eq] at hx
  set q : ℝ := x 0 with hq
  set w1 : ℝ := x 1 with hw1
  set w2 : ℝ := x 2 with hw2
  rcases hx with ⟨hqlo, hqhi, _hw1lo, _hw1hi, _hw2lo, _hw2hi, haway, hD⟩
  let a : ℝ := w1 - w2
  let s : ℝ := w1 + w2
  let h : ℝ := 1 - Real.cos q
  have hq2 : q ^ 2 ≤ (9 : ℝ) / 4 := by
    have hp : 0 ≤ (q + (3 : ℝ) / 2) * ((3 : ℝ) / 2 - q) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith
  have hq4 : q ^ 4 ≤ ((9 : ℝ) / 4) * q ^ 2 := by
    have hp : 0 ≤ ((9 : ℝ) / 4 - q ^ 2) * q ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg q)
    nlinarith
  let t : ℝ := q / 2
  have htlo : -(3 : ℝ) / 4 ≤ t := by
    dsimp [t]
    linarith
  have hthi : t ≤ (3 : ℝ) / 4 := by
    dsimp [t]
    linarith
  have habst : |t| ≤ 1 := by
    rw [abs_le]
    constructor <;> linarith
  have ht2 : t ^ 2 ≤ (9 : ℝ) / 16 := by
    have hp : 0 ≤ (t + (3 : ℝ) / 4) * ((3 : ℝ) / 4 - t) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith
  have ht4 : t ^ 4 ≤ ((9 : ℝ) / 16) * t ^ 2 := by
    have hp : 0 ≤ ((9 : ℝ) / 16 - t ^ 2) * t ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg t)
    nlinarith
  have ht6 : t ^ 6 ≤ ((81 : ℝ) / 256) * t ^ 2 := by
    have hp : 0 ≤ ((9 : ℝ) / 16 - t ^ 2) * t ^ 4 :=
      mul_nonneg (by linarith) (sq_nonneg (t ^ 2))
    nlinarith [ht4]
  have hsinerr :
      |Real.sin t - (t - t ^ 3 / 6)| ≤ |t| ^ 5 / 100 :=
    Real.sin_bound habst
  have htsin : ((9 : ℝ) / 10) * t ^ 2 ≤ t * Real.sin t := by
    by_cases ht0 : 0 ≤ t
    · rw [abs_of_nonneg ht0] at hsinerr
      have herr : -(t ^ 5 / 100) ≤ Real.sin t - (t - t ^ 3 / 6) :=
        (abs_le.mp hsinerr).1
      have hp :
          0 ≤ t * (Real.sin t - (t - t ^ 3 / 6) + t ^ 5 / 100) :=
        mul_nonneg ht0 (by linarith)
      nlinarith [ht4, ht6]
    · have ht0' : t ≤ 0 := le_of_not_ge ht0
      rw [abs_of_nonpos ht0'] at hsinerr
      have herr :
          Real.sin t - (t - t ^ 3 / 6) ≤ (-t) ^ 5 / 100 :=
        (abs_le.mp hsinerr).2
      have hp := mul_le_mul_of_nonpos_left herr ht0'
      nlinarith [ht4, ht6]
  have hcos : (23 : ℝ) / 32 ≤ Real.cos t := by
    have hc := Real.one_sub_sq_div_two_le_cos (x := t)
    nlinarith [ht2]
  have htsin0 : 0 ≤ t * Real.sin t := by
    nlinarith [htsin, sq_nonneg t]
  have hprod :
      (((9 : ℝ) / 10) * t ^ 2) * ((23 : ℝ) / 32) ≤
        (t * Real.sin t) * Real.cos t := by
    exact mul_le_mul htsin hcos (by norm_num) htsin0
  have hqt : q = 2 * t := by
    dsimp [t]
    ring
  have hsindouble : Real.sin q = 2 * Real.sin t * Real.cos t := by
    rw [hqt, Real.sin_two_mul]
  have hqsin : ((5 : ℝ) / 8) * q ^ 2 ≤ q * Real.sin q := by
    nlinarith [hprod, hqt, hsindouble]
  have hh0 : 0 ≤ h := by
    dsimp [h]
    linarith [Real.cos_le_one q]
  have hhupper : h ≤ q ^ 2 / 2 := by
    dsimp [h]
    linarith [Real.one_sub_sq_div_two_le_cos (x := q)]
  have hhfac : 0 ≤ (q ^ 2 / 2 - h) * (q ^ 2 / 2 + h) := by
    apply mul_nonneg
    · linarith
    · nlinarith [sq_nonneg q]
  have hhsq : h ^ 2 ≤ q ^ 4 / 4 := by
    nlinarith [hhfac]
  have hhqsin : h ^ 2 ≤ ((9 : ℝ) / 10) * (q * Real.sin q) := by
    nlinarith [hhsq, hq4, hqsin]
  have hyoung :
      -((1 : ℝ) / 2) * s * h ≤
        ((1 : ℝ) / 4) * s ^ 2 + ((1 : ℝ) / 4) * h ^ 2 := by
    nlinarith [sq_nonneg (s + h)]
  have hDsimple :
      -((1 : ℝ) / 2) * a ^ 2
          - ((1 : ℝ) / 2) * q * Real.sin q
          - ((1 : ℝ) / 2) * s ^ 2
          - ((1 : ℝ) / 2) * s * h ≥ 0 := by
    dsimp [a, s, h]
    nlinarith [hD]
  have hpos : 0 < q ^ 2 + a ^ 2 + s ^ 2 := by
    dsimp [a, s]
    nlinarith [haway, sq_nonneg w1, sq_nonneg w2]
  nlinarith [hDsimple, hyoung, hhqsin, hqsin, hpos,
    sq_nonneg a, sq_nonneg s, sq_nonneg q]

#print axioms verify_lie_negative_af420dcfc775

end LeanBarrier.Generated
