import LeanBarrier

#check Real.cos
#check Real.cos_le_one
