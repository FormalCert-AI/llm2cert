import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: af420dcfc7754c005e7d32030041586a14f4e246851590a4ddec1f0a09a3ba6a
noncomputable def barrier_af420dcfc775 (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2)))
@[simp] theorem barrier_unfold_af420dcfc775 (x : LeanBarrier.State 3) : barrier_af420dcfc775 x = (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) := by
  rfl
def violationSet_lie_negative_af420dcfc775 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ (-2 : ℝ)) ∧ (x 2 ≤ (2 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((Real.sin (x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 - x 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0)) * (x 1 - x 2)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) + (((1 : ℝ) / (2 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 + x 2))) * ((((-1 : ℝ) - ((2 : ℝ) * x 1)) - Real.sin (x 0)) + Real.cos (x 0))) + (((1 : ℝ) / (2 : ℝ)) * (((-1 : ℝ) * (x 1 - x 2)) + (((-1 : ℝ) / (2 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * (x 1 + x 2))) * (((-1 : ℝ) - ((2 : ℝ) * x 2)) + Real.sin (x 0) + Real.cos (x 0)))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_af420dcfc775

end LeanBarrier.Generated
