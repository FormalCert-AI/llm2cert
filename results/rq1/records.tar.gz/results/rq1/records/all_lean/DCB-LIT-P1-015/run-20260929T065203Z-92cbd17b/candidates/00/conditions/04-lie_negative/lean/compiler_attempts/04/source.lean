import LeanBarrier

#check Real.sin_two_mul
