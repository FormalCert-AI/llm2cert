import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: af420dcfc7754c005e7d32030041586a14f4e246851590a4ddec1f0a09a3ba6a
noncomputable def barrier_af420dcfc775 (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2)))
@[simp] theorem barrier_unfold_af420dcfc775 (x : LeanBarrier.State 3) : barrier_af420dcfc775 x = (((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) := by
  rfl
def violationSet_positive_definite_af420dcfc775 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ (-2 : ℝ)) ∧ (x 2 ≤ (2 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((1 : ℝ) - Real.cos (x 0)) + (((1 : ℝ) / (2 : ℝ)) * ((x 1 - x 2) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * x 0 * (x 1 - x 2)) + (((1 : ℝ) / (4 : ℝ)) * (x 0 ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * ((x 1 + x 2) ^ 2))) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_af420dcfc775 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_positive_definite_af420dcfc775, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hqlo, hqhi, hw1lo, hw1hi, hw2lo, hw2hi, hnorm, hbad⟩
  have hcos : 0 ≤ (1 : ℝ) - Real.cos (x 0) := by
    linarith [Real.cos_le_one (x 0)]
  have hcomp : 0 ≤ ((x 1 - x 2) + (x 0) / 2) ^ 2 := sq_nonneg _
  have hsum : 0 ≤ (x 1 + x 2) ^ 2 := sq_nonneg _
  have hq2le : (x 0) ^ 2 ≤ 0 := by
    nlinarith [hbad, hcos, hcomp, hsum]
  have hq2 : (x 0) ^ 2 = 0 :=
    le_antisymm hq2le (sq_nonneg (x 0))
  have hq : x 0 = 0 := by
    have hp : x 0 * x 0 = 0 := by
      simpa only [pow_two] using hq2
    rcases mul_eq_zero.mp hp with hp | hp
    · exact hp
    · exact hp
  have hbad' := hbad
  simp [hq] at hbad'
  have hdiff2le : (x 1 - x 2) ^ 2 ≤ 0 := by
    nlinarith [hbad', sq_nonneg (x 1 + x 2)]
  have hsum2le : (x 1 + x 2) ^ 2 ≤ 0 := by
    nlinarith [hbad', sq_nonneg (x 1 - x 2)]
  have hdiff2 : (x 1 - x 2) ^ 2 = 0 :=
    le_antisymm hdiff2le (sq_nonneg (x 1 - x 2))
  have hsum2 : (x 1 + x 2) ^ 2 = 0 :=
    le_antisymm hsum2le (sq_nonneg (x 1 + x 2))
  have hdiff : x 1 - x 2 = 0 := by
    have hp : (x 1 - x 2) * (x 1 - x 2) = 0 := by
      simpa only [pow_two] using hdiff2
    rcases mul_eq_zero.mp hp with hp | hp
    · exact hp
    · exact hp
  have hadd : x 1 + x 2 = 0 := by
    have hp : (x 1 + x 2) * (x 1 + x 2) = 0 := by
      simpa only [pow_two] using hsum2
    rcases mul_eq_zero.mp hp with hp | hp
    · exact hp
    · exact hp
  have hw1 : x 1 = 0 := by
    linarith [hdiff, hadd]
  have hw2 : x 2 = 0 := by
    linarith [hdiff, hadd]
  norm_num [hq, hw1, hw2] at hnorm

#print axioms verify_positive_definite_af420dcfc775

end LeanBarrier.Generated
