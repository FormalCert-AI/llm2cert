import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c27561229984f52733aeb4b895521a1744ba5e759b8602d6519f7db39920afef
noncomputable def barrier_c27561229984 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_c27561229984 (x : LeanBarrier.State 2) : barrier_c27561229984 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_c27561229984 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ ((((((((687 : ℝ) / (1000 : ℝ)) * x 0) + (((279 : ℝ) / (500 : ℝ)) * x 1)) - (((1 : ℝ) / (10000 : ℝ)) * x 0 * x 1)) > (0 : ℝ))) ∨ (((((((687 : ℝ) / (1000 : ℝ)) * x 0) + (((279 : ℝ) / (500 : ℝ)) * x 1)) - (((1 : ℝ) / (10000 : ℝ)) * x 0 * x 1)) < (0 : ℝ))) ∨ ((((((-73 : ℝ) / (250 : ℝ)) * x 0) + (((773 : ℝ) / (1000 : ℝ)) * x 1)) > (0 : ℝ))) ∨ ((((((-73 : ℝ) / (250 : ℝ)) * x 0) + (((773 : ℝ) / (1000 : ℝ)) * x 1)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_c27561229984 (hV : ContDiff ℝ 1 barrier_c27561229984) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_c27561229984 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, hbad⟩
  norm_num [h0, h1] at hbad

#print axioms verify_equilibrium_fixed_c27561229984

end LeanBarrier.Generated
