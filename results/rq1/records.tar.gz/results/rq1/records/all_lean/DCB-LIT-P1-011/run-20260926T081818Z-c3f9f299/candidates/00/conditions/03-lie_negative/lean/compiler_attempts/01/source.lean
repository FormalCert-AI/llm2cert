import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c27561229984f52733aeb4b895521a1744ba5e759b8602d6519f7db39920afef
noncomputable def barrier_c27561229984 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_c27561229984 (x : LeanBarrier.State 2) : barrier_c27561229984 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_c27561229984 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ (((((((((687 : ℝ) / (1000 : ℝ)) * x 0) + (((279 : ℝ) / (500 : ℝ)) * x 1)) - (((1 : ℝ) / (10000 : ℝ)) * x 0 * x 1)) ^ 2) + (((((-73 : ℝ) / (250 : ℝ)) * x 0) + (((773 : ℝ) / (1000 : ℝ)) * x 1)) ^ 2)) - ((x 0 ^ 2) + (x 1 ^ 2))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_c27561229984 (hV : ContDiff ℝ 1 barrier_c27561229984) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_c27561229984 := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_lie_negative_c27561229984] at hx
  rcases hx with ⟨haL, haU, hbL, hbU, hsU, hsPos, hdelta⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let g : ℝ := (687 : ℝ) / 1000 * a + (279 : ℝ) / 500 * b
  let z : ℝ := (-73 : ℝ) / 250 * a + (773 : ℝ) / 1000 * b
  have haL' : (-1 : ℝ) ≤ a := by
    simpa [a] using haL
  have haU' : a ≤ (1 : ℝ) := by
    simpa [a] using haU
  have hbL' : (-1 : ℝ) ≤ b := by
    simpa [b] using hbL
  have hbU' : b ≤ (1 : ℝ) := by
    simpa [b] using hbU
  have hsPos' : 0 < a ^ 2 + b ^ 2 := by
    simpa [a, b] using hsPos
  have hdelta' :
      0 ≤ (g - (1 : ℝ) / 10000 * a * b) ^ 2 + z ^ 2 - (a ^ 2 + b ^ 2) := by
    simpa [g, z, a, b] using hdelta
  have ha0 : 0 ≤ a ^ 2 := sq_nonneg a
  have hb0 : 0 ≤ b ^ 2 := sq_nonneg b
  have hb2le : b ^ 2 ≤ (1 : ℝ) := by
    have hfac : 0 ≤ (1 - b) * (1 + b) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith [hfac]
  have hposA : 0 ≤ a ^ 2 * (b + 1) := by
    apply mul_nonneg ha0
    linarith
  have hposB : 0 ≤ b ^ 2 * (a + 1) := by
    apply mul_nonneg hb0
    linarith
  have hquart : 0 ≤ a ^ 2 * (1 - b ^ 2) := by
    exact mul_nonneg ha0 (sub_nonneg.mpr hb2le)
  have hcubicA : -(a ^ 2 * b) ≤ a ^ 2 := by
    nlinarith [hposA]
  have hcubicB : -(a * b ^ 2) ≤ b ^ 2 := by
    nlinarith [hposB]
  have hquartic : a ^ 2 * b ^ 2 ≤ a ^ 2 := by
    nlinarith [hquart]
  let q : ℝ :=
    (442767 : ℝ) / 1000000 * a ^ 2
      - (315260 : ℝ) / 1000000 * a * b
      + (91107 : ℝ) / 1000000 * b ^ 2
  have hcert :
      (412767 : ℝ) *
          ((412767 : ℝ) * a ^ 2 - (315260 : ℝ) * a * b +
            (61107 : ℝ) * b ^ 2) =
        ((412767 : ℝ) * a - (157630 : ℝ) * b) ^ 2 +
          (375736169 : ℝ) * b ^ 2 := by
    ring
  have hrhs :
      0 ≤ ((412767 : ℝ) * a - (157630 : ℝ) * b) ^ 2 +
        (375736169 : ℝ) * b ^ 2 := by
    exact add_nonneg (sq_nonneg _) (mul_nonneg (by norm_num) hb0)
  have hP :
      0 ≤ (412767 : ℝ) * a ^ 2 - (315260 : ℝ) * a * b +
        (61107 : ℝ) * b ^ 2 := by
    nlinarith [hcert, hrhs]
  have hQ : (3 : ℝ) / 100 * (a ^ 2 + b ^ 2) ≤ q := by
    dsimp [q]
    nlinarith [hP]
  let r : ℝ :=
    -(a * b / 5000) * g + a ^ 2 * b ^ 2 / 100000000
  have hrem : r ≤ (7 : ℝ) / 50000 * (a ^ 2 + b ^ 2) := by
    dsimp [r, g]
    nlinarith [hcubicA, hcubicB, hquartic, ha0, hb0]
  have hid :
      (g - (1 : ℝ) / 10000 * a * b) ^ 2 + z ^ 2 -
          (a ^ 2 + b ^ 2) =
        -q + r := by
    dsimp [g, z, q, r]
    ring
  nlinarith [hdelta', hid, hQ, hrem, hsPos']

#print axioms verify_lie_negative_c27561229984

end LeanBarrier.Generated
