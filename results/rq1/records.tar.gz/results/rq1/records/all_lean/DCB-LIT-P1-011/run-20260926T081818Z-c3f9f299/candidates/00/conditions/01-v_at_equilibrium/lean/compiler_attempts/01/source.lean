import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c27561229984f52733aeb4b895521a1744ba5e759b8602d6519f7db39920afef
noncomputable def barrier_c27561229984 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_c27561229984 (x : LeanBarrier.State 2) : barrier_c27561229984 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_c27561229984 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_c27561229984 (hV : ContDiff ℝ 1 barrier_c27561229984) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_c27561229984 := by
  rintro ⟨x, hx⟩
  change
    x 0 = (0 : ℝ) ∧ x 1 = (0 : ℝ) ∧
      ((x 0 ^ 2 + x 1 ^ 2 > 0) ∨ (x 0 ^ 2 + x 1 ^ 2 < 0)) at hx
  rcases hx with ⟨h0, h1, h⟩
  simp [h0, h1] at h

#print axioms verify_v_at_equilibrium_c27561229984

end LeanBarrier.Generated
