-- candidate-sha256: b9f085dc0472ee68e691186a6769739dcad3c038c1b41b3c6802b41a87679fb2
noncomputable def barrier_b9f085dc0472 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_b9f085dc0472 (x : LeanBarrier.State 3) : barrier_b9f085dc0472 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_lie_negative_b9f085dc0472 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (0 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (x 0 ≥ (0 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * (((-3 : ℝ) * x 0) - (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 3)))) + ((2 : ℝ) * x 1 * ((-x 1) + x 2)) + ((2 : ℝ) * x 2 * (-x 2))) ≥ (0 : ℝ)))}

theorem verify_lie_negative_b9f085dc0472 (hV : ContDiff ℝ 1 barrier_b9f085dc0472) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_b9f085dc0472
