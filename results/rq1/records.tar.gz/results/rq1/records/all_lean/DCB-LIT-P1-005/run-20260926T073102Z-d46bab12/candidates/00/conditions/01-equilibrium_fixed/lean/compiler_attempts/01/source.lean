import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: b9f085dc0472ee68e691186a6769739dcad3c038c1b41b3c6802b41a87679fb2
noncomputable def barrier_b9f085dc0472 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_b9f085dc0472 (x : LeanBarrier.State 3) : barrier_b9f085dc0472 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_b9f085dc0472 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ ((((((-3 : ℝ) * x 0) - (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 3))) > (0 : ℝ))) ∨ (((((-3 : ℝ) * x 0) - (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 3))) < (0 : ℝ))) ∨ ((((-x 1) + x 2) > (0 : ℝ))) ∨ ((((-x 1) + x 2) < (0 : ℝ))) ∨ (((-x 2) > (0 : ℝ))) ∨ (((-x 2) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_b9f085dc0472 (hV : ContDiff ℝ 1 barrier_b9f085dc0472) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_b9f085dc0472 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_equilibrium_fixed_b9f085dc0472, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0, hx1, hx2, hbad⟩
  norm_num [hx0, hx1, hx2] at hbad

#print axioms verify_equilibrium_fixed_b9f085dc0472

end LeanBarrier.Generated
