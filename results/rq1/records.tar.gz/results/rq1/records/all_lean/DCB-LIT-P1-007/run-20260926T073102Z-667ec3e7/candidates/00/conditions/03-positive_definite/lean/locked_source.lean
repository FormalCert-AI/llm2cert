-- candidate-sha256: 1fa5b18838e747e5956ed6c32c11f8dac4d8d9cdbc671800462aa6bd4b7d197e
noncomputable def barrier_1fa5b18838e7 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_1fa5b18838e7 (x : LeanBarrier.State 2) : barrier_1fa5b18838e7 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_1fa5b18838e7 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-10 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (-10 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (100 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (0 : ℝ)))}

theorem verify_positive_definite_1fa5b18838e7 (hV : ContDiff ℝ 1 barrier_1fa5b18838e7) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_1fa5b18838e7
