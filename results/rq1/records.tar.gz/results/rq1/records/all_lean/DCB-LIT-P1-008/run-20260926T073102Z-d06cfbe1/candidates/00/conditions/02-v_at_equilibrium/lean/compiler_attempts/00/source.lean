import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 4da057cf5b68d97b08ee9149e409a825cd076910fb4cb38b4f7ef631b101f265
noncomputable def barrier_4da057cf5b68 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_4da057cf5b68 (x : LeanBarrier.State 2) : barrier_4da057cf5b68 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_4da057cf5b68 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2)) < (0 : ℝ)))))}

#print axioms barrier_unfold_4da057cf5b68

end LeanBarrier.Generated
