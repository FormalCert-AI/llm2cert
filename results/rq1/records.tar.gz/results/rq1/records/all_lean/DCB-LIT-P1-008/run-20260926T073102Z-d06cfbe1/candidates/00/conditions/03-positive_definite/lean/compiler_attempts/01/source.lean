import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 4da057cf5b68d97b08ee9149e409a825cd076910fb4cb38b4f7ef631b101f265
noncomputable def barrier_4da057cf5b68 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_4da057cf5b68 (x : LeanBarrier.State 2) : barrier_4da057cf5b68 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_4da057cf5b68 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-10 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (-10 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (100 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_4da057cf5b68 (hV : ContDiff ℝ 1 barrier_4da057cf5b68) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_4da057cf5b68 := by
  rintro ⟨x, hx⟩
  change
    x 0 ≥ (-10 : ℝ) ∧
      x 0 ≤ (10 : ℝ) ∧
      x 1 ≥ (-10 : ℝ) ∧
      x 1 ≤ (10 : ℝ) ∧
      x 0 ^ 2 + x 1 ^ 2 ≤ (100 : ℝ) ∧
      x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ) ∧
      x 0 ^ 2 + x 1 ^ 2 ≤ (0 : ℝ) at hx
  rcases hx with ⟨_, _, _, _, _, hpos, hnonpos⟩
  exact (not_lt_of_ge hnonpos) hpos

#print axioms verify_positive_definite_4da057cf5b68

end LeanBarrier.Generated
