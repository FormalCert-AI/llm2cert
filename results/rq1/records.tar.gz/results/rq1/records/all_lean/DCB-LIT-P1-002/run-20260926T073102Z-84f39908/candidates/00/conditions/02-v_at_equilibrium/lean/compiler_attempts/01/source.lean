import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: b08e99e380901b5980fe2eb801ddcf98ec5e9c34f5c57fa13afc2acdfdb13c9d
noncomputable def barrier_b08e99e38090 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_b08e99e38090 (x : LeanBarrier.State 2) : barrier_b08e99e38090 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_b08e99e38090 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_b08e99e38090 (hV : ContDiff ℝ 1 barrier_b08e99e38090) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_b08e99e38090 := by
  rintro ⟨x, hx⟩
  change x 0 = (0 : ℝ) ∧ x 1 = (0 : ℝ) ∧
    (x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ) ∨ x 0 ^ 2 + x 1 ^ 2 < (0 : ℝ)) at hx
  rcases hx with ⟨hx0, hx1, hx⟩
  norm_num [hx0, hx1] at hx

#print axioms verify_v_at_equilibrium_b08e99e38090

end LeanBarrier.Generated
