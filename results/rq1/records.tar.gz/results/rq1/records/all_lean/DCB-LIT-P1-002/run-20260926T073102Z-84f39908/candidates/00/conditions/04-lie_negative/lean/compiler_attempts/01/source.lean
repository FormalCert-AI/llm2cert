import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: b08e99e380901b5980fe2eb801ddcf98ec5e9c34f5c57fa13afc2acdfdb13c9d
noncomputable def barrier_b08e99e38090 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_b08e99e38090 (x : LeanBarrier.State 2) : barrier_b08e99e38090 x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_b08e99e38090 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((2 : ℝ) * x 0 * ((-x 0) + (x 0 * x 1))) + ((2 : ℝ) * x 1 * (-x 1))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_b08e99e38090 (hV : ContDiff ℝ 1 barrier_b08e99e38090) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_b08e99e38090 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_b08e99e38090, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0_lower, hx0_upper, hx1_lower, hx1_upper, hV_upper, hV_pos, hD⟩
  by_cases hz : x 1 = 0
  · rw [hz] at hV_pos hD
    norm_num at hV_pos hD
    nlinarith [sq_nonneg (x 0)]
  · have ha : 0 ≤ 1 - x 1 := by
      linarith
    have hprod : 0 ≤ (x 0) ^ 2 * (1 - x 1) :=
      mul_nonneg (sq_nonneg (x 0)) ha
    have hsq_pos : 0 < (x 1) ^ 2 := sq_pos_of_ne_zero hz
    nlinarith [hprod, hsq_pos]

#print axioms verify_lie_negative_b08e99e38090

end LeanBarrier.Generated
