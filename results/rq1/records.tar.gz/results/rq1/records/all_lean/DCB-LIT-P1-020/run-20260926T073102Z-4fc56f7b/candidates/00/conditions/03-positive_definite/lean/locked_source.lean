-- candidate-sha256: 6dc13b97f0f7bee62506b9cac31e802f1a718a0630e178d678d372486ac99180
noncomputable def barrier_6dc13b97f0f7 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_6dc13b97f0f7 (x : LeanBarrier.State 3) : barrier_6dc13b97f0f7 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_positive_definite_6dc13b97f0f7 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (0 : ℝ)))}

theorem verify_positive_definite_6dc13b97f0f7 (hV : ContDiff ℝ 1 barrier_6dc13b97f0f7) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_6dc13b97f0f7
