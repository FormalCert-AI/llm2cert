import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: 6dc13b97f0f7bee62506b9cac31e802f1a718a0630e178d678d372486ac99180
noncomputable def barrier_6dc13b97f0f7 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_6dc13b97f0f7 (x : LeanBarrier.State 3) : barrier_6dc13b97f0f7 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_6dc13b97f0f7 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ ((((((-8 : ℝ) * x 0 * (x 1 ^ 2)) - ((10 : ℝ) * (x 1 ^ 4))) > (0 : ℝ))) ∨ (((((-8 : ℝ) * x 0 * (x 1 ^ 2)) - ((10 : ℝ) * (x 1 ^ 4))) < (0 : ℝ))) ∨ ((((((-8 : ℝ) * (x 1 ^ 3)) + ((3 : ℝ) * (x 1 ^ 2))) - ((8 : ℝ) * x 1)) > (0 : ℝ))) ∨ ((((((-8 : ℝ) * (x 1 ^ 3)) + ((3 : ℝ) * (x 1 ^ 2))) - ((8 : ℝ) * x 1)) < (0 : ℝ))) ∨ (((-x 2) > (0 : ℝ))) ∨ (((-x 2) < (0 : ℝ)))))}

#print axioms barrier_unfold_6dc13b97f0f7

end LeanBarrier.Generated
