import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 6dc13b97f0f7bee62506b9cac31e802f1a718a0630e178d678d372486ac99180
noncomputable def barrier_6dc13b97f0f7 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_6dc13b97f0f7 (x : LeanBarrier.State 3) : barrier_6dc13b97f0f7 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_6dc13b97f0f7 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_6dc13b97f0f7 (hV : ContDiff ℝ 1 barrier_6dc13b97f0f7) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_v_at_equilibrium_6dc13b97f0f7 := by
  rintro ⟨x, hx0, hx1, hx2, hpos | hneg⟩
  · norm_num [hx0, hx1, hx2] at hpos
  · norm_num [hx0, hx1, hx2] at hneg

#print axioms verify_v_at_equilibrium_6dc13b97f0f7

end LeanBarrier.Generated
