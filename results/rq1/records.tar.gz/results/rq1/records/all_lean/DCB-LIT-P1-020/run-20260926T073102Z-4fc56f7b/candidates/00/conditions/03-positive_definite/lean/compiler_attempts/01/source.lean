import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 6dc13b97f0f7bee62506b9cac31e802f1a718a0630e178d678d372486ac99180
noncomputable def barrier_6dc13b97f0f7 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))
@[simp] theorem barrier_unfold_6dc13b97f0f7 (x : LeanBarrier.State 3) : barrier_6dc13b97f0f7 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) := by
  rfl
def violationSet_positive_definite_6dc13b97f0f7 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_6dc13b97f0f7 (hV : ContDiff ℝ 1 barrier_6dc13b97f0f7) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_6dc13b97f0f7 := by
  rintro ⟨x, hx⟩
  change
    (x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧
    (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧
    (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧
    (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧
    (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (0 : ℝ)) at hx
  rcases hx with ⟨_, _, _, _, _, _, hpos, hnonpos⟩
  exact (not_lt_of_ge hnonpos) hpos

#print axioms verify_positive_definite_6dc13b97f0f7

end LeanBarrier.Generated
