import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 8fe286fd6b8f522fcf2fc746f75c3fba4432d504347490b711b052820d6bed03
noncomputable def barrier_8fe286fd6b8f (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_8fe286fd6b8f (x : LeanBarrier.State 2) : barrier_8fe286fd6b8f x = (((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl
def violationSet_positive_definite_8fe286fd6b8f : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (0 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (100 : ℝ)) ∧ (x 0 ≥ (0 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2)) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_8fe286fd6b8f (hV : ContDiff ℝ 1 barrier_8fe286fd6b8f) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_8fe286fd6b8f := by
  rintro ⟨x, hx⟩
  change
    (x 0 ≥ (0 : ℝ)) ∧
      (x 0 ≤ (10 : ℝ)) ∧
      (x 1 ≥ (0 : ℝ)) ∧
      (x 1 ≤ (10 : ℝ)) ∧
      ((x 0 ^ 2) + (x 1 ^ 2) ≤ (100 : ℝ)) ∧
      (x 0 ≥ (0 : ℝ)) ∧
      (x 1 ≥ (0 : ℝ)) ∧
      ((x 0 ^ 2) + (x 1 ^ 2) > (0 : ℝ)) ∧
      (((x 0 ^ 2) * Real.exp ((40 : ℝ) * x 1)) + (x 1 ^ 2) ≤ (0 : ℝ)) at hx
  rcases hx with ⟨_, _, _, _, _, _, _, haway, hnonpos⟩
  have hprod_nonneg :
      0 ≤ (x 0 ^ 2) * Real.exp ((40 : ℝ) * x 1) :=
    mul_nonneg (sq_nonneg (x 0)) (le_of_lt (Real.exp_pos _))
  have hprod_le :
      (x 0 ^ 2) * Real.exp ((40 : ℝ) * x 1) ≤ 0 := by
    nlinarith [sq_nonneg (x 1)]
  have hprod_eq :
      (x 0 ^ 2) * Real.exp ((40 : ℝ) * x 1) = 0 :=
    le_antisymm hprod_le hprod_nonneg
  have hexp_ne : Real.exp ((40 : ℝ) * x 1) ≠ 0 :=
    ne_of_gt (Real.exp_pos _)
  have hx0_sq : x 0 ^ 2 = 0 := by
    rcases mul_eq_zero.mp hprod_eq with h | h
    · exact h
    · exact (hexp_ne h).elim
  have hx1_sq : x 1 ^ 2 = 0 := by
    nlinarith
  nlinarith

#print axioms verify_positive_definite_8fe286fd6b8f

end LeanBarrier.Generated
