import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: e0ef31861d7104d815817db0fb3875451317b080b26d4c0235af12d2fe99548d
noncomputable def barrier_e0ef31861d71 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2))))
@[simp] theorem barrier_unfold_e0ef31861d71 (x : LeanBarrier.State 3) : barrier_e0ef31861d71 x = ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) := by
  rfl
def violationSet_equilibrium_fixed_e0ef31861d71 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ ((((-x 0) > (0 : ℝ))) ∨ (((-x 0) < (0 : ℝ))) ∨ (((((-2 : ℝ) * x 1) + (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 2)) + x 2) > (0 : ℝ))) ∨ (((((-2 : ℝ) * x 1) + (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 2)) + x 2) < (0 : ℝ))) ∨ ((((-x 2) - (((3 : ℝ) / (2 : ℝ)) * x 1)) > (0 : ℝ))) ∨ ((((-x 2) - (((3 : ℝ) / (2 : ℝ)) * x 1)) < (0 : ℝ)))))}



set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_e0ef31861d71 (hV : ContDiff ℝ 1 barrier_e0ef31861d71) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_e0ef31861d71 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_equilibrium_fixed_e0ef31861d71, Set.mem_setOf_eq] at hx
  rcases hx with ⟨h0, h1, h2, hbad⟩
  norm_num [h0, h1, h2] at hbad

#print axioms verify_equilibrium_fixed_e0ef31861d71

end LeanBarrier.Generated
