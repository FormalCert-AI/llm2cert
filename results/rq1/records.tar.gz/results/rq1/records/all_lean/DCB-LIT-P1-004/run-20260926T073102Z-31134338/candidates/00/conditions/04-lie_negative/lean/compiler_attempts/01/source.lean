import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: e0ef31861d7104d815817db0fb3875451317b080b26d4c0235af12d2fe99548d
noncomputable def barrier_e0ef31861d71 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2))))
@[simp] theorem barrier_unfold_e0ef31861d71 (x : LeanBarrier.State 3) : barrier_e0ef31861d71 x = ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) := by
  rfl
def violationSet_lie_negative_e0ef31861d71 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (0 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (x 0 ≥ (0 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) * (-x 0)) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * x 1 * (((-2 : ℝ) * x 1) + (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 2)) + x 2)) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * x 2 * ((-x 2) - (((3 : ℝ) / (2 : ℝ)) * x 1)))) ≥ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_e0ef31861d71 (hV : ContDiff ℝ 1 barrier_e0ef31861d71) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_e0ef31861d71 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨ha, ha10, hb, hb10, hc, hc10, hbound, ha', hb', hc', hpos, hD⟩
  have hab2 : 0 ≤ x 0 * (x 1) ^ 2 :=
    mul_nonneg ha (sq_nonneg (x 1))
  have hbminus : x 1 - 10 ≤ 0 := by
    linarith
  have hprod : x 0 * (x 1) ^ 2 * (x 1 - 10) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos hab2 hbminus
  have hbc : 0 ≤ x 1 * x 2 :=
    mul_nonneg hb hc
  have hac2 : 0 ≤ x 0 * (x 2) ^ 2 :=
    mul_nonneg ha (sq_nonneg (x 2))
  have hbracket :
      -4 * (x 1) ^ 2 - x 1 * x 2 - 2 * (x 2) ^ 2
          + (x 0 * (x 1) ^ 2 / 5) * (x 1 - 10)
          - 2 * x 0 * (x 2) ^ 2 ≤ 0 := by
    nlinarith [sq_nonneg (x 1), sq_nonneg (x 2), hprod]
  have hfactor :
      (((((2 : ℝ) * x 0) +
              ((2 : ℝ) * Real.exp ((2 : ℝ) * x 0) *
                ((x 1) ^ 2 + (x 2) ^ 2))) * (-x 0))
          + ((2 : ℝ) * Real.exp ((2 : ℝ) * x 0) * x 1 *
              (((-2 : ℝ) * x 1) +
                (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1) ^ 2) + x 2))
          + ((2 : ℝ) * Real.exp ((2 : ℝ) * x 0) * x 2 *
              ((-x 2) - (((3 : ℝ) / (2 : ℝ)) * x 1))))
        = -2 * (x 0) ^ 2 + Real.exp (2 * x 0) *
            (-4 * (x 1) ^ 2 - x 1 * x 2 - 2 * (x 2) ^ 2
              + (x 0 * (x 1) ^ 2 / 5) * (x 1 - 10)
              - 2 * x 0 * (x 2) ^ 2) := by
    ring
  rw [hfactor] at hD
  by_cases haz : x 0 = 0
  · simp [haz] at hD hpos
    nlinarith [sq_nonneg (x 1), sq_nonneg (x 2)]
  · have hapos : 0 < x 0 := lt_of_le_of_ne ha (Ne.symm haz)
    have hsqa : 0 < (x 0) ^ 2 := by
      simpa [pow_two] using mul_pos hapos hapos
    have hE : 0 < Real.exp (2 * x 0) := Real.exp_pos _
    have hEB :
        Real.exp (2 * x 0) *
            (-4 * (x 1) ^ 2 - x 1 * x 2 - 2 * (x 2) ^ 2
              + (x 0 * (x 1) ^ 2 / 5) * (x 1 - 10)
              - 2 * x 0 * (x 2) ^ 2) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos (le_of_lt hE) hbracket
    nlinarith

#print axioms verify_lie_negative_e0ef31861d71

end LeanBarrier.Generated
