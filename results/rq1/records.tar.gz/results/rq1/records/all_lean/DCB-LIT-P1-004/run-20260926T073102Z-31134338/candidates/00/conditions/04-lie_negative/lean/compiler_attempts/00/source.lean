import LeanBarrier

namespace LeanBarrier.Generated

-- candidate-sha256: e0ef31861d7104d815817db0fb3875451317b080b26d4c0235af12d2fe99548d
noncomputable def barrier_e0ef31861d71 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2))))
@[simp] theorem barrier_unfold_e0ef31861d71 (x : LeanBarrier.State 3) : barrier_e0ef31861d71 x = ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) := by
  rfl
def violationSet_lie_negative_e0ef31861d71 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (0 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (x 0 ≥ (0 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) * (-x 0)) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * x 1 * (((-2 : ℝ) * x 1) + (((1 : ℝ) / (10 : ℝ)) * x 0 * (x 1 ^ 2)) + x 2)) + ((2 : ℝ) * Real.exp (((2 : ℝ) * x 0)) * x 2 * ((-x 2) - (((3 : ℝ) / (2 : ℝ)) * x 1)))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_e0ef31861d71

end LeanBarrier.Generated
