import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: e0ef31861d7104d815817db0fb3875451317b080b26d4c0235af12d2fe99548d
noncomputable def barrier_e0ef31861d71 (x : LeanBarrier.State 3) : ℝ := ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2))))
@[simp] theorem barrier_unfold_e0ef31861d71 (x : LeanBarrier.State 3) : barrier_e0ef31861d71 x = ((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) := by
  rfl
def violationSet_positive_definite_e0ef31861d71 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (0 : ℝ)) ∧ (x 0 ≤ (10 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 1 ≤ (10 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (x 2 ≤ (10 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ (100 : ℝ)) ∧ (x 0 ≥ (0 : ℝ)) ∧ (x 1 ≥ (0 : ℝ)) ∧ (x 2 ≥ (0 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) > (0 : ℝ)) ∧ (((x 0 ^ 2) + (Real.exp (((2 : ℝ) * x 0)) * ((x 1 ^ 2) + (x 2 ^ 2)))) ≤ (0 : ℝ)))}



set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_e0ef31861d71 (hV : ContDiff ℝ 1 barrier_e0ef31861d71) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_e0ef31861d71 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0_nonneg, hx0_le, hx1_nonneg, hx1_le,
    hx2_nonneg, hx2_le, hball, hx0_nonneg', hx1_nonneg',
    hx2_nonneg', haway, hV_nonpos⟩
  have hE : 0 < Real.exp ((2 : ℝ) * x 0) := Real.exp_pos _
  have hA : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have hQ : 0 ≤ x 1 ^ 2 + x 2 ^ 2 :=
    add_nonneg (sq_nonneg (x 1)) (sq_nonneg (x 2))
  have hProd :
      0 ≤ Real.exp ((2 : ℝ) * x 0) * (x 1 ^ 2 + x 2 ^ 2) :=
    mul_nonneg (le_of_lt hE) hQ
  have hAzero : x 0 ^ 2 = 0 := by
    nlinarith
  have hProdZero :
      Real.exp ((2 : ℝ) * x 0) * (x 1 ^ 2 + x 2 ^ 2) = 0 := by
    nlinarith
  have hQzero : x 1 ^ 2 + x 2 ^ 2 = 0 := by
    rcases mul_eq_zero.mp hProdZero with hEz | hQz
    · exact False.elim ((ne_of_gt hE) hEz)
    · exact hQz
  nlinarith

#print axioms verify_positive_definite_e0ef31861d71

end LeanBarrier.Generated
