import LeanBarrier

#check Real.arctan
#check Real.strictMono_arctan.monotone
