import LeanBarrier.GeneratedCache.Context_0a23c6144232e492a7e8273c99d2da255ef4bd23bddcee06525dbdf91d9a7287

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_342c024400b7 (hV : ContDiff ℝ 1 barrier_342c024400b7) : ¬ ∃ x : LeanBarrier.State 5, ∃ omega : ℝ, violationSet_lie_strict_342c024400b7 x omega := by
  rintro ⟨x, omega, h⟩
  unfold violationSet_lie_strict_342c024400b7 at h
  rcases h with ⟨hωlo, hωhi, hx0lo, hx0hi, hx1lo, hx1hi,
    hx2lo, hx2hi, hx3lo, hx3hi, hx4lo, hx4hi, hB, hD⟩
  have hωnonneg : 0 ≤ omega := by linarith
  have hωsq : (x 1) ^ 2 ≤ omega * (x 1) ^ 2 := by
    have ht := mul_le_mul_of_nonneg_right hωlo (sq_nonneg (x 1))
    simpa using ht
  have hab :
      -((x 0) ^ 2 / 400 + (x 1) ^ 2 / 25) ≤
        omega * (x 0) * (x 1) / 100 := by
    by_cases hp : 0 ≤ (x 0) * (x 1)
    · have hm : 0 ≤ omega * ((x 0) * (x 1)) :=
        mul_nonneg hωnonneg hp
      nlinarith [sq_nonneg (x 0), sq_nonneg (x 1)]
    · have hp' : (x 0) * (x 1) ≤ 0 := le_of_not_ge hp
      have hm : 2 * ((x 0) * (x 1)) ≤ omega * ((x 0) * (x 1)) :=
        mul_le_mul_of_nonpos_right hωhi hp'
      nlinarith [sq_nonneg ((x 0) + 4 * (x 1))]
  have had :
      -((x 0) ^ 2 / 400 + (x 3) ^ 2 / 25) ≤
        -((x 0) * (x 3)) / 50 := by
    nlinarith [sq_nonneg ((x 0) - 4 * (x 3))]
  have hbe :
      -((x 1) ^ 2 / 400 + (x 4) ^ 2 / 400) ≤
        -((x 1) * (x 4)) / 200 := by
    nlinarith [sq_nonneg ((x 1) - (x 4))]
  have hcd :
      -((x 2) ^ 2 / 250 + 9 * (x 3) ^ 2 / 640) ≤
        3 * (x 2) * (x 3) / 200 := by
    nlinarith [sq_nonneg (8 * (x 2) + 15 * (x 3))]
  have hbc :
      -((x 2) ^ 2 / 250 + (x 1) ^ 2 / 40) ≤
        (x 1) * (x 2) / 50 := by
    nlinarith [sq_nonneg (2 * (x 2) + 5 * (x 1))]
  have hce :
      -((x 2) ^ 2 / 250 + (x 4) ^ 2 / 160) ≤
        -((x 2) * (x 4)) / 100 := by
    nlinarith [sq_nonneg (4 * (x 2) - 5 * (x 4))]
  have hcatan : 0 ≤ (x 2) * Real.arctan (x 2) := by
    by_cases hc : 0 ≤ x 2
    · have hat : 0 ≤ Real.arctan (x 2) := by
        simpa using hc
      exact mul_nonneg hc hat
    · have hc' : x 2 ≤ 0 := le_of_not_ge hc
      have hat : Real.arctan (x 2) ≤ 0 := by
        simpa using hc'
      exact mul_nonneg_of_nonpos_of_nonpos hc' hat
  have heatan : 0 ≤ (x 4) * Real.arctan (x 4) := by
    by_cases he : 0 ≤ x 4
    · have hat : 0 ≤ Real.arctan (x 4) := by
        simpa using he
      exact mul_nonneg he hat
    · have he' : x 4 ≤ 0 := le_of_not_ge he
      have hat : Real.arctan (x 4) ≤ 0 := by
        simpa using he'
      exact mul_nonneg_of_nonpos_of_nonpos he' hat
  ring_nf at hD
  have hs :
      (x 0) ^ 2 / 200 + 369 * (x 1) ^ 2 / 400 +
          (x 2) ^ 2 / 125 + 919 * (x 3) ^ 2 / 640 +
          793 * (x 4) ^ 2 / 800 ≤ 0 := by
    nlinarith [hD, hωsq, hab, had, hbe, hcd, hbc, hce, hcatan, heatan]
  have hx0 : x 0 = 0 := by
    nlinarith [hs, sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4)]
  have hx1 : x 1 = 0 := by
    nlinarith [hs, sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4)]
  have hx2 : x 2 = 0 := by
    nlinarith [hs, sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4)]
  have hx3 : x 3 = 0 := by
    nlinarith [hs, sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4)]
  have hx4 : x 4 = 0 := by
    nlinarith [hs, sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4)]
  norm_num [hx0, hx1, hx2, hx3, hx4] at hB

#print axioms verify_lie_strict_342c024400b7

end LeanBarrier.Generated
