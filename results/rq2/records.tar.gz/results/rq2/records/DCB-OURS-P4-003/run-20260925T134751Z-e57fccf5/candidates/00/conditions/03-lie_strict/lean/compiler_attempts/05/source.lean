import LeanBarrier.GeneratedCache.Helper_550185a5978d1654d1a724dc4d6b1cc56d282d8595de30a5cadcc744ed52a79e

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_boundary_radius_d7837f803cbd
    (a0 a1 a2 a3 a4 a5 a6 a7 : ℝ)
    (hB :
      (3 / 10 : ℝ) -
        (a0 ^ 2 + a1 ^ 2 + a2 ^ 2 + a3 ^ 2 +
          a4 ^ 2 + a5 ^ 2 + a6 ^ 2 + a7 ^ 2 +
          (1 / 5 : ℝ) * a0 * a1) = 0) :
    (3 / 11 : ℝ) ≤
      a0 ^ 2 + a1 ^ 2 + a2 ^ 2 + a3 ^ 2 +
        a4 ^ 2 + a5 ^ 2 + a6 ^ 2 + a7 ^ 2 := by
  have hcross :
      (1 / 5 : ℝ) * a0 * a1 ≤
        (1 / 10 : ℝ) * a0 ^ 2 + (1 / 10 : ℝ) * a1 ^ 2 := by
    nlinarith [sq_nonneg (a0 - a1)]
  nlinarith [hcross, sq_nonneg a0, sq_nonneg a1, sq_nonneg a2,
    sq_nonneg a3, sq_nonneg a4, sq_nonneg a5, sq_nonneg a6,
    sq_nonneg a7]

#print axioms lie_boundary_radius_d7837f803cbd

end LeanBarrier.Generated
