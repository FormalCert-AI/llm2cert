import LeanBarrier.GeneratedCache.Context_9017dc710b45bae13e156fdae3f58fe0ef41daec72b3c0d40058d69211e1f47f

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_sine_control_d7837f803cbd
    (omega a : ℝ)
    (hωlo : (1 / 2 : ℝ) ≤ omega) (hωhi : omega ≤ 2)
    (halo : -1 ≤ a) (hahi : a ≤ 1) :
    0 ≤ a * Real.sin (omega * a) ∧
      (a + Real.sin (omega * a)) ^ 2 ≤ 9 * a ^ 2 := by
  have hω0 : 0 ≤ omega := by linarith
  have hsin0 : 0 ≤ a * Real.sin (omega * a) := by
    rcases le_total 0 a with ha | ha
    · have hang0 : 0 ≤ omega * a := mul_nonneg hω0 ha
      have hang2 : omega * a ≤ 2 := by
        have hm := mul_le_mul_of_nonneg_right hωhi ha
        nlinarith
      have hangpi : omega * a ≤ Real.pi := by
        nlinarith [Real.two_le_pi]
      have hs : 0 ≤ Real.sin (omega * a) :=
        Real.sin_nonneg_of_nonneg_of_le_pi hang0 hangpi
      exact mul_nonneg ha hs
    · have hang0 : 0 ≤ -(omega * a) := by
        nlinarith [mul_nonpos_of_nonneg_of_nonpos hω0 ha]
      have hang2 : -(omega * a) ≤ 2 := by
        have hm := mul_le_mul_of_nonneg_right hωhi (neg_nonneg.mpr ha)
        nlinarith
      have hangpi : -(omega * a) ≤ Real.pi := by
        nlinarith [Real.two_le_pi]
      have hs : 0 ≤ Real.sin (-(omega * a)) :=
        Real.sin_nonneg_of_nonneg_of_le_pi hang0 hangpi
      rw [Real.sin_neg] at hs
      exact mul_nonneg_of_nonpos_of_nonpos ha (by linarith)
  have hωsq : omega ^ 2 ≤ 4 := by
    have hp : 0 ≤ omega * (2 - omega) :=
      mul_nonneg hω0 (sub_nonneg.mpr hωhi)
    nlinarith
  have hangsq : (omega * a) ^ 2 ≤ 4 * a ^ 2 := by
    have hp : 0 ≤ a ^ 2 * (4 - omega ^ 2) :=
      mul_nonneg (sq_nonneg a) (sub_nonneg.mpr hωsq)
    nlinarith
  have hsinsq : (Real.sin (omega * a)) ^ 2 ≤ (omega * a) ^ 2 := by
    have habs := Real.abs_sin_le_abs (omega * a)
    have hp :
        0 ≤ (|omega * a| - |Real.sin (omega * a)|) *
          (|omega * a| + |Real.sin (omega * a)|) :=
      mul_nonneg (sub_nonneg.mpr habs)
        (add_nonneg (abs_nonneg _) (abs_nonneg _))
    nlinarith [sq_abs (omega * a), sq_abs (Real.sin (omega * a))]
  have hsinsq' : (Real.sin (omega * a)) ^ 2 ≤ 4 * a ^ 2 := by
    linarith
  constructor
  · exact hsin0
  · nlinarith [hsinsq', sq_nonneg (Real.sin (omega * a) - 2 * a)]

#print axioms lie_sine_control_d7837f803cbd

end LeanBarrier.Generated
