import LeanBarrier.GeneratedCache.Helper_8b043bbd7b8ccd6256aff464bbf906222ec98cf8ff868c03c8169b0b045e06bd

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_cos_nonnegative_d7837f803cbd
    (a : ℝ) (halo : -1 ≤ a) (hahi : a ≤ 1) : 0 ≤ Real.cos a := by
  apply Real.cos_nonneg_of_mem_Icc
  constructor <;> nlinarith [Real.two_le_pi]

#print axioms lie_cos_nonnegative_d7837f803cbd

end LeanBarrier.Generated
