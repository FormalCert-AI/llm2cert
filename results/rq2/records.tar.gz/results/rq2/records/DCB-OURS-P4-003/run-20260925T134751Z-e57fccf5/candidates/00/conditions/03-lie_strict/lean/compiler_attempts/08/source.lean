import LeanBarrier.GeneratedCache.Helper_dd33e40b1fdd65945dc034fb06122ff440b5217c9ee7a6319420441538e8d87d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_d7837f803cbd (hV : ContDiff ℝ 1 barrier_d7837f803cbd) : ¬ ∃ x : LeanBarrier.State 8, ∃ omega : ℝ, violationSet_lie_strict_d7837f803cbd x omega := by
  rintro ⟨x, omega, h⟩
  exact no_lie_violation_d7837f803cbd x omega h

#print axioms verify_lie_strict_d7837f803cbd

end LeanBarrier.Generated
