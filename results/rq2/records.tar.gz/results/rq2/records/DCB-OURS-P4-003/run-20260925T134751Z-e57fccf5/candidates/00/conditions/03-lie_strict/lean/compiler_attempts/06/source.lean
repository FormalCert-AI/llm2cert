import LeanBarrier.GeneratedCache.Helper_02555f826fea440b152996d477463a51dea8fc4134ab70d2cbf731aa82ce80bc

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_decay_algebra_d7837f803cbd
    (a0 a1 a2 a3 a4 a5 a6 a7 t u v : ℝ)
    (ht : 0 ≤ a0 * t)
    (hz : (a0 + t) ^ 2 ≤ 9 * a0 ^ 2)
    (hu : -1 ≤ u) (hv : 0 ≤ v) :
    ((2 * a0 + (1 / 5 : ℝ) * a1) * a1) +
      ((2 * a1 + (1 / 5 : ℝ) * a0) *
        (((-a0) - (1 / 10 : ℝ) * t) - a1 + a2)) +
      ((2 * a2) * ((-2 : ℝ) * a2 + a3)) +
      ((2 * a3) * ((-3 / 2 : ℝ) * a3 + a4)) +
      ((2 * a4) * ((-2 : ℝ) * a4 + a5)) +
      ((2 * a5) * ((-3 / 2 : ℝ) * a5 + (1 / 5 : ℝ) * a6)) +
      ((2 * a6) * (((-2 : ℝ) * a6 + (1 / 5 : ℝ) * a5 +
        (1 / 5 : ℝ) * a7) - (1 / 10 : ℝ) * a6 * u)) +
      ((2 * a7) * (((-3 / 2 : ℝ) * a7 + (1 / 5 : ℝ) * a6) -
        (1 / 10 : ℝ) * a7 * v)) ≤
      -(1 / 20 : ℝ) *
        (a0 ^ 2 + a1 ^ 2 + a2 ^ 2 + a3 ^ 2 +
          a4 ^ 2 + a5 ^ 2 + a6 ^ 2 + a7 ^ 2) := by
  have hmain :
      -(1 / 5 : ℝ) * a1 * (a0 + t) ≤
        (1 / 10 : ℝ) * a0 ^ 2 + (9 / 10 : ℝ) * a1 ^ 2 := by
    nlinarith [hz, sq_nonneg ((a0 + t) + 9 * a1)]
  have h02 :
      (1 / 5 : ℝ) * a0 * a2 ≤
        (1 / 20 : ℝ) * a0 ^ 2 + (1 / 5 : ℝ) * a2 ^ 2 := by
    nlinarith [sq_nonneg (a0 - 2 * a2)]
  have h12 :
      2 * a1 * a2 ≤
        (4 / 5 : ℝ) * a1 ^ 2 + (5 / 4 : ℝ) * a2 ^ 2 := by
    nlinarith [sq_nonneg (4 * a1 - 5 * a2)]
  have h23 : 2 * a2 * a3 ≤ a2 ^ 2 + a3 ^ 2 := by
    nlinarith [sq_nonneg (a2 - a3)]
  have h34 : 2 * a3 * a4 ≤ a3 ^ 2 + a4 ^ 2 := by
    nlinarith [sq_nonneg (a3 - a4)]
  have h45 : 2 * a4 * a5 ≤ a4 ^ 2 + a5 ^ 2 := by
    nlinarith [sq_nonneg (a4 - a5)]
  have h56 :
      (4 / 5 : ℝ) * a5 * a6 ≤
        (2 / 5 : ℝ) * a5 ^ 2 + (2 / 5 : ℝ) * a6 ^ 2 := by
    nlinarith [sq_nonneg (a5 - a6)]
  have h67 :
      (4 / 5 : ℝ) * a6 * a7 ≤
        (2 / 5 : ℝ) * a6 ^ 2 + (2 / 5 : ℝ) * a7 ^ 2 := by
    nlinarith [sq_nonneg (a6 - a7)]
  have h6u :
      -(1 / 5 : ℝ) * a6 ^ 2 * u ≤ (1 / 5 : ℝ) * a6 ^ 2 := by
    have hp : 0 ≤ a6 ^ 2 * (u + 1) :=
      mul_nonneg (sq_nonneg a6) (by linarith)
    nlinarith
  have h7v : -(1 / 5 : ℝ) * a7 ^ 2 * v ≤ 0 := by
    have hp : 0 ≤ a7 ^ 2 * v := mul_nonneg (sq_nonneg a7) hv
    nlinarith
  nlinarith [hmain, h02, h12, h23, h34, h45, h56, h67, h6u, h7v,
    sq_nonneg a0, sq_nonneg a1, sq_nonneg a2, sq_nonneg a3,
    sq_nonneg a4, sq_nonneg a5, sq_nonneg a6, sq_nonneg a7]

#print axioms lie_decay_algebra_d7837f803cbd

end LeanBarrier.Generated
