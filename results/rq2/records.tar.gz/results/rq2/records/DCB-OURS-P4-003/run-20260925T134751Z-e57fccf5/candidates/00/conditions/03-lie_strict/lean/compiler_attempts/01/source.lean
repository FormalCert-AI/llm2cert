import LeanBarrier

#check Real.sin
#check Real.pi
#check Real.two_le_pi
#check Real.sin_nonneg_of_nonneg_of_le_pi
#check Real.sin_neg
#check Real.abs_sin_le_abs
#check Real.cos
#check Real.cos_nonneg_of_mem_Icc
#check Real.neg_one_le_sin
