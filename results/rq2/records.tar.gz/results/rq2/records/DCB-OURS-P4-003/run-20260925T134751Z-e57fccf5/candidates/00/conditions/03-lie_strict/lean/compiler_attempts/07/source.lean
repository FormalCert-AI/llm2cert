import LeanBarrier.GeneratedCache.Helper_af6dc71c60717d8dec983134bdd4a8cf61b6b49e69562fd0ecf081c277d903a3

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem no_lie_violation_d7837f803cbd
    (x : LeanBarrier.State 8) (omega : ℝ) :
    ¬ violationSet_lie_strict_d7837f803cbd x omega := by
  intro h
  simp only [violationSet_lie_strict_d7837f803cbd] at h
  rcases h with
    ⟨hωlo, hωhi,
      hx0lo, hx0hi, hx1lo, hx1hi, hx2lo, hx2hi, hx3lo, hx3hi,
      hx4lo, hx4hi, hx5lo, hx5hi, hx6lo, hx6hi, hx7lo, hx7hi,
      hB, hL⟩
  obtain ⟨hsin0, hsinsq⟩ :=
    lie_sine_control_d7837f803cbd omega (x 0) hωlo hωhi hx0lo hx0hi
  have hcos : 0 ≤ Real.cos (x 6) :=
    lie_cos_nonnegative_d7837f803cbd (x 6) hx6lo hx6hi
  have hSlower := lie_boundary_radius_d7837f803cbd
    (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) hB
  have hDupper := lie_decay_algebra_d7837f803cbd
    (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7)
    (Real.sin (omega * x 0)) (Real.sin (x 7)) (Real.cos (x 6))
    hsin0 hsinsq (Real.neg_one_le_sin (x 7)) hcos
  nlinarith [hL, hDupper, hSlower]

#print axioms no_lie_violation_d7837f803cbd

end LeanBarrier.Generated
