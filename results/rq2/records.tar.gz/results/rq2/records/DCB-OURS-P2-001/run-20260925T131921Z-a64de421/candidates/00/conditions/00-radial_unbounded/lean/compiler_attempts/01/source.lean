import LeanBarrier.GeneratedCache.Context_0ac983f4002562e61bf9fb0e822162dfccb818611acb6e6b42f8b54bd2ff3f93

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_88a1aa1bb7a7 (hV : ContDiff ℝ 1 barrier_88a1aa1bb7a7) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_88a1aa1bb7a7 := by
  intro c
  refine ⟨max 1 (c + 1), ?_⟩
  first
  | constructor
    · positivity
  | skip
  intro x hx
  have hc : c + 1 ≤ max 1 (c + 1) := le_max_right _ _
  rw [barrier_unfold_88a1aa1bb7a7]
  simp [Fin.sum_univ_succ] at hx
  ring_nf at hx ⊢
  linarith

#print axioms verify_radial_unbounded_88a1aa1bb7a7

end LeanBarrier.Generated
