-- candidate-sha256: 88a1aa1bb7a79d30c7325ded09f7c7d346991f9912a79afc838b5f4bbe1893b5
noncomputable def barrier_88a1aa1bb7a7 (x : LeanBarrier.State 10) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2) + (x 8 ^ 2) + (x 9 ^ 2))
@[simp] theorem barrier_unfold_88a1aa1bb7a7 (x : LeanBarrier.State 10) : barrier_88a1aa1bb7a7 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2) + (x 8 ^ 2) + (x 9 ^ 2)) := by
  rfl

theorem verify_radial_unbounded_88a1aa1bb7a7 (hV : ContDiff ℝ 1 barrier_88a1aa1bb7a7) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_88a1aa1bb7a7
