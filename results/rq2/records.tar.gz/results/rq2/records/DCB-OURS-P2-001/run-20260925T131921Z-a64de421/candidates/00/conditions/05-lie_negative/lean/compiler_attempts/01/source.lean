import LeanBarrier.GeneratedCache.Context_b3ddb67a8c116ccb30c9b1ba95628996a404fc3c0336a907c69a880a2c1e1104

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_88a1aa1bb7a7 (hV : ContDiff ℝ 1 barrier_88a1aa1bb7a7) : ¬ ∃ x : LeanBarrier.State 10, x ∈ violationSet_lie_negative_88a1aa1bb7a7 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_88a1aa1bb7a7, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hunit, hpos, hD⟩
  have hprod (a b : ℝ) : a * b ≤ (a ^ 2 + b ^ 2) / 2 := by
    nlinarith [sq_nonneg (a - b)]
  have hfrac (a b : ℝ) :
      a * (b / (b ^ 2 + 1)) ≤ (a ^ 2 + b ^ 2) / 2 := by
    have hd : 0 < b ^ 2 + 1 := by
      nlinarith [sq_nonneg b]
    calc
      a * (b / (b ^ 2 + 1)) = (a * b) / (b ^ 2 + 1) := by ring
      _ ≤ (a ^ 2 + b ^ 2) / 2 := by
        apply (div_le_iff₀ hd).2
        have hq : 0 ≤ (a ^ 2 + b ^ 2) / 2 := by positivity
        have hextra : 0 ≤ ((a ^ 2 + b ^ 2) / 2) * b ^ 2 :=
          mul_nonneg hq (sq_nonneg b)
        nlinarith [hprod a b]
  have hlin :
      x 0 * x 1 + x 1 * x 2 + x 2 * x 3 + x 3 * x 4 + x 4 * x 5 +
          x 5 * x 6 + x 6 * x 7 + x 7 * x 8 + x 8 * x 9 + x 9 * x 0 ≤
        x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 + x 3 ^ 2 + x 4 ^ 2 +
          x 5 ^ 2 + x 6 ^ 2 + x 7 ^ 2 + x 8 ^ 2 + x 9 ^ 2 := by
    nlinarith [hprod (x 0) (x 1), hprod (x 1) (x 2),
      hprod (x 2) (x 3), hprod (x 3) (x 4), hprod (x 4) (x 5),
      hprod (x 5) (x 6), hprod (x 6) (x 7), hprod (x 7) (x 8),
      hprod (x 8) (x 9), hprod (x 9) (x 0)]
  have hnonlinear :
      x 0 * (x 2 / (x 2 ^ 2 + 1)) +
          x 1 * (x 3 / (x 3 ^ 2 + 1)) +
          x 2 * (x 4 / (x 4 ^ 2 + 1)) +
          x 3 * (x 5 / (x 5 ^ 2 + 1)) +
          x 4 * (x 6 / (x 6 ^ 2 + 1)) +
          x 5 * (x 7 / (x 7 ^ 2 + 1)) +
          x 6 * (x 8 / (x 8 ^ 2 + 1)) +
          x 7 * (x 9 / (x 9 ^ 2 + 1)) +
          x 8 * (x 0 / (x 0 ^ 2 + 1)) +
          x 9 * (x 1 / (x 1 ^ 2 + 1)) ≤
        x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 + x 3 ^ 2 + x 4 ^ 2 +
          x 5 ^ 2 + x 6 ^ 2 + x 7 ^ 2 + x 8 ^ 2 + x 9 ^ 2 := by
    nlinarith [hfrac (x 0) (x 2), hfrac (x 1) (x 3),
      hfrac (x 2) (x 4), hfrac (x 3) (x 5), hfrac (x 4) (x 6),
      hfrac (x 5) (x 7), hfrac (x 6) (x 8), hfrac (x 7) (x 9),
      hfrac (x 8) (x 0), hfrac (x 9) (x 1)]
  nlinarith [hlin, hnonlinear]

#print axioms verify_lie_negative_88a1aa1bb7a7

end LeanBarrier.Generated
