import LeanBarrier

#check Real.pi
#check Real.pi_gt_three
#check Real.cos
#check Real.cos_pos_of_mem_Ioo
#check Real.sin
#check Real.sin_pos_of_pos_of_lt_pi
#check Real.sin_neg
