import LeanBarrier.GeneratedCache.Context_677a037d8913eb0f2a30eea79e6afb62baea80006a2fd48eb94fb6cd26e0379d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_53ede657fdfb (hV : ContDiff ℝ 1 barrier_53ede657fdfb) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_53ede657fdfb := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_53ede657fdfb, Set.mem_setOf_eq] at hx
  rcases hx with ⟨haL, haU, htL, htU, hrad, hbar, haway, hLie⟩
  have htmem : x 1 ∈ Set.Ioo (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> nlinarith [Real.pi_gt_three]
  have hcpos : 0 < Real.cos (x 1) := Real.cos_pos_of_mem_Ioo htmem
  have hcne : Real.cos (x 1) ≠ 0 := ne_of_gt hcpos
  have hcancel :
      ((Real.cos (x 1) / (1 - x 0) -
          (2 * (x 0 + Real.sin (x 1))) / Real.cos (x 1)) -
        Real.cos (x 1) / (1 - x 0)) =
        -((2 * (x 0 + Real.sin (x 1))) / Real.cos (x 1)) := by
    ring
  have hcalc :
      ((2 * x 0 + 2 * (x 0 + Real.sin (x 1))) * Real.sin (x 1) +
        2 * (x 0 + Real.sin (x 1)) * Real.cos (x 1) *
          ((Real.cos (x 1) / (1 - x 0) -
              (2 * (x 0 + Real.sin (x 1))) / Real.cos (x 1)) -
            Real.cos (x 1) / (1 - x 0))) =
        -2 * (x 0) ^ 2 - 2 * (x 0 + Real.sin (x 1)) ^ 2 := by
    rw [hcancel]
    field_simp [hcne]
    <;> ring
  rw [hcalc] at hLie
  have ha_sq_le : (x 0) ^ 2 ≤ 0 := by
    nlinarith [sq_nonneg (x 0 + Real.sin (x 1))]
  have ha_sq : (x 0) ^ 2 = 0 :=
    le_antisymm ha_sq_le (sq_nonneg (x 0))
  have ha0 : x 0 = 0 := by
    have hm : x 0 * x 0 = 0 := by
      simpa [pow_two] using ha_sq
    rcases mul_eq_zero.mp hm with h | h
    · exact h
    · exact h
  have hz_sq_le : (x 0 + Real.sin (x 1)) ^ 2 ≤ 0 := by
    nlinarith [sq_nonneg (x 0)]
  have hz_sq : (x 0 + Real.sin (x 1)) ^ 2 = 0 :=
    le_antisymm hz_sq_le (sq_nonneg (x 0 + Real.sin (x 1)))
  have hz0 : x 0 + Real.sin (x 1) = 0 := by
    have hm : (x 0 + Real.sin (x 1)) * (x 0 + Real.sin (x 1)) = 0 := by
      simpa [pow_two] using hz_sq
    rcases mul_eq_zero.mp hm with h | h
    · exact h
    · exact h
  have hs0 : Real.sin (x 1) = 0 := by
    linarith
  have ht0 : x 1 = 0 := by
    by_contra hne
    rcases lt_or_gt_of_ne hne with hneg | hpos
    · have hp : 0 < Real.sin (-(x 1)) :=
        Real.sin_pos_of_pos_of_lt_pi (by linarith) (by nlinarith [Real.pi_gt_three])
      rw [Real.sin_neg, hs0] at hp
      norm_num at hp
    · have hp : 0 < Real.sin (x 1) :=
        Real.sin_pos_of_pos_of_lt_pi hpos (by nlinarith [Real.pi_gt_three])
      rw [hs0] at hp
      norm_num at hp
  norm_num [ha0, ht0] at haway

#print axioms verify_lie_negative_53ede657fdfb

end LeanBarrier.Generated
