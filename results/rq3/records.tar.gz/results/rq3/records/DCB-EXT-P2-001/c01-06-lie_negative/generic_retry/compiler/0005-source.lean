import LeanBarrier.GeneratedCache.Context_677a037d8913eb0f2a30eea79e6afb62baea80006a2fd48eb94fb6cd26e0379d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_53ede657fdfb (hV : ContDiff ℝ 1 barrier_53ede657fdfb) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_53ede657fdfb := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_53ede657fdfb, Set.mem_setOf_eq] at hx
  rcases hx with ⟨haL, haU, htL, htU, hrad, hbar, haway, hLie⟩
  set a : ℝ := x 0 at *
  set t : ℝ := x 1 at *
  have hpi : (3 : ℝ) < Real.pi := Real.pi_gt_three
  have htmem : t ∈ Set.Ioo (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> linarith
  have hcpos : 0 < Real.cos t := Real.cos_pos_of_mem_Ioo htmem
  have hcne : Real.cos t ≠ 0 := ne_of_gt hcpos
  have hcancel :
      ((Real.cos t / (1 - a) -
          (2 * (a + Real.sin t)) / Real.cos t) -
        Real.cos t / (1 - a)) =
        -((2 * (a + Real.sin t)) / Real.cos t) := by
    ring
  rw [hcancel] at hLie
  have hterm :
      2 * (a + Real.sin t) * Real.cos t *
          (-((2 * (a + Real.sin t)) / Real.cos t)) =
        -4 * (a + Real.sin t) ^ 2 := by
    calc
      2 * (a + Real.sin t) * Real.cos t *
            (-((2 * (a + Real.sin t)) / Real.cos t)) =
          -4 * (a + Real.sin t) ^ 2 *
            (Real.cos t / Real.cos t) := by ring
      _ = -4 * (a + Real.sin t) ^ 2 := by
        rw [div_self hcne]
        ring
  rw [hterm] at hLie
  have hLie' :
      -2 * a ^ 2 - 2 * (a + Real.sin t) ^ 2 ≥ 0 := by
    nlinarith [hLie]
  have ha0 : a = 0 := by
    nlinarith [hLie', sq_nonneg a, sq_nonneg (a + Real.sin t)]
  have hz0 : a + Real.sin t = 0 := by
    nlinarith [hLie', sq_nonneg a, sq_nonneg (a + Real.sin t)]
  have hs0 : Real.sin t = 0 := by
    linarith
  have ht0 : t = 0 := by
    rcases lt_trichotomy t 0 with hneg | heq | hpos
    · have hp : 0 < Real.sin (-t) := by
        apply Real.sin_pos_of_pos_of_lt_pi
        · linarith
        · linarith
      rw [Real.sin_neg, hs0] at hp
      norm_num at hp
    · exact heq
    · have hp : 0 < Real.sin t := by
        apply Real.sin_pos_of_pos_of_lt_pi
        · exact hpos
        · linarith
      rw [hs0] at hp
      norm_num at hp
  rw [ha0, ht0] at haway
  norm_num at haway

#print axioms verify_lie_negative_53ede657fdfb

end LeanBarrier.Generated
