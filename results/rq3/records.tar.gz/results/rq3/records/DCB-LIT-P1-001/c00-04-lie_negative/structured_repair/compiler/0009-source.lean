import LeanBarrier.GeneratedCache.Helper_7872c9015d6175b18ffd5304d43300ebe1f56b8cce00f6a500ad6c9852af1c22

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem shifted_tan_bound_pos_00550cacd40b (s : ℝ)
    (hshi : s ≤ (1 : ℝ) / 4) (hspos : 0 < s) :
    2 * s <
      Real.sin (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) /
        Real.cos (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) - 1 := by
  have hp : 0 < Real.pi := Real.pi_pos
  have hp3 : 3 < Real.pi := Real.pi_gt_three
  let v : ℝ := ((1 : ℝ) / 2) * Real.pi * s
  have hvpos : 0 < v := by
    dsimp [v]
    positivity
  have hv0 : 0 ≤ v := le_of_lt hvpos
  have hvle : v ≤ Real.pi / 8 := by
    dsimp [v]
    nlinarith [mul_nonneg (sub_nonneg.mpr hshi) (le_of_lt hp)]
  rcases trig_aux_00550cacd40b v hv0 hvle with ⟨hcos, hmul, htwo⟩
  have hsin0 : 0 ≤ Real.sin v := by
    have hvc : 0 ≤ v * Real.cos v := mul_nonneg hv0 (le_of_lt hcos)
    nlinarith
  have hden : 0 < Real.cos v - Real.sin v := by
    nlinarith
  have hform := shifted_tan_add_identity_00550cacd40b v hden
  have hang :
      ((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi =
        Real.pi / 4 + v := by
    dsimp [v]
    ring
  have hratio :
      2 * v ≤ 2 * Real.sin v / (Real.cos v - Real.sin v) := by
    apply (le_div_iff₀ hden).2
    have hz : 0 ≤ v * Real.sin v := mul_nonneg hv0 hsin0
    nlinarith
  have hvrel : 2 * s < 2 * v := by
    have hz : 0 < s * (Real.pi - 2) :=
      mul_pos hspos (by nlinarith [hp3])
    dsimp [v]
    nlinarith
  rw [hang, hform]
  nlinarith

#print axioms shifted_tan_bound_pos_00550cacd40b

end LeanBarrier.Generated
