import LeanBarrier

#check Real.hasDerivAt_sin
#check Real.hasDerivAt_cos
