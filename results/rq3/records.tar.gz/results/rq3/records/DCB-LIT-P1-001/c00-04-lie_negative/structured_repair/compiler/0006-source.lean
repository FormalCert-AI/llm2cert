import LeanBarrier.GeneratedCache.Context_63cdb8e09c5a7a7a2f7414b8c5998e3e0453dab33ea987bac4ec8fe06e994cc5

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem trig_aux_00550cacd40b (v : ℝ) (hv0 : 0 ≤ v) (hvle : v ≤ Real.pi / 8) :
    0 < Real.cos v ∧ v * Real.cos v ≤ Real.sin v ∧ 2 * Real.sin v < Real.cos v := by
  have hp : 0 < Real.pi := Real.pi_pos
  have hvpi : v ≤ Real.pi := by nlinarith
  have hcos : 0 < Real.cos v := by
    apply Real.cos_pos_of_mem_Ioo
    constructor <;> nlinarith
  have hmul : v * Real.cos v ≤ Real.sin v := by
    rcases eq_or_lt_of_le hv0 with rfl | hvpos
    · simp
    · let f : ℝ → ℝ := fun t => Real.sin t - t * Real.cos t
      have hf' (t : ℝ) : HasDerivAt f (t * Real.sin t) t := by
        change HasDerivAt (fun z : ℝ => Real.sin z - z * Real.cos z)
          (t * Real.sin t) t
        have h := (Real.hasDerivAt_sin t).sub
          ((hasDerivAt_id t).mul (Real.hasDerivAt_cos t))
        have heq :
            Real.cos t - (1 * Real.cos t + t * (-Real.sin t)) =
              t * Real.sin t := by
          ring
        rw [← heq]
        exact h
      have hfcont : ContinuousOn f (Set.Icc 0 v) := by
        intro t ht
        exact (hf' t).continuousAt.continuousWithinAt
      have hfdiff : DifferentiableOn ℝ f (interior (Set.Icc 0 v)) := by
        intro t ht
        exact (hf' t).differentiableAt.differentiableWithinAt
      have hfder : ∀ t ∈ interior (Set.Icc 0 v), 0 ≤ deriv f t := by
        intro t ht
        rw [(hf' t).deriv]
        have htI : t ∈ Set.Icc (0 : ℝ) v := interior_subset ht
        have htpi : t < Real.pi := by
          have hvltpi : v < Real.pi := by nlinarith
          exact lt_of_le_of_lt htI.2 hvltpi
        have hsin : 0 ≤ Real.sin t := by
          rcases eq_or_lt_of_le htI.1 with rfl | htpos
          · simp
          · exact le_of_lt (Real.sin_pos_of_pos_of_lt_pi htpos htpi)
        exact mul_nonneg htI.1 hsin
      have hfmono : MonotoneOn f (Set.Icc 0 v) :=
        monotoneOn_of_deriv_nonneg (convex_Icc 0 v) hfcont hfdiff hfder
      have hfv := hfmono (show (0 : ℝ) ∈ Set.Icc 0 v by exact ⟨le_rfl, hv0⟩)
        (show v ∈ Set.Icc 0 v by exact ⟨hv0, le_rfl⟩) hv0
      dsimp [f] at hfv
      simp at hfv
      nlinarith
  have hsqrt0 : 0 ≤ Real.sqrt 2 := Real.sqrt_nonneg 2
  have hsqrt_sq : (Real.sqrt 2) ^ 2 = (2 : ℝ) := by
    simpa using Real.sq_sqrt (show (0 : ℝ) ≤ 2 by norm_num)
  have hsqrt_lower : (6 : ℝ) / 5 < Real.sqrt 2 := by
    nlinarith
  let u : ℝ := Real.pi / 8
  have hu0 : 0 ≤ u := by
    dsimp [u]
    nlinarith
  have hupi : u ≤ Real.pi := by
    dsimp [u]
    nlinarith
  have hsin_u_pos : 0 < Real.sin u := by
    apply Real.sin_pos_of_pos_of_lt_pi
    · dsimp [u]
      nlinarith
    · dsimp [u]
      nlinarith
  have hcos_u_pos : 0 < Real.cos u := by
    apply Real.cos_pos_of_mem_Ioo
    constructor <;> dsimp [u] <;> nlinarith
  have hsum := Real.sin_sq_add_cos_sq u
  have hdouble : Real.cos (2 * u) = 2 * (Real.cos u) ^ 2 - 1 := by
    simpa using Real.cos_two_mul u
  have hu_double : 2 * u = Real.pi / 4 := by
    dsimp [u]
    ring
  rw [hu_double, Real.cos_pi_div_four] at hdouble
  have hend : 2 * Real.sin u < Real.cos u := by
    nlinarith [sq_nonneg (2 * Real.sin u - Real.cos u)]
  have hvI : v ∈ Set.Icc (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> nlinarith
  have huI : u ∈ Set.Icc (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> dsimp [u] <;> nlinarith
  have hsin_mono : Real.sin v ≤ Real.sin u :=
    Real.strictMonoOn_sin.monotoneOn hvI huI hvle
  have hvC : v ∈ Set.Icc (0 : ℝ) Real.pi := ⟨hv0, hvpi⟩
  have huC : u ∈ Set.Icc (0 : ℝ) Real.pi := ⟨hu0, hupi⟩
  have hcos_mono : Real.cos u ≤ Real.cos v :=
    Real.strictAntiOn_cos.antitoneOn hvC huC hvle
  refine ⟨hcos, hmul, ?_⟩
  nlinarith

#print axioms trig_aux_00550cacd40b

end LeanBarrier.Generated
