import LeanBarrier.GeneratedCache.Context_63cdb8e09c5a7a7a2f7414b8c5998e3e0453dab33ea987bac4ec8fe06e994cc5

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_00550cacd40b (hV : ContDiff ℝ 1 barrier_00550cacd40b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_00550cacd40b := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_00550cacd40b, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hball, hpos, hD⟩
  let q0 : ℝ :=
    Real.sin (((1 : ℝ) / 2) * Real.pi * x 0 + ((1 : ℝ) / 4) * Real.pi) /
      Real.cos (((1 : ℝ) / 2) * Real.pi * x 0 + ((1 : ℝ) / 4) * Real.pi) - 1
  let q1 : ℝ :=
    Real.sin (((1 : ℝ) / 2) * Real.pi * x 1 + ((1 : ℝ) / 4) * Real.pi) /
      Real.cos (((1 : ℝ) / 2) * Real.pi * x 1 + ((1 : ℝ) / 4) * Real.pi) - 1
  have hD' : 0 ≤ -(x 0 * q0) - x 1 * q1 + 4 * x 0 * x 1 := by
    dsimp [q0, q1]
    convert hD using 1 <;> ring
  by_cases hx0z : x 0 = 0
  · have hx1ne : x 1 ≠ 0 := by
      intro hx1z
      rw [hx0z, hx1z] at hpos
      norm_num at hpos
    have hq0 : 2 * (x 0) ^ 2 ≤ x 0 * q0 := by
      simp [hx0z]
    have hq1 : 2 * (x 1) ^ 2 < x 1 * q1 := by
      dsimp [q1]
      exact shifted_tan_product_gt_00550cacd40b (x 1) hx1l hx1u hx1ne
    nlinarith [hD', hq0, hq1, sq_nonneg (x 0 - x 1)]
  · have hq0 : 2 * (x 0) ^ 2 < x 0 * q0 := by
      dsimp [q0]
      exact shifted_tan_product_gt_00550cacd40b (x 0) hx0l hx0u hx0z
    have hq1 : 2 * (x 1) ^ 2 ≤ x 1 * q1 := by
      by_cases hx1z : x 1 = 0
      · simp [hx1z]
      · exact le_of_lt (by
          dsimp [q1]
          exact shifted_tan_product_gt_00550cacd40b (x 1) hx1l hx1u hx1z)
    nlinarith [hD', hq0, hq1, sq_nonneg (x 0 - x 1)]

#print axioms verify_lie_negative_00550cacd40b

end LeanBarrier.Generated
