import LeanBarrier.GeneratedCache.Helper_670f05fe377ab80926bb9d4be0b6a45c85863a93b6d8850cc835bb489e8796c9

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem shifted_tan_add_identity_00550cacd40b (v : ℝ)
    (hden : 0 < Real.cos v - Real.sin v) :
    Real.sin (Real.pi / 4 + v) / Real.cos (Real.pi / 4 + v) - 1 =
      2 * Real.sin v / (Real.cos v - Real.sin v) := by
  have hsqrtpos : 0 < Real.sqrt 2 := Real.sqrt_pos.2 (by norm_num)
  have hshift :
      Real.sqrt 2 / 2 * Real.cos v - Real.sqrt 2 / 2 * Real.sin v ≠ 0 := by
    have hz : 0 < (Real.sqrt 2 / 2) * (Real.cos v - Real.sin v) :=
      mul_pos (by positivity) hden
    apply ne_of_gt
    nlinarith
  rw [Real.sin_add, Real.cos_add, Real.sin_pi_div_four,
    Real.cos_pi_div_four]
  field_simp [ne_of_gt hden, ne_of_gt hsqrtpos, hshift] <;> ring

#print axioms shifted_tan_add_identity_00550cacd40b

end LeanBarrier.Generated
