import LeanBarrier.GeneratedCache.Helper_30254dde68a957a3d427b99fa1c868c2f7d94ccce887fc6a821e4ae96c1def8e

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem shifted_tan_bound_neg_00550cacd40b (s : ℝ)
    (hslo : (-1 : ℝ) / 4 ≤ s) (hsneg : s < 0) :
    Real.sin (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) /
        Real.cos (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) - 1 <
      2 * s := by
  have hp : 0 < Real.pi := Real.pi_pos
  have hp3 : 3 < Real.pi := Real.pi_gt_three
  let v : ℝ := -(((1 : ℝ) / 2) * Real.pi * s)
  have hcoef : 0 < ((1 : ℝ) / 2) * Real.pi :=
    mul_pos (by norm_num) hp
  have hvpos : 0 < v := by
    dsimp [v]
    exact neg_pos.mpr (mul_neg_of_pos_of_neg hcoef hsneg)
  have hv0 : 0 ≤ v := le_of_lt hvpos
  have hvle : v ≤ Real.pi / 8 := by
    dsimp [v]
    nlinarith [mul_nonneg (sub_nonneg.mpr hslo) (le_of_lt hp)]
  rcases trig_aux_00550cacd40b v hv0 hvle with ⟨hcos, hmul, htwo⟩
  have hsinpos : 0 < Real.sin v := by
    have hvc : 0 < v * Real.cos v := mul_pos hvpos hcos
    nlinarith
  have hden : 0 < Real.cos v + Real.sin v := by
    nlinarith
  have hform := shifted_tan_sub_identity_00550cacd40b v hden
  have hang :
      ((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi =
        Real.pi / 4 - v := by
    dsimp [v]
    ring
  have hcross :
      4 * v * (Real.cos v + Real.sin v) < 6 * Real.sin v := by
    have hvhalf : 2 * v < 1 := by
      have hz : 0 < (-s) * (Real.pi - 3) :=
        mul_pos (neg_pos.mpr hsneg) (sub_pos.mpr hp3)
      dsimp [v]
      nlinarith
    have hz : 0 < (1 - 2 * v) * Real.sin v :=
      mul_pos (by nlinarith) hsinpos
    nlinarith
  have hratio :
      4 * v / 3 < 2 * Real.sin v / (Real.cos v + Real.sin v) := by
    apply (lt_div_iff₀ hden).2
    nlinarith
  have hvrel : -2 * s < 4 * v / 3 := by
    have hz : 0 < (-s) * (Real.pi - 3) :=
      mul_pos (neg_pos.mpr hsneg) (sub_pos.mpr hp3)
    dsimp [v]
    nlinarith
  rw [hang, hform]
  nlinarith

#print axioms shifted_tan_bound_neg_00550cacd40b

end LeanBarrier.Generated
