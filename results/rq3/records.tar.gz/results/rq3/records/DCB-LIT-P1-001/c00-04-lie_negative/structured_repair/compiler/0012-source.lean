import LeanBarrier.GeneratedCache.Helper_cb0d2c23379921cece92b3cfc6f7f75503052cf81de143fee157b644ca176d25

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem shifted_tan_product_gt_00550cacd40b (s : ℝ)
    (hslo : (-1 : ℝ) / 4 ≤ s) (hshi : s ≤ (1 : ℝ) / 4) (hsne : s ≠ 0) :
    2 * s ^ 2 < s *
      (Real.sin (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) /
          Real.cos (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) - 1) := by
  rcases lt_or_gt_of_ne hsne with hsneg | hspos
  · have hq := shifted_tan_bound_neg_00550cacd40b s hslo hsneg
    have hm : 0 < s *
        ((Real.sin (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) /
              Real.cos (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) - 1) -
          2 * s) :=
      mul_pos_of_neg_of_neg hsneg (by nlinarith)
    nlinarith
  · have hq := shifted_tan_bound_pos_00550cacd40b s hshi hspos
    have hm : 0 < s *
        ((Real.sin (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) /
              Real.cos (((1 : ℝ) / 2) * Real.pi * s + ((1 : ℝ) / 4) * Real.pi) - 1) -
          2 * s) :=
      mul_pos hspos (by nlinarith)
    nlinarith

#print axioms shifted_tan_product_gt_00550cacd40b

end LeanBarrier.Generated
