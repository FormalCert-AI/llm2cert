import LeanBarrier.GeneratedCache.Context_e17eaf8be4ba561c32227fd46409196b4fcc5b62fdfe70e46bf58b5a88ab6707

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_00550cacd40b (hV : ContDiff ℝ 1 barrier_00550cacd40b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_00550cacd40b := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  have ht : Real.sin (Real.pi / 4) / Real.cos (Real.pi / 4) = (1 : ℝ) := by
    rw [Real.sin_pi_div_four, Real.cos_pi_div_four]
    apply div_self
    positivity
  have ha0 :
      (1 : ℝ) / 2 * Real.pi * x 0 + (1 : ℝ) / 4 * Real.pi = Real.pi / 4 := by
    rw [hx0]
    ring
  have ha1 :
      (1 : ℝ) / 2 * Real.pi * x 1 + (1 : ℝ) / 4 * Real.pi = Real.pi / 4 := by
    rw [hx1]
    ring
  rw [ha0, ha1, ht, hx0, hx1] at hbad
  norm_num at hbad

#print axioms verify_equilibrium_fixed_00550cacd40b

end LeanBarrier.Generated
