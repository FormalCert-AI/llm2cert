import LeanBarrier

#check Real.exp
#check Real.exp_pos
#check Real.exp_le_exp.mpr
#check Real.exp_add
