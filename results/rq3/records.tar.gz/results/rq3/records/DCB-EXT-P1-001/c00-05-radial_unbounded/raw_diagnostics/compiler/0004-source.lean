import LeanBarrier.GeneratedCache.Context_f39dabf9ab09230fcc1a4a82e39d06fc0ea824d0e611d01f42be7e61eda33b60

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_96dae1d24041 := by
  unfold LeanBarrier.Lyapunov.RadiallyUnbounded
  intro c
  by_cases hc : c ≤ 0
  · refine ⟨0, ?_⟩
    intro x hx
    rw [barrier_unfold_96dae1d24041]
    have he : 0 ≤ Real.exp ((2 : ℝ) * x 1) :=
      le_of_lt (Real.exp_pos _)
    have hp : 0 ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
      mul_nonneg (sq_nonneg _) he
    nlinarith [sq_nonneg (x 1)]
  · have hcpos : 0 < c := lt_of_not_ge hc
    let D : ℝ := max c 1
    have hDc : c ≤ D := by
      simp [D]
    have hD1 : 1 ≤ D := by
      simp [D]
    have hDpos : 0 < D := lt_of_lt_of_le zero_lt_one hD1
    have hDsq : c ≤ D ^ 2 := by
      have hDD : D ≤ D ^ 2 := by
        nlinarith
      exact hDc.trans hDD
    refine ⟨c + c * Real.exp ((2 : ℝ) * D), ?_⟩
    intro x hx
    have hxsum :
        c + c * Real.exp ((2 : ℝ) * D) ≤ x 0 ^ 2 + x 1 ^ 2 := by
      simpa [Fin.sum_univ_succ] using hx
    by_cases hy : c ≤ x 1 ^ 2
    · rw [barrier_unfold_96dae1d24041]
      have he : 0 ≤ Real.exp ((2 : ℝ) * x 1) :=
        le_of_lt (Real.exp_pos _)
      have hp : 0 ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
        mul_nonneg (sq_nonneg _) he
      nlinarith
    · have hylt : x 1 ^ 2 < c := lt_of_not_ge hy
      have hylower : -D ≤ x 1 := by
        by_contra hnot
        have hyneg : x 1 < -D := lt_of_not_ge hnot
        have hfac₁ : 0 < -x 1 - D := by
          linarith
        have hfac₂ : 0 < -x 1 + D := by
          linarith
        have hprodpos : 0 < (-x 1 - D) * (-x 1 + D) :=
          mul_pos hfac₁ hfac₂
        have hsquares : D ^ 2 < x 1 ^ 2 := by
          nlinarith
        linarith
      have harg : -(2 * D) ≤ (2 : ℝ) * x 1 := by
        linarith
      have hexp :
          Real.exp (-(2 * D)) ≤ Real.exp ((2 : ℝ) * x 1) :=
        Real.exp_le_exp.mpr harg
      have hx0 : c * Real.exp ((2 : ℝ) * D) ≤ x 0 ^ 2 := by
        nlinarith
      have hmul :
          (c * Real.exp ((2 : ℝ) * D)) * Real.exp (-(2 * D)) ≤
            (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
        mul_le_mul hx0 hexp
          (le_of_lt (Real.exp_pos _)) (sq_nonneg _)
      have hexpcancel :
          Real.exp ((2 : ℝ) * D) * Real.exp (-(2 * D)) = 1 := by
        calc
          Real.exp ((2 : ℝ) * D) * Real.exp (-(2 * D)) =
              Real.exp ((2 : ℝ) * D + -(2 * D)) := by
                rw [Real.exp_add]
          _ = 1 := by
            rw [show (2 : ℝ) * D + -(2 * D) = 0 by ring, Real.exp_zero]
      have hmain : c ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) := by
        calc
          c = (c * Real.exp ((2 : ℝ) * D)) * Real.exp (-(2 * D)) := by
            rw [mul_assoc, hexpcancel, mul_one]
          _ ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) := hmul
      rw [barrier_unfold_96dae1d24041]
      nlinarith [sq_nonneg (x 1)]

#print axioms verify_radial_unbounded_96dae1d24041

end LeanBarrier.Generated
