import LeanBarrier.GeneratedCache.Context_f39dabf9ab09230fcc1a4a82e39d06fc0ea824d0e611d01f42be7e61eda33b60

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_96dae1d24041 := by
  unfold LeanBarrier.Lyapunov.RadiallyUnbounded
  rintro ⟨c, hc⟩
  obtain ⟨y, hyR, hyV⟩ := hc 0
  rw [barrier_unfold_96dae1d24041] at hyV
  have hyexp : 0 ≤ Real.exp ((2 : ℝ) * y 1) :=
    (Real.exp_pos _).le
  have hyprod : 0 ≤ (y 0 ^ 2) * Real.exp ((2 : ℝ) * y 1) :=
    mul_nonneg (sq_nonneg _) hyexp
  have hc0 : 0 ≤ c := by
    nlinarith [sq_nonneg (y 1)]
  let D : ℝ := max c 1
  have hDc : c ≤ D := by
    simp [D]
  have hD1 : 1 ≤ D := by
    simp [D]
  have hDpos : 0 < D := by
    linarith
  have hDsq : c ≤ D ^ 2 := by
    have hDD : D ≤ D ^ 2 := by
      nlinarith
    exact hDc.trans hDD
  obtain ⟨x, hxR, hxV⟩ :=
    hc (c + c * Real.exp ((2 : ℝ) * D) + 1)
  have hxsum :
      c + c * Real.exp ((2 : ℝ) * D) + 1 ≤ x 0 ^ 2 + x 1 ^ 2 := by
    simpa [Fin.sum_univ_succ] using hxR
  by_cases hy : c < x 1 ^ 2
  · rw [barrier_unfold_96dae1d24041] at hxV
    have he : 0 ≤ Real.exp ((2 : ℝ) * x 1) :=
      (Real.exp_pos _).le
    have hp : 0 ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
      mul_nonneg (sq_nonneg _) he
    nlinarith
  · have hyc : x 1 ^ 2 ≤ c := le_of_not_gt hy
    have hylower : -D ≤ x 1 := by
      by_contra hnot
      have hyneg : x 1 < -D := lt_of_not_ge hnot
      have hfac₁ : 0 < -x 1 - D := by
        linarith
      have hfac₂ : 0 < -x 1 + D := by
        linarith
      have hprodpos : 0 < (-x 1 - D) * (-x 1 + D) :=
        mul_pos hfac₁ hfac₂
      have hsquares : D ^ 2 < x 1 ^ 2 := by
        nlinarith
      nlinarith
    have harg : -(2 * D) ≤ (2 : ℝ) * x 1 := by
      linarith
    have hexp :
        Real.exp (-(2 * D)) ≤ Real.exp ((2 : ℝ) * x 1) :=
      Real.exp_le_exp.mpr harg
    have hx0 :
        c * Real.exp ((2 : ℝ) * D) + 1 ≤ x 0 ^ 2 := by
      linarith
    have hmul :
        (c * Real.exp ((2 : ℝ) * D) + 1) * Real.exp (-(2 * D)) ≤
          (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
      mul_le_mul hx0 hexp (Real.exp_pos _).le (sq_nonneg _)
    have hexpcancel :
        Real.exp ((2 : ℝ) * D) * Real.exp (-(2 * D)) = 1 := by
      calc
        Real.exp ((2 : ℝ) * D) * Real.exp (-(2 * D)) =
            Real.exp ((2 : ℝ) * D + -(2 * D)) :=
          (Real.exp_add _ _).symm
        _ = Real.exp 0 := by
          congr 1
          ring
        _ = 1 := Real.exp_zero
    have hleft :
        (c * Real.exp ((2 : ℝ) * D) + 1) * Real.exp (-(2 * D)) =
          c + Real.exp (-(2 * D)) := by
      calc
        (c * Real.exp ((2 : ℝ) * D) + 1) * Real.exp (-(2 * D)) =
            c * (Real.exp ((2 : ℝ) * D) * Real.exp (-(2 * D))) +
              Real.exp (-(2 * D)) := by ring
        _ = c + Real.exp (-(2 * D)) := by rw [hexpcancel, mul_one]
    have hmain :
        c < (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) := by
      calc
        c < c + Real.exp (-(2 * D)) := by
          linarith [Real.exp_pos (-(2 * D))]
        _ = (c * Real.exp ((2 : ℝ) * D) + 1) *
              Real.exp (-(2 * D)) := hleft.symm
        _ ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) := hmul
    rw [barrier_unfold_96dae1d24041] at hxV
    nlinarith [sq_nonneg (x 1)]

#print axioms verify_radial_unbounded_96dae1d24041

end LeanBarrier.Generated
