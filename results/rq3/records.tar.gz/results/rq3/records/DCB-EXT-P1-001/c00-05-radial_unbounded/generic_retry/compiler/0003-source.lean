import LeanBarrier

#check Real.exp_zero
