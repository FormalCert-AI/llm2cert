import LeanBarrier.GeneratedCache.Context_4f141536f0ef68dc25041f133bac848be0aaf9e9a09ed21ef9f7a5912b92dd21

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem young_abs_75b60a1fd818 (u v : ℝ) :
    2 * |u * v| ≤ u ^ 2 + v ^ 2 := by
  have hp : 2 * (u * v) ≤ u ^ 2 + v ^ 2 := by
    nlinarith [sq_nonneg (u - v)]
  have hn : -(u ^ 2 + v ^ 2) ≤ 2 * (u * v) := by
    nlinarith [sq_nonneg (u + v)]
  have hh : |2 * (u * v)| ≤ u ^ 2 + v ^ 2 :=
    (abs_le).2 ⟨hn, hp⟩
  simpa [abs_mul] using hh

#print axioms young_abs_75b60a1fd818

end LeanBarrier.Generated
