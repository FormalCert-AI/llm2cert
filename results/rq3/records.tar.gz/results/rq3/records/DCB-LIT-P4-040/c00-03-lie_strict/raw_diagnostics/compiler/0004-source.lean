import LeanBarrier.GeneratedCache.Helper_9099cda08c9b092eeea7aada344be3a820d0c50b4dd18b74c7ff6addad22113b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem nonlinear_bounds_75b60a1fd818 (a b c d : ℝ)
    (haabs : |a| ≤ 1) (hcabs : |c| ≤ 1) :
    (-((1 : ℝ) / 5) * a * b ^ 2 * Real.cos c ≥
      -((1 : ℝ) / 5) * b ^ 2) ∧
    (-((6 : ℝ) / 25) * (b * Real.sin a * Real.tanh d) ≥
      -((3 : ℝ) / 25) * (a ^ 2 + b ^ 2)) ∧
    (-((4 : ℝ) / 25) * (a * b * c) ≥
      -((2 : ℝ) / 25) * (a ^ 2 + b ^ 2)) ∧
    (-((3 : ℝ) / 25) * (d * (a + b)) ≥
      -((3 : ℝ) / 50) * (a ^ 2 + b ^ 2 + 2 * d ^ 2)) := by
  have hcosabs : |Real.cos c| ≤ 1 := Real.abs_cos_le_one c
  have hacosabs : |a * Real.cos c| ≤ 1 := by
    calc
      |a * Real.cos c| = |a| * |Real.cos c| := by rw [abs_mul]
      _ ≤ 1 * |Real.cos c| :=
        mul_le_mul_of_nonneg_right haabs (abs_nonneg _)
      _ ≤ 1 := by simpa using hcosabs
  have hacos : a * Real.cos c ≤ 1 :=
    le_trans (le_abs_self _) hacosabs
  have hcos_lower :
      -((1 : ℝ) / 5) * a * b ^ 2 * Real.cos c ≥
        -((1 : ℝ) / 5) * b ^ 2 := by
    have hp := mul_nonneg (sq_nonneg b) (sub_nonneg.mpr hacos)
    nlinarith
  have htanh : |Real.tanh d| ≤ 1 :=
    le_of_lt (Real.abs_tanh_lt_one d)
  have hsina : |Real.sin a| ≤ |a| := Real.abs_sin_le_abs a
  have hsinprod : |b * Real.sin a * Real.tanh d| ≤ |a * b| := by
    have h₁ : |b| * |Real.sin a| ≤ |b| * |a| :=
      mul_le_mul_of_nonneg_left hsina (abs_nonneg b)
    calc
      |b * Real.sin a * Real.tanh d| =
          |b| * |Real.sin a| * |Real.tanh d| := by
            simp only [abs_mul]
      _ ≤ (|b| * |a|) * |Real.tanh d| :=
        mul_le_mul_of_nonneg_right h₁ (abs_nonneg _)
      _ ≤ (|b| * |a|) * 1 :=
        mul_le_mul_of_nonneg_left htanh
          (mul_nonneg (abs_nonneg b) (abs_nonneg a))
      _ = |a * b| := by rw [abs_mul]; ring
  have hsin_lower :
      -((6 : ℝ) / 25) * (b * Real.sin a * Real.tanh d) ≥
        -((3 : ℝ) / 25) * (a ^ 2 + b ^ 2) := by
    nlinarith [le_abs_self (b * Real.sin a * Real.tanh d),
      hsinprod, young_abs_75b60a1fd818 a b]
  have habcprod : |a * b * c| ≤ |a * b| := by
    calc
      |a * b * c| = |a * b| * |c| := by rw [abs_mul]
      _ ≤ |a * b| * 1 :=
        mul_le_mul_of_nonneg_left hcabs (abs_nonneg (a * b))
      _ = |a * b| := by ring
  have habc_lower :
      -((4 : ℝ) / 25) * (a * b * c) ≥
        -((2 : ℝ) / 25) * (a ^ 2 + b ^ 2) := by
    nlinarith [le_abs_self (a * b * c), habcprod,
      young_abs_75b60a1fd818 a b]
  have hdc_lower :
      -((3 : ℝ) / 25) * (d * (a + b)) ≥
        -((3 : ℝ) / 50) * (a ^ 2 + b ^ 2 + 2 * d ^ 2) := by
    nlinarith [le_abs_self (d * a), le_abs_self (d * b),
      young_abs_75b60a1fd818 d a, young_abs_75b60a1fd818 d b]
  exact ⟨hcos_lower, hsin_lower, habc_lower, hdc_lower⟩

#print axioms nonlinear_bounds_75b60a1fd818

end LeanBarrier.Generated
