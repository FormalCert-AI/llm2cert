import LeanBarrier

#check Real.cos
#check Real.sin
#check Real.tanh
#check Real.abs_cos_le_one
#check Real.abs_tanh_lt_one
#check Real.abs_sin_le_abs
