import LeanBarrier.GeneratedCache.Helper_0f14ec86746f94ed3675179742556c16c3092b25ad912a47aba024e1201807cc

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sphere_abs_bounds_75b60a1fd818 (a b c d : ℝ)
    (hs : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (3 : ℝ) / 5) :
    |a| ≤ 1 ∧ |c| ≤ 1 := by
  have ha_sq_lt : a ^ 2 < 1 := by
    nlinarith [hs, sq_nonneg b, sq_nonneg c, sq_nonneg d]
  have hc_sq_lt : c ^ 2 < 1 := by
    nlinarith [hs, sq_nonneg a, sq_nonneg b, sq_nonneg d]
  have ha_hi : a ≤ 1 := by
    by_contra h
    have hgt : 1 < a := lt_of_not_ge h
    have hp : 0 < (a - 1) * (a + 1) :=
      mul_pos (by linarith) (by linarith)
    nlinarith
  have ha_lo : -(1 : ℝ) ≤ a := by
    by_contra h
    have hlt : a < -1 := lt_of_not_ge h
    have hp : 0 < (a - 1) * (a + 1) :=
      mul_pos_of_neg_of_neg (by linarith) (by linarith)
    nlinarith
  have hc_hi : c ≤ 1 := by
    by_contra h
    have hgt : 1 < c := lt_of_not_ge h
    have hp : 0 < (c - 1) * (c + 1) :=
      mul_pos (by linarith) (by linarith)
    nlinarith
  have hc_lo : -(1 : ℝ) ≤ c := by
    by_contra h
    have hlt : c < -1 := lt_of_not_ge h
    have hp : 0 < (c - 1) * (c + 1) :=
      mul_pos_of_neg_of_neg (by linarith) (by linarith)
    nlinarith
  exact ⟨(abs_le).2 ⟨ha_lo, ha_hi⟩, (abs_le).2 ⟨hc_lo, hc_hi⟩⟩

#print axioms sphere_abs_bounds_75b60a1fd818

end LeanBarrier.Generated
