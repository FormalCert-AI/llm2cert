import LeanBarrier.GeneratedCache.Helper_4b902ddad3e292343edd03823505cfb729fa8dee29540adba6d10d622024b7db

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem scalar_lie_impossible_75b60a1fd818
    (a b c d : ℝ)
    (hs : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (3 : ℝ) / 5)
    (hL :
      ((13 : ℝ) / 10) * a ^ 2
        - ((1 : ℝ) / 5) * a * b ^ 2 * Real.cos c
        + ((7 : ℝ) / 5) * b ^ 2
        - ((6 : ℝ) / 25) * (b * Real.sin a * Real.tanh d)
        + ((3 : ℝ) / 2) * c ^ 2
        - ((4 : ℝ) / 25) * (a * b * c)
        + ((6 : ℝ) / 5) * d ^ 2
        - ((3 : ℝ) / 25) * (d * (a + b)) ≤ 0) : False := by
  have ha_sq_lt : a ^ 2 < 1 := by
    nlinarith [hs, sq_nonneg b, sq_nonneg c, sq_nonneg d]
  have hc_sq_lt : c ^ 2 < 1 := by
    nlinarith [hs, sq_nonneg a, sq_nonneg b, sq_nonneg d]
  have ha_hi : a ≤ 1 := by
    nlinarith [sq_nonneg (a - 1)]
  have ha_lo : -(1 : ℝ) ≤ a := by
    nlinarith [sq_nonneg (a + 1)]
  have hc_hi : c ≤ 1 := by
    nlinarith [sq_nonneg (c - 1)]
  have hc_lo : -(1 : ℝ) ≤ c := by
    nlinarith [sq_nonneg (c + 1)]
  have haabs : |a| ≤ 1 := (abs_le).2 ⟨ha_lo, ha_hi⟩
  have hcabs : |c| ≤ 1 := (abs_le).2 ⟨hc_lo, hc_hi⟩
  rcases nonlinear_bounds_75b60a1fd818 a b c d haabs hcabs with
    ⟨hcos, hsin, habc, hdc⟩
  nlinarith [hL, hcos, hsin, habc, hdc, hs,
    sq_nonneg a, sq_nonneg b, sq_nonneg c, sq_nonneg d]

#print axioms scalar_lie_impossible_75b60a1fd818

end LeanBarrier.Generated
