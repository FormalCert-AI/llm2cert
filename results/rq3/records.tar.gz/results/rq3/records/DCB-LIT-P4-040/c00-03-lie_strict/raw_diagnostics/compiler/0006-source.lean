import LeanBarrier.GeneratedCache.Helper_d133d81947b8aea5341514905f4bc80be1bbcdf7ec8b659dbf919a534e1ba2e2

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_positive_on_sphere_75b60a1fd818 (a b c d : ℝ)
    (hs : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (3 : ℝ) / 5) :
    ((-((2 : ℝ) * a)) * ((((-13 : ℝ) / 20) * a) +
        (((1 : ℝ) / 10) * b ^ 2 * Real.cos c)) +
      (-((2 : ℝ) * b)) * ((((-7 : ℝ) / 10) * b) +
        (((3 : ℝ) / 25) * Real.sin a * Real.tanh d)) +
      (-((2 : ℝ) * c)) * ((((-3 : ℝ) / 4) * c) +
        (((2 : ℝ) / 25) * a * b)) +
      (-((2 : ℝ) * d)) * ((((-3 : ℝ) / 5) * d) +
        (((3 : ℝ) / 50) * (a + b)))) > 0 := by
  rcases sphere_abs_bounds_75b60a1fd818 a b c d hs with ⟨ha, hc⟩
  rcases nonlinear_bounds_75b60a1fd818 a b c d ha hc with
    ⟨hcos, hsin, habc, hdc⟩
  nlinarith [hcos, hsin, habc, hdc, hs, sq_nonneg a, sq_nonneg b,
    sq_nonneg c, sq_nonneg d]

#print axioms lie_positive_on_sphere_75b60a1fd818

end LeanBarrier.Generated
