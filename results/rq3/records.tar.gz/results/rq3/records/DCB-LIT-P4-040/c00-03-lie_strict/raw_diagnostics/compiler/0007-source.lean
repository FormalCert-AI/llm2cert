import LeanBarrier.GeneratedCache.Helper_9ed22b97d2d5927eb0dcf2d2d84f8645076f8a8724a2ce4df51ff0bafa1a50d0

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_75b60a1fd818 (hV : ContDiff ℝ 1 barrier_75b60a1fd818) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_75b60a1fd818 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hL⟩
  set a : ℝ := x 0 with ha
  set b : ℝ := x 1 with hb
  set c : ℝ := x 2 with hc
  set d : ℝ := x 3 with hd
  rw [← ha, ← hb, ← hc, ← hd] at hB hL
  have hs : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (3 : ℝ) / 5 := by
    nlinarith [hB]
  have hp := lie_positive_on_sphere_75b60a1fd818 a b c d hs
  linarith

#print axioms verify_lie_strict_75b60a1fd818

end LeanBarrier.Generated
