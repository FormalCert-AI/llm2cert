import LeanBarrier.GeneratedCache.Context_c5e66cfcb7963000496b95fb7bebe59208fe7598febe0700a8db46c997d72a74

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sq_le_one_314fb4c8cb25 {z : ℝ}
    (hlo : -(1 : ℝ) ≤ z) (hhi : z ≤ (1 : ℝ)) : z ^ 2 ≤ (1 : ℝ) := by
  nlinarith

#print axioms sq_le_one_314fb4c8cb25

end LeanBarrier.Generated
