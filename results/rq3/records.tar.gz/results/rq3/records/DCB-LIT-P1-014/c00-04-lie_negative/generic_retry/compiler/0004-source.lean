import LeanBarrier

#check Real.mul_cos_le_sin
