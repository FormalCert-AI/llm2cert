import LeanBarrier.GeneratedCache.Context_817297f78bcb796619561a18d55eacc659304e4edbfc6008661a9b6bbc8c65be

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
lemma trig_product_bounds_98b3e0854be8 (z : ℝ)
    (hzl : (-3 : ℝ) / 2 ≤ z) (hzu : z ≤ (3 : ℝ) / 2) :
    (1 / 100 : ℝ) * z ^ 2 ≤ Real.sin z * Real.cos z * z ∧
      |Real.sin z * Real.cos z| ≤ |z| := by
  have hpos : ∀ y : ℝ, 0 ≤ y → y ≤ (3 : ℝ) / 2 →
      (1 / 100 : ℝ) * y ^ 2 ≤ Real.sin y * Real.cos y * y := by
    intro y hy0 hyu
    have hysq : y ^ 2 ≤ (9 : ℝ) / 4 := by
      have hp : 0 ≤ y * ((3 : ℝ) / 2 - y) :=
        mul_nonneg hy0 (sub_nonneg.mpr hyu)
      nlinarith
    have hch : (23 : ℝ) / 32 ≤ Real.cos (y / 2) := by
      have ht := Real.one_sub_sq_div_two_le_cos (y / 2)
      nlinarith
    have hchsq : ((23 : ℝ) / 32) ^ 2 ≤ Real.cos (y / 2) ^ 2 := by
      have hp : 0 ≤ (Real.cos (y / 2) - (23 : ℝ) / 32) *
          (Real.cos (y / 2) + (23 : ℝ) / 32) := by
        apply mul_nonneg
        · linarith
        · nlinarith
      nlinarith
    have hdouble := Real.cos_two_mul (y / 2)
    have hcf : (17 : ℝ) / 512 ≤ Real.cos y := by
      rw [show 2 * (y / 2) = y by ring] at hdouble
      nlinarith [hchsq]
    have hmono : MonotoneOn
        (fun t : ℝ => Real.sin t - t * Real.cos t)
        (Set.Icc 0 Real.pi) := by
      refine Convex.monotoneOn_of_deriv_nonneg (convex_Icc 0 Real.pi) ?_ ?_
      · fun_prop
      · intro t ht
        simp only [interior_Icc, Set.mem_Ioo] at ht
        have hs : 0 ≤ Real.sin t := by positivity
        have hd : HasDerivAt
            (fun u : ℝ => Real.sin u - u * Real.cos u)
            (t * Real.sin t) t := by
          convert (by fun_prop) using 1 <;> ring
        rw [hd.deriv]
        exact mul_nonneg (le_of_lt ht.1) hs
    have hzero : (0 : ℝ) ∈ Set.Icc 0 Real.pi := by
      constructor
      · exact le_rfl
      · nlinarith [Real.pi_gt_three]
    have hhalf : y / 2 ∈ Set.Icc 0 Real.pi := by
      constructor
      · positivity
      · nlinarith [Real.pi_gt_three]
    have hsc0 := hmono hzero hhalf (by positivity : (0 : ℝ) ≤ y / 2)
    have hsc : (y / 2) * Real.cos (y / 2) ≤ Real.sin (y / 2) := by
      simpa using hsc0
    have hmult := mul_le_mul_of_nonneg_right hsc (by linarith [hch] : 0 ≤ Real.cos (y / 2))
    have hsdouble := Real.sin_two_mul (y / 2)
    rw [show 2 * (y / 2) = y by ring] at hsdouble
    have hsin : y * Real.cos (y / 2) ^ 2 ≤ Real.sin y := by
      nlinarith [hmult]
    have hcoef : (1 : ℝ) / 100 ≤ Real.cos (y / 2) ^ 2 * Real.cos y := by
      calc
        (1 : ℝ) / 100 ≤ ((23 : ℝ) / 32) ^ 2 * ((17 : ℝ) / 512) := by norm_num
        _ ≤ Real.cos (y / 2) ^ 2 * ((17 : ℝ) / 512) := by
          exact mul_le_mul_of_nonneg_right hchsq (by norm_num)
        _ ≤ Real.cos (y / 2) ^ 2 * Real.cos y := by
          exact mul_le_mul_of_nonneg_left hcf (sq_nonneg _)
    calc
      (1 / 100 : ℝ) * y ^ 2 ≤
          (Real.cos (y / 2) ^ 2 * Real.cos y) * y ^ 2 :=
        mul_le_mul_of_nonneg_right hcoef (sq_nonneg y)
      _ = (y * Real.cos (y / 2) ^ 2) * Real.cos y * y := by ring
      _ ≤ Real.sin y * Real.cos y * y := by
        exact mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right hsin (by linarith [hcf] : 0 ≤ Real.cos y)) hy0
  constructor
  · by_cases hz : 0 ≤ z
    · exact hpos z hz hzu
    · have hz' : 0 ≤ -z := by linarith
      have hzu' : -z ≤ (3 : ℝ) / 2 := by linarith
      simpa [Real.sin_neg, Real.cos_neg] using hpos (-z) hz' hzu'
  · have hs := Real.abs_sin_le_abs z
    have hc := Real.abs_cos_le_one z
    calc
      |Real.sin z * Real.cos z| = |Real.sin z| * |Real.cos z| := abs_mul _ _
      _ ≤ |z| * 1 := mul_le_mul hs hc (abs_nonneg _) (abs_nonneg _)
      _ = |z| := mul_one _

#print axioms trig_product_bounds_98b3e0854be8

end LeanBarrier.Generated
