import LeanBarrier.GeneratedCache.Context_3b273808a3e21750e6d2cc2630565cefd0da8d0d30ee99fea41aa261bf6f5c05

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sin_linear_lower_on_three_quarters (x : ℝ) (hx0 : 0 ≤ x)
    (hx1 : x ≤ (3 : ℝ) / 4) :
    ((23 : ℝ) / 32) * x ≤ Real.sin x := by
  have hi :
      (∫ t in (0 : ℝ)..x, ((23 : ℝ) / 32)) ≤
        ∫ t in (0 : ℝ)..x, Real.cos t := by
    apply intervalIntegral.integral_mono_on hx0
    · exact (continuous_const : Continuous (fun _ : ℝ => ((23 : ℝ) / 32))).intervalIntegrable
    · exact Real.continuous_cos.intervalIntegrable
    · intro t ht
      have hleft : 0 ≤ (3 : ℝ) / 4 - t := by
        linarith [ht.2]
      have hright : 0 ≤ (3 : ℝ) / 4 + t := by
        linarith [ht.1]
      have hprod := mul_nonneg hleft hright
      have hcos := Real.one_sub_sq_div_two_le_cos (x := t)
      nlinarith
  have hi' : x * 23 / 32 ≤ Real.sin x := by
    simpa using hi
  calc
    ((23 : ℝ) / 32) * x = x * 23 / 32 := by ring
    _ ≤ Real.sin x := hi'

#print axioms sin_linear_lower_on_three_quarters

end LeanBarrier.Generated
