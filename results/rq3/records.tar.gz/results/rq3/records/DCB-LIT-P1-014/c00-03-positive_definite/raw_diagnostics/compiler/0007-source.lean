import LeanBarrier.GeneratedCache.Helper_4b0964c5af507baebf253efe1660d4fbf6f3e7dbb4461452f6e27eefa78ca226

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sin_sq_ge_quarter_sq_on_three_halves (x : ℝ)
    (hx0 : (-3 : ℝ) / 2 ≤ x) (hx1 : x ≤ (3 : ℝ) / 2) :
    x ^ 2 / 4 ≤ Real.sin x ^ 2 := by
  by_cases hx : 0 ≤ x
  · let s : ℝ := x / 2
    have hs0 : 0 ≤ s := by
      dsimp [s]
      linarith
    have hs1 : s ≤ (3 : ℝ) / 4 := by
      dsimp [s]
      linarith
    have hsin := sin_linear_lower_on_three_quarters s hs0 hs1
    have hleft : 0 ≤ (3 : ℝ) / 4 - s := by linarith
    have hright : 0 ≤ (3 : ℝ) / 4 + s := by linarith
    have hsquare := mul_nonneg hleft hright
    have hcos0 : 1 - s ^ 2 / 2 ≤ Real.cos s :=
      Real.one_sub_sq_div_two_le_cos
    have hcos : (23 : ℝ) / 32 ≤ Real.cos s := by
      nlinarith
    have hprod :
        0 ≤ (Real.sin s - ((23 : ℝ) / 32) * s) *
          (Real.cos s - 23 / 32) :=
      mul_nonneg (by linarith) (by linarith)
    have hid := Real.sin_two_mul s
    have htwos : 2 * s = x := by
      dsimp [s]
      ring
    rw [htwos] at hid
    have hlower : x / 2 ≤ Real.sin x := by
      nlinarith
    have hfac :
        0 ≤ (Real.sin x - x / 2) * (Real.sin x + x / 2) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith
  · have hxneg : x < 0 := lt_of_not_ge hx
    let s : ℝ := -x / 2
    have hs0 : 0 ≤ s := by
      dsimp [s]
      linarith
    have hs1 : s ≤ (3 : ℝ) / 4 := by
      dsimp [s]
      linarith
    have hsin := sin_linear_lower_on_three_quarters s hs0 hs1
    have hleft : 0 ≤ (3 : ℝ) / 4 - s := by linarith
    have hright : 0 ≤ (3 : ℝ) / 4 + s := by linarith
    have hsquare := mul_nonneg hleft hright
    have hcos0 : 1 - s ^ 2 / 2 ≤ Real.cos s :=
      Real.one_sub_sq_div_two_le_cos
    have hcos : (23 : ℝ) / 32 ≤ Real.cos s := by
      nlinarith
    have hprod :
        0 ≤ (Real.sin s - ((23 : ℝ) / 32) * s) *
          (Real.cos s - 23 / 32) :=
      mul_nonneg (by linarith) (by linarith)
    have hid := Real.sin_two_mul s
    have htwos : 2 * s = -x := by
      dsimp [s]
      ring
    rw [htwos, Real.sin_neg] at hid
    have hlower : -x / 2 ≤ -Real.sin x := by
      nlinarith
    have hfac :
        0 ≤ (-Real.sin x + x / 2) * (-Real.sin x - x / 2) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith

#print axioms sin_sq_ge_quarter_sq_on_three_halves

end LeanBarrier.Generated
