import LeanBarrier

#check Real.arctan
#check Real.sqrt
#check Real.sqrt_pos
#check Real.sq_sqrt
#check Real.sqrt_le_sqrt
#check Real.sqrt_nonneg
#check Real.abs_sin_le_abs
#check Real.sin_arctan
#check Real.strictMono_arctan.monotone
#check Real.abs_arctan_le_abs
