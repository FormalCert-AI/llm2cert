import LeanBarrier

#check Real.strictMono_arctan.monotone
#check Real.abs_arctan_le_abs
