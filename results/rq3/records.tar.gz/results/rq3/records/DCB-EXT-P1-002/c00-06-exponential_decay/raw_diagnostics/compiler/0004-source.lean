import LeanBarrier

#check Real.arctan_nonneg.mpr
#check Real.arctan_neg
#check Real.arctan_le_self
