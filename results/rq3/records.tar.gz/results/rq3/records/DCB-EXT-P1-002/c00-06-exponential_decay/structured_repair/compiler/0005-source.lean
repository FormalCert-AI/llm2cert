import LeanBarrier.GeneratedCache.Context_5e6db81e1fa119efeaeda57fd1056047517f23d83da1f37eee8f7cb2720ceb1d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem arctan_order_bounds_b6deee9d2a9b (x : ℝ) :
    (0 ≤ x → 0 ≤ Real.arctan x ∧ Real.arctan x ≤ x) ∧
      (x ≤ 0 → x ≤ Real.arctan x ∧ Real.arctan x ≤ 0) := by
  have hatan_diff : Differentiable ℝ Real.arctan := by
    intro y
    exact (Real.hasDerivAt_arctan y).differentiableAt
  have hatan_mono : Monotone Real.arctan := by
    apply monotone_of_deriv_nonneg hatan_diff
    intro y
    rw [(Real.hasDerivAt_arctan y).deriv]
    positivity
  let g : ℝ → ℝ := fun y => y - Real.arctan y
  have hg_diff : Differentiable ℝ g := by
    intro y
    exact ((hasDerivAt_id y).sub (Real.hasDerivAt_arctan y)).differentiableAt
  have hg_mono : Monotone g := by
    apply monotone_of_deriv_nonneg hg_diff
    intro y
    have hderiv := (hasDerivAt_id y).sub (Real.hasDerivAt_arctan y)
    rw [hderiv.deriv]
    have hd : 0 < 1 + y ^ 2 := by positivity
    have hi : (1 : ℝ) / (1 + y ^ 2) ≤ 1 := by
      apply (div_le_iff₀ hd).2
      nlinarith [sq_nonneg y]
    linarith
  constructor
  · intro hx
    constructor
    · have h := hatan_mono hx
      simpa using h
    · have h := hg_mono hx
      change g 0 ≤ g x at h
      dsimp [g] at h
      simpa using h
  · intro hx
    constructor
    · have h := hg_mono hx
      change g x ≤ g 0 at h
      dsimp [g] at h
      simpa using h
    · have h := hatan_mono hx
      simpa using h

#print axioms arctan_order_bounds_b6deee9d2a9b

end LeanBarrier.Generated
