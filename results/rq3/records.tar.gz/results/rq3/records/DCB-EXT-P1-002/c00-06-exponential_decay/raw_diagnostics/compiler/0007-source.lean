import LeanBarrier

#check Real.hasDerivAt_arctan
#check Real.arctan_le_zero.mpr
