import LeanBarrier.GeneratedCache.Context_5e6db81e1fa119efeaeda57fd1056047517f23d83da1f37eee8f7cb2720ceb1d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem arctan_self_mul_lower_b6deee9d2a9b (x : ℝ) :
    x ^ 2 / (1 + x ^ 2) ≤ x * Real.arctan x := by
  have hd : 0 < 1 + x ^ 2 := by positivity
  have hsqrt_pos : 0 < Real.sqrt (1 + x ^ 2) := Real.sqrt_pos.2 hd
  have hsqrt_sq : (Real.sqrt (1 + x ^ 2)) ^ 2 = 1 + x ^ 2 :=
    Real.sq_sqrt (le_of_lt hd)
  have hsqrt_one : 1 ≤ Real.sqrt (1 + x ^ 2) := by
    have h := Real.sqrt_le_sqrt (show (1 : ℝ) ≤ 1 + x ^ 2 by nlinarith [sq_nonneg x])
    simpa using h
  have hsqrt_le : Real.sqrt (1 + x ^ 2) ≤ 1 + x ^ 2 := by
    have hm := mul_nonneg (Real.sqrt_nonneg (1 + x ^ 2))
      (sub_nonneg.mpr hsqrt_one)
    nlinarith [hsqrt_sq, hm]
  have hsin : |x| / Real.sqrt (1 + x ^ 2) ≤ |Real.arctan x| := by
    have h := Real.abs_sin_le_abs (Real.arctan x)
    rw [Real.sin_arctan, abs_div,
      abs_of_nonneg (Real.sqrt_nonneg (1 + x ^ 2))] at h
    exact h
  have hsmall : |x| / (1 + x ^ 2) ≤ |x| / Real.sqrt (1 + x ^ 2) := by
    apply (div_le_div_iff₀ hd hsqrt_pos).2
    exact mul_le_mul_of_nonneg_left hsqrt_le (abs_nonneg x)
  have hbound : |x| / (1 + x ^ 2) ≤ |Real.arctan x| :=
    le_trans hsmall hsin
  rcases le_total 0 x with hx | hx
  · have ht : 0 ≤ Real.arctan x := Real.arctan_nonneg.mpr hx
    rw [abs_of_nonneg hx, abs_of_nonneg ht] at hbound
    have hm := mul_le_mul_of_nonneg_left hbound hx
    calc
      x ^ 2 / (1 + x ^ 2) = x * (x / (1 + x ^ 2)) := by ring
      _ ≤ x * Real.arctan x := hm
  · have htn : 0 ≤ Real.arctan (-x) :=
      Real.arctan_nonneg.mpr (neg_nonneg.mpr hx)
    have ht : Real.arctan x ≤ 0 := by
      rw [Real.arctan_neg] at htn
      linarith
    rw [abs_of_nonpos hx, abs_of_nonpos ht] at hbound
    have hm := mul_le_mul_of_nonneg_left hbound (neg_nonneg.mpr hx)
    calc
      x ^ 2 / (1 + x ^ 2) = (-x) * ((-x) / (1 + x ^ 2)) := by ring
      _ ≤ (-x) * (-Real.arctan x) := hm
      _ = x * Real.arctan x := by ring

#print axioms arctan_self_mul_lower_b6deee9d2a9b

end LeanBarrier.Generated
