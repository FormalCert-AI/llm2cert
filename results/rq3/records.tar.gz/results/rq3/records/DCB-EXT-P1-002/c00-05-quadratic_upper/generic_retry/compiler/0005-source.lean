import LeanBarrier

#check Real.hasSum_arctan
#check Real.arctan_le_zero
#check arctan_le_zero
#check Real.ofReal_arctan
#check ofReal_arctan
#check Real.arctan_le_arctan_iff
#check arctan_le_arctan_iff
#check Real.arctan_one
#check arctan_one
#check hasSum_arctan
#check Real.arctan_pos
#check arctan_pos
#check Real.hasSum_arctan_aux
#check hasSum_arctan_aux
