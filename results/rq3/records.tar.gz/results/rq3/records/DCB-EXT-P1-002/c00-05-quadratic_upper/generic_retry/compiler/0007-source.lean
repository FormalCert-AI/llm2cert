import LeanBarrier

#check Real.arctan_nonneg.mpr
#check Real.arctan_le_self
#check Real.arctan_nonpos.mpr
#check Real.arctan_neg
