import LeanBarrier.GeneratedCache.Context_70195e136e88dffdb40cc7e0f32a3b2644f85caef52268d7bee1cc279db3edf5

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem abs_arctan_le_abs_b6deee9d2a9b (x : ℝ) : |Real.arctan x| ≤ |x| := by
  have hd : ∀ y : ℝ, HasDerivAt Real.arctan (1 / (1 + y ^ 2)) y := fun y =>
    Real.hasDerivAt_arctan y
  have hdiff : Differentiable ℝ Real.arctan := fun y => (hd y).differentiableAt
  have hcont : Continuous Real.arctan := hdiff.continuous
  have hnonneg : ∀ y : ℝ, 0 ≤ y → 0 ≤ Real.arctan y ∧ Real.arctan y ≤ y := by
    intro y hy
    rcases hy.eq_or_lt with rfl | hypos
    · simp
    · obtain ⟨c, hc, hslope⟩ :=
        exists_deriv_eq_slope Real.arctan hypos hcont.continuousOn hdiff.differentiableOn
      have hslope' := hslope
      rw [(hd c).deriv] at hslope'
      have hden : 0 < 1 + c ^ 2 := by
        nlinarith [sq_nonneg c]
      have hderiv_nonneg : 0 ≤ 1 / (1 + c ^ 2) :=
        div_nonneg (by norm_num) hden.le
      have hderiv_le : 1 / (1 + c ^ 2) ≤ 1 := by
        exact (div_le_one hden).2 (by nlinarith [sq_nonneg c])
      have heq : 1 / (1 + c ^ 2) = Real.arctan y / y := by
        simpa using hslope'
      have hs0 : 0 ≤ Real.arctan y / y := by
        nlinarith
      have hs1 : Real.arctan y / y ≤ 1 := by
        nlinarith
      have ha0 : 0 ≤ Real.arctan y := by
        have h := (le_div_iff₀ hypos).1 hs0
        simpa using h
      have ha1 : Real.arctan y ≤ y := by
        have h := (div_le_iff₀ hypos).1 hs1
        simpa using h
      exact ⟨ha0, ha1⟩
  by_cases hx : 0 ≤ x
  · obtain ⟨ha0, ha1⟩ := hnonneg x hx
    rw [abs_of_nonneg hx, abs_of_nonneg ha0]
    exact ha1
  · have hxnonpos : x ≤ 0 := le_of_not_ge hx
    have hnx : 0 ≤ -x := by linarith
    obtain ⟨ha0, ha1⟩ := hnonneg (-x) hnx
    have hax : Real.arctan x ≤ 0 := by
      simpa using ha0
    rw [abs_of_nonpos hxnonpos, abs_of_nonpos hax]
    simpa using ha1

#print axioms abs_arctan_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
