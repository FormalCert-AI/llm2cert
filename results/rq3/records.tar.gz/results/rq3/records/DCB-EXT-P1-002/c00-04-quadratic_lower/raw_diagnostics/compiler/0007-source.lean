import LeanBarrier

#check Real.lipschitzWith_arctan.dist_le_mul
#check Real.dist_eq
