-- candidate-sha256: b6deee9d2a9b0aa81013eaf15d1566accee686c20dcf52c16519d8051a0a5c91
noncomputable def barrier_b6deee9d2a9b (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (4 : ℝ)) * Real.arctan (x 0) * x 1))
@[simp] theorem barrier_unfold_b6deee9d2a9b (x : LeanBarrier.State 2) : barrier_b6deee9d2a9b x = ((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (4 : ℝ)) * Real.arctan (x 0) * x 1)) := by
  rfl
def violationSet_quadratic_lower_b6deee9d2a9b : Set (LeanBarrier.State 2) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (((1 : ℝ) / (4 : ℝ)) * Real.arctan (x 0) * x 1)) < (((7 : ℝ) / (8 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2)))))}