import LeanBarrier

#check Real.arctan_le_zero.mpr
