import LeanBarrier

#check lipschitzWith_iff_dist_le_mul
#check lipschitzWith_iff_norm_inv_mul_le
#check LipschitzWith.norm_inv_mul_le_of_le
#check LipschitzWith.norm_le_mul'
#check LipschitzWith.nnorm_le_mul'
#check _root_.lipschitzWith_of_nnnorm_fderiv_le
#check lipschitzWith_iff_norm_div_le
