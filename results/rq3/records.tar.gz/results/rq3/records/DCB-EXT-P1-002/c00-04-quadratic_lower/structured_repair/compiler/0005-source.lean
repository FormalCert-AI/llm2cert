import LeanBarrier.GeneratedCache.Context_0792df8c108fbac868dfcbcb0f4a94de996705541a8838aeab65729daa8cc0c7

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
open Real in
theorem arctan_abs_le_abs_b6deee9d2a9b (x : ℝ) : |Real.arctan x| ≤ |x| := by
  have hd (y : ℝ) := (hasDerivAt_id y).sub (hasDerivAt_arctan y)
  have hc : Continuous (fun y : ℝ => y - Real.arctan y) :=
    continuous_iff_continuousAt.mpr fun y => (hd y).continuousAt
  have hm : Monotone (fun y : ℝ => y - Real.arctan y) := by
    apply monotone_of_deriv_nonneg hc
    intro y
    rw [(hd y).deriv]
    change 0 ≤ 1 - (1 + y ^ 2)⁻¹
    have hp : 0 < 1 + y ^ 2 := by positivity
    have heq : 1 - (1 + y ^ 2)⁻¹ = y ^ 2 / (1 + y ^ 2) := by
      field_simp [ne_of_gt hp]
    rw [heq]
    exact div_nonneg (sq_nonneg y) (le_of_lt hp)
  by_cases hx : 0 ≤ x
  · have hfx := hm hx
    have ht0 : 0 ≤ Real.arctan x := by
      have h := (Real.arctan_le_arctan_iff).2 hx
      simpa using h
    have htx : Real.arctan x ≤ x := by
      simpa using hfx
    rw [abs_of_nonneg hx, abs_of_nonneg ht0]
    exact htx
  · have hx0 : x ≤ 0 := le_of_not_ge hx
    have hfx := hm hx0
    have ht0 : Real.arctan x ≤ 0 := Real.arctan_le_zero.mpr hx0
    have hxt : x ≤ Real.arctan x := by
      simpa using hfx
    rw [abs_of_nonpos hx0, abs_of_nonpos ht0]
    linarith

#print axioms arctan_abs_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
