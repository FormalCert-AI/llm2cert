import LeanBarrier

#check Real.strictMono_arctan.monotone
#check Real.arctan_le_self
#check Real.arctan_neg
