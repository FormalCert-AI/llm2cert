import LeanBarrier.GeneratedCache.Context_8a74f0970cf2f3f9ad6a933718b13147ec5a60ccb4246d3cff0d3ce726ef8ba0

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem abs_arctan_le_abs_b6deee9d2a9b (u : ℝ) : |Real.arctan u| ≤ |u| := by
  have hd (x : ℝ) :
      HasDerivAt (fun y : ℝ => y - Real.arctan y)
        (1 - 1 / (1 + x ^ 2)) x := by
    simpa using (hasDerivAt_id x).sub (Real.hasDerivAt_arctan x)
  have hdiff : Differentiable ℝ (fun y : ℝ => y - Real.arctan y) := by
    intro x
    exact (hd x).differentiableAt
  have hderiv : ∀ x : ℝ,
      0 ≤ deriv (fun y : ℝ => y - Real.arctan y) x := by
    intro x
    rw [(hd x).deriv]
    have hp : 0 < 1 + x ^ 2 := by
      nlinarith [sq_nonneg x]
    have hi : 1 / (1 + x ^ 2) ≤ (1 : ℝ) := by
      apply (div_le_iff₀ hp).2
      nlinarith
    linarith
  have hmono : Monotone (fun y : ℝ => y - Real.arctan y) :=
    monotone_of_deriv_nonneg hdiff hderiv
  have hle_nonneg (x : ℝ) (hx : 0 ≤ x) : Real.arctan x ≤ x := by
    have h := hmono hx
    simpa using h
  by_cases hu : 0 ≤ u
  · have ha : 0 ≤ Real.arctan u := Real.arctan_nonneg.mpr hu
    rw [abs_of_nonneg hu, abs_of_nonneg ha]
    exact hle_nonneg u hu
  · have hnu : 0 ≤ -u := by linarith
    have hle := hle_nonneg (-u) hnu
    rw [Real.arctan_neg] at hle
    have hau : Real.arctan u ≤ 0 := by
      have := Real.arctan_nonneg.mpr hnu
      rw [Real.arctan_neg] at this
      linarith
    rw [abs_of_nonpos hau, abs_of_nonpos (le_of_not_ge hu)]
    linarith

#print axioms abs_arctan_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
