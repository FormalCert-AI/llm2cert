import LeanBarrier

#check Real.arctan_le_zero
#check Real.hasSum_arctan
#check Real.arctan_le_arctan_iff
#check Real.arctan_one
#check Real.arctan_pos
#check Real.measurable_arctan
