import LeanBarrier

#check Real.hasSum_arctan
#check Real.arctan_le_zero
#check Real.arctan_le_arctan_iff
#check Real.arctan_one
#check Real.arctan_pos
#check Real.measurable_arctan
#check Monotone.mul_strictMono'
#check Real.exists_seq_rat_strictMono_tendsto
#check StrictMono.mul_monotone'
#check StrictMono.monotone
