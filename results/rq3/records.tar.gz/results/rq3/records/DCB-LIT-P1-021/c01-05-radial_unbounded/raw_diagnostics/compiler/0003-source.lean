import LeanBarrier.GeneratedCache.Context_f84aa32ece4cf773fec37b40fe672893baca61b571768b706b381aa7a6512992

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_radial_unbounded_4d3ace7a9d15 (hV : ContDiff ℝ 1 barrier_4d3ace7a9d15) : LeanBarrier.Lyapunov.RadiallyUnbounded barrier_4d3ace7a9d15 := by
  intro C
  refine ⟨(|C| + 1) / Real.exp (-5 : ℝ), ?_⟩
  intro x hxR
  have hsR :
      (|C| + 1) / Real.exp (-5 : ℝ) ≤ x 0 ^ 2 + x 1 ^ 2 := by
    simpa [Fin.sum_univ_succ] using hxR
  have hs0 : 0 ≤ x 0 ^ 2 + x 1 ^ 2 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1)]
  have hq :
      (-5 : ℝ) ≤
        ((-10 : ℝ) * x 0 * x 1) / (x 0 ^ 2 + x 1 ^ 2) := by
    by_cases hz : x 0 ^ 2 + x 1 ^ 2 = 0
    · rw [hz]
      norm_num
    · have hsp : 0 < x 0 ^ 2 + x 1 ^ 2 :=
        lt_of_le_of_ne hs0 (Ne.symm hz)
      apply (le_div_iff₀ hsp).2
      nlinarith [sq_nonneg (x 0 - x 1)]
  have hexp :
      Real.exp (-5 : ℝ) ≤
        Real.exp (((-10 : ℝ) * x 0 * x 1) /
          (x 0 ^ 2 + x 1 ^ 2)) :=
    Real.exp_le_exp.mpr hq
  have hVlower :
      Real.exp (-5 : ℝ) * (x 0 ^ 2 + x 1 ^ 2) ≤
        barrier_4d3ace7a9d15 x := by
    calc
      Real.exp (-5 : ℝ) * (x 0 ^ 2 + x 1 ^ 2) =
          (x 0 ^ 2 + x 1 ^ 2) * Real.exp (-5 : ℝ) := by ring
      _ ≤ (x 0 ^ 2 + x 1 ^ 2) *
          Real.exp (((-10 : ℝ) * x 0 * x 1) /
            (x 0 ^ 2 + x 1 ^ 2)) :=
        mul_le_mul_of_nonneg_left hexp hs0
      _ = barrier_4d3ace7a9d15 x := by
        rw [barrier_unfold_4d3ace7a9d15]
  have hepos : 0 < Real.exp (-5 : ℝ) := Real.exp_pos _
  have hmul := mul_le_mul_of_nonneg_left hsR (le_of_lt hepos)
  have hcancel :
      Real.exp (-5 : ℝ) *
          ((|C| + 1) / Real.exp (-5 : ℝ)) = |C| + 1 := by
    field_simp
  rw [hcancel] at hmul
  have hCabs : C < |C| + 1 := by
    nlinarith [le_abs_self C]
  linarith

#print axioms verify_radial_unbounded_4d3ace7a9d15

end LeanBarrier.Generated
