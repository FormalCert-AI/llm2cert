import LeanBarrier.GeneratedCache.Helper_4d9b38c5628eac4b11c0e1ef4ddef893f62e8f76d3f6c478041c69bb03bfd66d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_46596114e3c1 (hV : ContDiff ℝ 1 barrier_46596114e3c1) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_46596114e3c1 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hr, hsmall, hnonzero, hder⟩
  let u : ℝ := x 0
  let v : ℝ := x 1
  let q : ℝ := ((23286329 : ℝ) / 1000000) * u +
    ((105411 : ℝ) / 20000) * v
  have hsmall' : u ^ 2 + (1 / 100 : ℝ) * q ^ 2 ≤ (1 / 10000 : ℝ) := by
    simpa [u, q] using hsmall
  have hq2 : q ^ 2 ≤ (1 : ℝ) / 100 := by
    nlinarith [sq_nonneg u]
  have hqle : q ≤ (1 : ℝ) / 10 := by
    nlinarith [sq_nonneg q]
  have hqge : -(1 : ℝ) / 10 ≤ q := by
    nlinarith [sq_nonneg q]
  have hqabs : |q| ≤ (1 : ℝ) / 10 := (abs_le).2 ⟨hqge, hqle⟩
  have htanh : q * Real.tanh q ≥ q ^ 2 / 2 :=
    tanh_mul_self_ge_half_sq_46596114e3c1 q hqabs
  have hsabs : |Real.sin u| ≤ |u| := Real.abs_sin_le_abs u
  have hsabs2 : |Real.sin u| ^ 2 ≤ |u| ^ 2 := by
    nlinarith [sq_nonneg (|u| - |Real.sin u|)]
  have hssq : (Real.sin u) ^ 2 ≤ u ^ 2 := by
    simpa only [sq_abs] using hsabs2
  have hqsin : q * Real.sin u ≤ (q ^ 2 + u ^ 2) / 2 := by
    nlinarith [sq_nonneg (q - Real.sin u)]
  have huq_upper : u * q ≤ (u ^ 2 + q ^ 2) / 2 := by
    nlinarith [sq_nonneg (u - q)]
  have huq_lower : -(u * q) ≤ (u ^ 2 + q ^ 2) / 2 := by
    nlinarith [sq_nonneg (u + q)]
  have hder' :
      (((2 : ℝ) * u + ((23286329 : ℝ) / 50000000) * q) * v) +
        ((35137 : ℝ) / 12500) * q *
          (((2943 : ℝ) / 4000) * Real.sin u +
            20 * Real.tanh (-q) - (1 / 10 : ℝ) * v) ≥ 0 := by
    dsimp [u, v, q]
    convert hder using 1 <;> ring
  rw [Real.tanh_neg] at hder'
  have hv : v =
      (q - ((23286329 : ℝ) / 1000000) * u) /
        ((105411 : ℝ) / 20000) := by
    dsimp [q]
    ring
  rw [hv] at hder'
  ring_nf at hder'
  have hz : u ^ 2 + q ^ 2 ≤ 0 := by
    nlinarith [htanh, hqsin, huq_upper, huq_lower]
  have hu0 : u = 0 := by
    nlinarith [sq_nonneg u, sq_nonneg q]
  have hq0 : q = 0 := by
    nlinarith [sq_nonneg u, sq_nonneg q]
  have hv0 : v = 0 := by
    rw [hu0, hq0] at hv
    norm_num at hv ⊢
    exact hv
  have hnonzero' : u ^ 2 + v ^ 2 > 0 := by
    simpa [u, v] using hnonzero
  rw [hu0, hv0] at hnonzero'
  norm_num at hnonzero'

#print axioms verify_lie_negative_46596114e3c1

end LeanBarrier.Generated
