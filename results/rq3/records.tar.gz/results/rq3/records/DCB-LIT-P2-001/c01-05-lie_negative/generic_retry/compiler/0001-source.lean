import LeanBarrier

#check Real.tanh
#check Real.exp
#check Real.exp_pos
#check Real.add_one_le_exp
#check Real.sinh
#check Real.cosh
#check Real.exp_neg
#check Real.tanh_neg
#check Real.sin
#check Real.abs_sin_le_abs
