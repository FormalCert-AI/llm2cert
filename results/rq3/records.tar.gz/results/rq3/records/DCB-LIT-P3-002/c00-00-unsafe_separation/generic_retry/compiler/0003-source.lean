import LeanBarrier.GeneratedCache.Context_1e9149565b8c05318336c51aa88e7a98b55c04251e9e6df6cc0d4190ff76ca58

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_unsafe_separation_8fbe56e92cb3 (hV : ContDiff ℝ 1 barrier_8fbe56e92cb3) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_unsafe_separation_8fbe56e92cb3 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_unsafe_separation_8fbe56e92cb3, Set.mem_setOf_eq] at hx
  rcases hx with ⟨_, _, _, _, hB, hunsafe⟩
  let u : ℝ := x 0
  let v : ℝ := x 1
  change
    ((1999999 : ℝ) / 4000000) * Real.pi ^ 2 -
        (((((3 : ℝ) / 2) * u ^ 2 + Real.cos u) - 1) +
          ((1 : ℝ) / 2) * v ^ 2 + ((1 : ℝ) / 1000) * u * v) ≥ 0
    at hB
  change u < -Real.pi ∨ u > Real.pi ∨ v < -Real.pi ∨ v > Real.pi at hunsafe
  have hcos : 1 - u ^ 2 / 2 ≤ Real.cos u := by
    exact Real.one_sub_sq_div_two_le_cos u
  have hupper :
      (((((3 : ℝ) / 2) * u ^ 2 + Real.cos u) - 1) +
          ((1 : ℝ) / 2) * v ^ 2 + ((1 : ℝ) / 1000) * u * v) ≤
        ((1999999 : ℝ) / 4000000) * Real.pi ^ 2 := by
    linarith
  have henergy :
      u ^ 2 + ((1 : ℝ) / 2) * v ^ 2 + ((1 : ℝ) / 1000) * u * v ≤
        ((1999999 : ℝ) / 4000000) * Real.pi ^ 2 := by
    linarith [hcos, hupper]
  have hvbound :
      ((1999999 : ℝ) / 4000000) * v ^ 2 ≤
        ((1999999 : ℝ) / 4000000) * Real.pi ^ 2 := by
    have hs : 0 ≤ (u + v / 2000) ^ 2 := sq_nonneg (u + v / 2000)
    nlinarith [henergy]
  have hubound :
      ((1999999 : ℝ) / 2000000) * u ^ 2 ≤
        ((1999999 : ℝ) / 4000000) * Real.pi ^ 2 := by
    have hs : 0 ≤ (v + u / 1000) ^ 2 := sq_nonneg (v + u / 1000)
    nlinarith [henergy]
  have hsquare_neg (z : ℝ) (hz : z < -Real.pi) :
      Real.pi ^ 2 < z ^ 2 := by
    have h₁ : 0 < -z - Real.pi := by
      linarith
    have h₂ : 0 < -z + Real.pi := by
      linarith [Real.pi_pos]
    have hp : 0 < (-z - Real.pi) * (-z + Real.pi) := mul_pos h₁ h₂
    nlinarith
  have hsquare_pos (z : ℝ) (hz : z > Real.pi) :
      Real.pi ^ 2 < z ^ 2 := by
    have h₁ : 0 < z - Real.pi := by
      linarith
    have h₂ : 0 < z + Real.pi := by
      linarith [Real.pi_pos]
    have hp : 0 < (z - Real.pi) * (z + Real.pi) := mul_pos h₁ h₂
    nlinarith
  rcases hunsafe with hu | hu | hv | hv
  · have hs : Real.pi ^ 2 < u ^ 2 := hsquare_neg u hu
    nlinarith [hubound]
  · have hs : Real.pi ^ 2 < u ^ 2 := hsquare_pos u hu
    nlinarith [hubound]
  · have hs : Real.pi ^ 2 < v ^ 2 := hsquare_neg v hv
    nlinarith [hvbound]
  · have hs : Real.pi ^ 2 < v ^ 2 := hsquare_pos v hv
    nlinarith [hvbound]

#print axioms verify_unsafe_separation_8fbe56e92cb3

end LeanBarrier.Generated
