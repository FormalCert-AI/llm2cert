import LeanBarrier.GeneratedCache.Context_d68b1b0a4ab129c046d839a84080358b69da3ca92587331f910bb06f24cfc157

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem trig_decay_af420dcfc775 (q : ℝ)
    (hqlo : -(3 : ℝ) / 2 ≤ q) (hqhi : q ≤ (3 : ℝ) / 2) :
    0 ≤ q * Real.sin q ∧
      (1 - Real.cos q) ^ 2 ≤ q * Real.sin q ∧
      (q ≠ 0 → 0 < q * Real.sin q) := by
  have hpi3 : (3 : ℝ) < Real.pi := Real.pi_gt_three
  have hqmem : q ∈ Set.Ioo (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> nlinarith
  have hcpos : 0 < Real.cos q := Real.cos_pos_of_mem_Ioo hqmem
  have hstrict : q ≠ 0 → 0 < q * Real.sin q := by
    intro hqne
    rcases lt_or_gt_of_ne hqne with hqneg | hqpos
    · have hnqpos : 0 < -q := by linarith
      have hnqlt : -q < Real.pi := by nlinarith
      have hspos : 0 < Real.sin (-q) :=
        Real.sin_pos_of_pos_of_lt_pi hnqpos hnqlt
      have hp : 0 < (-q) * Real.sin (-q) := mul_pos hnqpos hspos
      rw [Real.sin_neg] at hp
      nlinarith
    · have hqlt : q < Real.pi := by nlinarith
      exact mul_pos hqpos (Real.sin_pos_of_pos_of_lt_pi hqpos hqlt)
  have hnonneg : 0 ≤ q * Real.sin q := by
    by_cases hqzero : q = 0
    · simp [hqzero]
    · exact le_of_lt (hstrict hqzero)
  have hsin_sq : (Real.sin q) ^ 2 ≤ q * Real.sin q := by
    by_cases hqzero : q = 0
    · simp [hqzero]
    · rcases lt_or_gt_of_ne hqzero with hqneg | hqpos
      · have hnqpos : 0 < -q := by linarith
        have hnqlt : -q < Real.pi := by nlinarith
        have hsneg : 0 < Real.sin (-q) :=
          Real.sin_pos_of_pos_of_lt_pi hnqpos hnqlt
        have hsle : Real.sin (-q) ≤ -q := Real.sin_le (-q)
        rw [Real.sin_neg] at hsneg hsle
        have horder : q ≤ Real.sin q := by linarith
        have hsnonpos : Real.sin q ≤ 0 := by linarith
        have hmul : Real.sin q * Real.sin q ≤ q * Real.sin q :=
          mul_le_mul_of_nonpos_right horder hsnonpos
        nlinarith
      · have hqlt : q < Real.pi := by nlinarith
        have hspos : 0 < Real.sin q :=
          Real.sin_pos_of_pos_of_lt_pi hqpos hqlt
        have hsle : Real.sin q ≤ q := Real.sin_le q
        have hmul : Real.sin q * Real.sin q ≤ Real.sin q * q :=
          mul_le_mul_of_nonneg_left hsle (le_of_lt hspos)
        nlinarith
  have hc0 : 0 ≤ Real.cos q := le_of_lt hcpos
  have hc1 : Real.cos q ≤ 1 := Real.cos_le_one q
  have hprod : 0 ≤ Real.cos q * (1 - Real.cos q) :=
    mul_nonneg hc0 (sub_nonneg.mpr hc1)
  have htrig : (Real.sin q) ^ 2 + (Real.cos q) ^ 2 = 1 :=
    Real.sin_sq_add_cos_sq q
  have hh : (1 - Real.cos q) ^ 2 ≤ q * Real.sin q := by
    nlinarith [hsin_sq, hprod, htrig]
  exact ⟨hnonneg, hh, hstrict⟩

#print axioms trig_decay_af420dcfc775

end LeanBarrier.Generated
