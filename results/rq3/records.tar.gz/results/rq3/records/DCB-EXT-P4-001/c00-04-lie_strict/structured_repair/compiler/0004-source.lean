import LeanBarrier.GeneratedCache.Helper_b582c64f3d0cae2fcc4eec66d56873a8f9d03bb2af50af4bfdf4c31e6329d7c1

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_a7ad635fb238 (hV : ContDiff ℝ 1 barrier_a7ad635fb238) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_a7ad635fb238 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hL⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let c : ℝ := x 2
  let d : ℝ := x 3
  have hB' :
      (5 : ℝ) / 4 - a ^ 2 - b ^ 2 - c ^ 2 - d ^ 2 = 0 := by
    simpa [a, b, c, d] using hB
  have hL' :
      (-((2 : ℝ) * a)) *
            (b + ((-3 : ℝ) * a) /
              ((2 : ℝ) * Real.sqrt (a ^ 2 + 1))) +
          (-((2 : ℝ) * b)) *
            ((((-19 : ℝ) / 20) * Real.sin a - ((1 : ℝ) / 50) * b) +
                ((1 : ℝ) / 100) * c +
              ((-3 : ℝ) * b) /
                ((2 : ℝ) * Real.sqrt (b ^ 2 + 1))) +
          (-((2 : ℝ) * c)) *
            ((((-1 : ℝ) / 10) * c + ((1 : ℝ) / 50) * a) +
              ((-3 : ℝ) * c) /
                ((2 : ℝ) * Real.sqrt (c ^ 2 + 1))) +
          (-((2 : ℝ) * d)) *
            ((((-3 : ℝ) / 100) * d + ((1 : ℝ) / 100) * b) +
              ((-3 : ℝ) * d) /
                ((2 : ℝ) * Real.sqrt (d ^ 2 + 1))) ≤ 0 := by
    simpa [a, b, c, d] using hL
  have hr : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (5 : ℝ) / 4 := by
    nlinarith [hB']
  have ha2 : a ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr, sq_nonneg b, sq_nonneg c, sq_nonneg d]
  have hb2 : b ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr, sq_nonneg a, sq_nonneg c, sq_nonneg d]
  have hc2 : c ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr, sq_nonneg a, sq_nonneg b, sq_nonneg d]
  have hd2 : d ^ 2 ≤ (5 : ℝ) / 4 := by
    nlinarith [hr, sq_nonneg a, sq_nonneg b, sq_nonneg c]
  have hsa := sq_div_sqrt_lower_a7ad635fb238 a ha2
  have hsb := sq_div_sqrt_lower_a7ad635fb238 b hb2
  have hsc := sq_div_sqrt_lower_a7ad635fb238 c hc2
  have hsd := sq_div_sqrt_lower_a7ad635fb238 d hd2
  let s : ℝ :=
    a ^ 2 / Real.sqrt (a ^ 2 + 1) +
      b ^ 2 / Real.sqrt (b ^ 2 + 1) +
      c ^ 2 / Real.sqrt (c ^ 2 + 1) +
      d ^ 2 / Real.sqrt (d ^ 2 + 1)
  have hs : (5 : ℝ) / 6 ≤ s := by
    dsimp [s]
    nlinarith [hsa, hsb, hsc, hsd, hr]
  have hsinabs : |Real.sin a| ≤ |a| := by
    exact Real.abs_sin_le_abs
  have hprod :
      0 ≤ (|a| - |Real.sin a|) * (|a| + |Real.sin a|) :=
    mul_nonneg (sub_nonneg.mpr hsinabs)
      (add_nonneg (abs_nonneg a) (abs_nonneg (Real.sin a)))
  have hsin_sq : (Real.sin a) ^ 2 ≤ a ^ 2 := by
    nlinarith [hprod, sq_abs a, sq_abs (Real.sin a)]
  have hab : a * b ≤ (a ^ 2 + b ^ 2) / 2 := by
    nlinarith [sq_nonneg (a - b)]
  have hbs : -(b * Real.sin a) ≤ (a ^ 2 + b ^ 2) / 2 := by
    nlinarith [sq_nonneg (b + Real.sin a), hsin_sq]
  have hbc : b * c ≤ (b ^ 2 + c ^ 2) / 2 := by
    nlinarith [sq_nonneg (b - c)]
  have hac : a * c ≤ (a ^ 2 + c ^ 2) / 2 := by
    nlinarith [sq_nonneg (a - c)]
  have hbd : b * d ≤ (b ^ 2 + d ^ 2) / 2 := by
    nlinarith [sq_nonneg (b - d)]
  let q : ℝ :=
    a * b - ((19 : ℝ) / 20) * b * Real.sin a -
        ((1 : ℝ) / 50) * b ^ 2 +
      ((1 : ℝ) / 100) * b * c -
        ((1 : ℝ) / 10) * c ^ 2 +
      ((1 : ℝ) / 50) * a * c -
        ((3 : ℝ) / 100) * d ^ 2 +
      ((1 : ℝ) / 100) * b * d
  have hq :
      q ≤ ((197 : ℝ) / 200) * (a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2) := by
    dsimp [q]
    nlinarith [hab, hbs, hbc, hac, hbd, sq_nonneg a, sq_nonneg b,
      sq_nonneg c, sq_nonneg d]
  have hLform : 3 * s - 2 * q ≤ 0 := by
    dsimp [s, q]
    ring_nf at hL' ⊢
    exact hL'
  nlinarith [hs, hq, hr, hLform]

#print axioms verify_lie_strict_a7ad635fb238

end LeanBarrier.Generated
