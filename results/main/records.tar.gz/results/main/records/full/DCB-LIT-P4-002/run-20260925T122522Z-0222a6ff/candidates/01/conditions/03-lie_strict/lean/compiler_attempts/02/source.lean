import LeanBarrier.GeneratedCache.Context_cf475c84e02ce379a96e82369d098b6ee23a11af212bf048db77043c47a49789

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_382c708e1af0 (hV : ContDiff ℝ 1 barrier_382c708e1af0) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_382c708e1af0 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_strict_382c708e1af0, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hB, hL⟩
  let y : ℝ := x 0 + x 2
  let s : ℝ := x 0 + x 1 + x 2
  let z : ℝ := x 2
  let a : ℝ := Real.exp y
  let b : ℝ := Real.exp s
  have hab : a + b = 2 := by
    dsimp [a, b, y, s]
    linarith [hB]
  have ha : 0 < a := by
    simpa [a] using Real.exp_pos y
  have hb : 0 < b := by
    simpa [b] using Real.exp_pos s
  have ha_lt : a < 2 := by
    linarith [hab, hb]
  let q : ℝ := (1 : ℝ) / 8
  have hpow : ∀ n : ℕ, (Real.exp q) ^ n = Real.exp ((n : ℝ) * q) := by
    intro n
    induction n with
    | zero => simp
    | succ n ih =>
        calc
          (Real.exp q) ^ Nat.succ n = (Real.exp q) ^ n * Real.exp q := by rw [pow_succ]
          _ = Real.exp ((n : ℝ) * q) * Real.exp q := by rw [ih]
          _ = Real.exp ((n : ℝ) * q + q) := (Real.exp_add _ _).symm
          _ = Real.exp ((Nat.succ n : ℝ) * q) := by
            congr 1
            rw [Nat.cast_succ]
            ring
  have hthree : (2 : ℝ) < Real.exp ((3 : ℝ) / 4) := by
    have hbase : ((9 : ℝ) / 8) ≤ Real.exp q := by
      dsimp [q]
      nlinarith [Real.add_one_le_exp ((1 : ℝ) / 8)]
    calc
      (2 : ℝ) < ((9 : ℝ) / 8) ^ 6 := by norm_num
      _ ≤ (Real.exp q) ^ 6 := by gcongr
      _ = Real.exp ((6 : ℝ) * q) := hpow 6
      _ = Real.exp ((3 : ℝ) / 4) := by norm_num [q]
  have hy : y < (3 : ℝ) / 4 := by
    by_contra hny
    have hyge : (3 : ℝ) / 4 ≤ y := le_of_not_gt hny
    have hmono : Real.exp ((3 : ℝ) / 4) ≤ Real.exp y :=
      (Real.exp_le_exp).2 hyge
    have hey : Real.exp y < 2 := by
      simpa [a] using ha_lt
    linarith [hthree, hmono, hey]
  let yd : ℝ := 2 * y - (z + (1 : ℝ) / 2) ^ 2 - (7 : ℝ) / 4
  let sd : ℝ :=
    3 * y - (11 : ℝ) / 4 - (s - y + (1 : ℝ) / 2) ^ 2 - (z + 1) ^ 2
  have hyd : yd < 0 := by
    have hzsq : 0 ≤ (z + (1 : ℝ) / 2) ^ 2 := sq_nonneg _
    dsimp [yd]
    nlinarith [hy, hzsq]
  have hsd : sd < 0 := by
    have hssq : 0 ≤ (s - y + (1 : ℝ) / 2) ^ 2 := sq_nonneg _
    have hzsq : 0 ≤ (z + 1) ^ 2 := sq_nonneg _
    dsimp [sd]
    nlinarith [hy, hssq, hzsq]
  have hL' : -a * yd - b * sd ≤ 0 := by
    dsimp [a, b, yd, sd, y, s, z]
    ring_nf at hL ⊢
    exact hL
  have ht1 : 0 < -a * yd :=
    mul_pos_of_neg_of_neg (neg_lt_zero.mpr ha) hyd
  have ht2 : 0 < -b * sd :=
    mul_pos_of_neg_of_neg (neg_lt_zero.mpr hb) hsd
  nlinarith [hL', ht1, ht2]

#print axioms verify_lie_strict_382c708e1af0

end LeanBarrier.Generated
