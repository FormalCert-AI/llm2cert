import LeanBarrier

#check Real.exp_add
#check Real.exp_le_exp
