import LeanBarrier.GeneratedCache.Context_cf077397e0de8f989391bd267aa6e1193ac941eff43ffd80e1115470b151995a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_unsafe_separation_382c708e1af0 (hV : ContDiff ℝ 1 barrier_382c708e1af0) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_unsafe_separation_382c708e1af0 := by
  rintro ⟨x, hx⟩
  change
    (x 0 + x 1 + x 2 ≥ (1 : ℝ)) ∧
      ((2 : ℝ) - Real.exp (x 0 + x 2) -
        Real.exp (x 0 + x 1 + x 2) ≥ 0) at hx
  rcases hx with ⟨hs, hbar⟩
  have hexpTotal : (2 : ℝ) ≤ Real.exp (x 0 + x 1 + x 2) := by
    have h := Real.add_one_le_exp (x 0 + x 1 + x 2)
    linarith
  have hexpPartial : 0 < Real.exp (x 0 + x 2) := Real.exp_pos _
  linarith

#print axioms verify_unsafe_separation_382c708e1af0

end LeanBarrier.Generated
