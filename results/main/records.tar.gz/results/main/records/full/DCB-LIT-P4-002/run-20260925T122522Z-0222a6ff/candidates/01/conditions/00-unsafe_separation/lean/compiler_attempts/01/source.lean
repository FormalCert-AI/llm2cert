import LeanBarrier

#check Real.exp
#check Real.add_one_le_exp
#check Real.exp_pos
