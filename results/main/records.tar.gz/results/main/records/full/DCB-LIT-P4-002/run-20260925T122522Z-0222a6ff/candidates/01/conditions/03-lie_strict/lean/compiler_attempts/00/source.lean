import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 382c708e1af0c9628590c9b3b97b608ed94b1ce91fb08c7cd08d9764ff989cab
noncomputable def barrier_382c708e1af0 (x : LeanBarrier.State 3) : ℝ := (((2 : ℝ) - Real.exp ((x 0 + x 2))) - Real.exp ((x 0 + x 1 + x 2)))
@[simp] theorem barrier_unfold_382c708e1af0 (x : LeanBarrier.State 3) : barrier_382c708e1af0 x = (((2 : ℝ) - Real.exp ((x 0 + x 2))) - Real.exp ((x 0 + x 1 + x 2))) := by
  rfl
def violationSet_lie_strict_382c708e1af0 : Set (LeanBarrier.State 3) := {x | (((((2 : ℝ) - Real.exp ((x 0 + x 2))) - Real.exp ((x 0 + x 1 + x 2))) = (0 : ℝ)) ∧ (((((-Real.exp ((x 0 + x 2))) - Real.exp ((x 0 + x 1 + x 2))) * ((((((2 : ℝ) * x 0) + x 1 + ((2 : ℝ) * x 2)) - (x 0 ^ 2)) + (x 0 * x 2)) - (x 2 ^ 2))) + ((-Real.exp ((x 0 + x 1 + x 2))) * (((x 0 + (-2 : ℝ)) - x 1) - (x 1 ^ 2))) + (((-Real.exp ((x 0 + x 2))) - Real.exp ((x 0 + x 1 + x 2))) * (((((-2 : ℝ) - x 1) - x 2) + (x 0 ^ 2)) - (x 0 * x 2)))) ≤ (0 : ℝ)))}
def unsafeSet_382c708e1af0 : Set (LeanBarrier.State 3) := {x | (((x 0 + x 1 + x 2) ≥ (1 : ℝ)))}
def initialSet_382c708e1af0 : Set (LeanBarrier.State 3) := {x | ((x 0 ≤ (0 : ℝ)) ∧ (x 1 ≤ (0 : ℝ)) ∧ (x 2 ≤ (0 : ℝ)))}

#print axioms barrier_unfold_382c708e1af0

end LeanBarrier.Generated
