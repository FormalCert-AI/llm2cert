import LeanBarrier

#check Real.cos_le_one
