import LeanBarrier.GeneratedCache.Context_e5c56845c7dccf84089c1d19669b29719a8a90c26e510685a79575fdf0b5d138

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_fec95f333f90 (hV : ContDiff ℝ 1 barrier_fec95f333f90) : ¬ ∃ x : LeanBarrier.State 5, x ∈ violationSet_lie_negative_fec95f333f90 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_fec95f333f90, Set.mem_setOf_eq] at hx
  rcases hx with
    ⟨h0l, h0u, h1l, h1u, h2l, h2u, h3l, h3u, h4l, h4u,
      hsumu, hsuml, hpos, hLie⟩

  have ht1 : |x 0 - x 1| ≤ (9 : ℝ) / 4 := by
    apply abs_le.mpr
    constructor <;> nlinarith
  have ht2 : |(2 : ℝ) * x 0 + x 1| ≤ (9 : ℝ) / 4 := by
    apply abs_le.mpr
    constructor <;> nlinarith
  have ht3 : |x 0 + (2 : ℝ) * x 1| ≤ (9 : ℝ) / 4 := by
    apply abs_le.mpr
    constructor <;> nlinarith

  have hsin_quad : ∀ t : ℝ, |t| ≤ (9 : ℝ) / 4 →
      (5 : ℝ) / 32 * t ^ 2 ≤ t * Real.sin t := by
    intro t ht
    have hnonneg : ∀ y : ℝ, 0 ≤ y → y ≤ (9 : ℝ) / 4 →
        (5 : ℝ) / 32 * y ^ 2 ≤ y * Real.sin y := by
      intro y hy hyu
      have hbound := Real.sin_bound y
      have hbound_low := (abs_le.mp hbound).1
      rw [abs_of_nonneg hy] at hbound_low
      have hy_sq : y ^ 2 ≤ ((9 : ℝ) / 4) ^ 2 := by
        nlinarith
      have hmul : 0 ≤ y * (((9 : ℝ) / 4) ^ 2 - y ^ 2) :=
        mul_nonneg hy (sub_nonneg.mpr hy_sq)
      have hslope : (5 : ℝ) / 32 * y ≤ Real.sin y := by
        nlinarith [hbound_low, hmul]
      have hprod := mul_nonneg hy (sub_nonneg.mpr hslope)
      nlinarith
    by_cases ht0 : 0 ≤ t
    · have htu : t ≤ (9 : ℝ) / 4 := by
        calc
          t ≤ |t| := le_abs_self t
          _ ≤ (9 : ℝ) / 4 := ht
      exact hnonneg t ht0 htu
    · have htneg : t ≤ 0 := le_of_not_ge ht0
      have htu : -t ≤ (9 : ℝ) / 4 := by
        calc
          -t = |t| := by symm; exact abs_of_nonpos htneg
          _ ≤ (9 : ℝ) / 4 := ht
      have hh := hnonneg (-t) (neg_nonneg.mpr htneg) htu
      rw [Real.sin_neg] at hh
      nlinarith

  have hs1 := hsin_quad (x 0 - x 1) ht1
  have hs2 := hsin_quad ((2 : ℝ) * x 0 + x 1) ht2
  have hs3 := hsin_quad (x 0 + (2 : ℝ) * x 1) ht3

  let a : ℝ := x 0 ^ 2 + x 1 ^ 2 + (x 0 + x 1) ^ 2
  let b : ℝ := x 2 ^ 2 + x 3 ^ 2 + x 4 ^ 2
  let m : ℝ := (1 : ℝ) / 3 * (x 2 + x 3 + x 4)
  let p : ℝ := (x 2 - m) ^ 2 + (x 3 - m) ^ 2 + (x 4 - m) ^ 2
  let c : ℝ := x 0 * x 2 + x 1 * x 3 - (x 0 + x 1) * x 4
  let r : ℝ :=
    (x 0 - x 1) * Real.sin (x 0 - x 1) +
    ((2 : ℝ) * x 0 + x 1) * Real.sin ((2 : ℝ) * x 0 + x 1) +
    (x 0 + (2 : ℝ) * x 1) * Real.sin (x 0 + (2 : ℝ) * x 1)

  have hp : p ≤ b := by
    dsimp [p, m, b]
    nlinarith [sq_nonneg (x 2 + x 3 + x 4)]

  have hc : -c ≤ (15 : ℝ) / 128 * a + (32 : ℝ) / 15 * b := by
    dsimp [c, a, b]
    nlinarith
      [sq_nonneg ((15 : ℝ) * x 0 + 64 * x 2),
       sq_nonneg ((15 : ℝ) * x 1 + 64 * x 3),
       sq_nonneg (-(15 : ℝ) * (x 0 + x 1) + 64 * x 4)]

  have hr : (15 : ℝ) / 32 * a ≤ r := by
    dsimp [a, r]
    nlinarith [hs1, hs2, hs3]

  have hsin_sym : Real.sin (x 1 - x 0) = -Real.sin (x 0 - x 1) := by
    rw [show x 1 - x 0 = -(x 0 - x 1) by ring, Real.sin_neg]
  rw [hsin_sym] at hLie

  let eLie : ℝ := -b + (1 : ℝ) / 8 * (p - c - (1 : ℝ) / 2 * r)
  have hmaster : eLie ≥ 0 := by
    change -b + (1 : ℝ) / 8 * (p - c - (1 : ℝ) / 2 * r) ≥ 0
    dsimp [b, p, m, c, r]
    convert hLie using 1 <;> ring

  have hdecay :
      eLie ≤ -(15 : ℝ) / 1024 * a - (73 : ℝ) / 120 * b := by
    change -b + (1 : ℝ) / 8 * (p - c - (1 : ℝ) / 2 * r) ≤
      -(15 : ℝ) / 1024 * a - (73 : ℝ) / 120 * b
    nlinarith [hp, hc, hr]

  have ha : 0 ≤ a := by
    dsimp [a]
    positivity
  have hb : 0 ≤ b := by
    dsimp [b]
    positivity
  have habpos : 0 < a + b := by
    dsimp [a, b]
    nlinarith [hpos, sq_nonneg (x 0 + x 1)]
  nlinarith [hmaster, hdecay, ha, hb, habpos]

#print axioms verify_lie_negative_fec95f333f90

end LeanBarrier.Generated
