import LeanBarrier

#check Real.sin
#check Real.sin_bound
#check Real.sin_neg
