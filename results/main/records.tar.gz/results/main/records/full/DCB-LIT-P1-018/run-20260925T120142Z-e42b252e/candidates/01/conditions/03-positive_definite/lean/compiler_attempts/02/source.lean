import LeanBarrier.GeneratedCache.Context_f190f8a011b14a63e2dd6a4ac6b777f16e570b2200e095d1c0dc10e51fc759fb

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_edaa4ca0da6c (hV : ContDiff ℝ 1 barrier_edaa4ca0da6c) : ¬ ∃ x : LeanBarrier.State 5, x ∈ violationSet_positive_definite_edaa4ca0da6c := by
  rintro ⟨x, hx⟩
  simp only [violationSet_positive_definite_edaa4ca0da6c, Set.mem_setOf_eq] at hx
  rcases hx with ⟨h0lo, h0hi, h1lo, h1hi, h2lo, h2hi, h3lo, h3hi,
    h4lo, h4hi, hsumhi, hsumlo, hpos, hle⟩
  have hc1 : 0 ≤ 1 - Real.cos (x 0 - x 1) := by
    linarith [Real.cos_le_one (x 0 - x 1)]
  have hc2 : 0 ≤ 1 - Real.cos (2 * x 0 + x 1) := by
    linarith [Real.cos_le_one (2 * x 0 + x 1)]
  have hc3 : 0 ≤ 1 - Real.cos (x 0 + 2 * x 1) := by
    linarith [Real.cos_le_one (x 0 + 2 * x 1)]
  have hp1 :
      (1 / 16 : ℝ) * ((x 2) ^ 2 + (x 0) ^ 2) ≤
        (1 / 2 : ℝ) * (x 2) ^ 2 +
          (1 / 2 : ℝ) * ((x 0) * (x 2)) +
            (1 / 4 : ℝ) * (x 0) ^ 2 := by
    nlinarith [sq_nonneg (7 * x 2 + 4 * x 0), sq_nonneg (x 0)]
  have hp2 :
      (1 / 16 : ℝ) * ((x 3) ^ 2 + (x 1) ^ 2) ≤
        (1 / 2 : ℝ) * (x 3) ^ 2 +
          (1 / 2 : ℝ) * ((x 1) * (x 3)) +
            (1 / 4 : ℝ) * (x 1) ^ 2 := by
    nlinarith [sq_nonneg (7 * x 3 + 4 * x 1), sq_nonneg (x 1)]
  have hp3 :
      (1 / 16 : ℝ) * ((x 4) ^ 2 + (x 0 + x 1) ^ 2) ≤
        (1 / 2 : ℝ) * (x 4) ^ 2 -
          (1 / 2 : ℝ) * ((x 0 + x 1) * (x 4)) +
            (1 / 4 : ℝ) * (x 0 + x 1) ^ 2 := by
    nlinarith [sq_nonneg (7 * x 4 - 4 * (x 0 + x 1)),
      sq_nonneg (x 0 + x 1)]
  have hquad :
      (1 / 16 : ℝ) *
          ((x 0) ^ 2 + (x 1) ^ 2 + (x 2) ^ 2 + (x 3) ^ 2 + (x 4) ^ 2) ≤
        (1 / 2 : ℝ) * ((x 2) ^ 2 + (x 3) ^ 2 + (x 4) ^ 2) +
          (1 / 2 : ℝ) *
            (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4)) +
          (1 / 4 : ℝ) *
            ((x 0) ^ 2 + (x 1) ^ 2 + (x 0 + x 1) ^ 2) := by
    nlinarith [hp1, hp2, hp3, sq_nonneg (x 0 + x 1)]
  nlinarith [hquad, hc1, hc2, hc3]

#print axioms verify_positive_definite_edaa4ca0da6c

end LeanBarrier.Generated
