import LeanBarrier

#check Real.hasDerivAt_cos
#check Real.sin_le
#check Real.hasDerivAt_sin
#check Real.cos_neg
