import LeanBarrier.GeneratedCache.Context_0a677bad663e3f0c1355d3dc6407ad453b555a24b77f7e0612504deee34ad0da

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_edaa4ca0da6c (hV : ContDiff ℝ 1 barrier_edaa4ca0da6c) : ¬ ∃ x : LeanBarrier.State 5, x ∈ violationSet_v_at_equilibrium_edaa4ca0da6c := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_edaa4ca0da6c] at hx
  rcases hx with ⟨hx0, hx1, hx2, hx3, hx4, hx⟩
  norm_num [hx0, hx1, hx2, hx3, hx4] at hx

#print axioms verify_v_at_equilibrium_edaa4ca0da6c

end LeanBarrier.Generated
