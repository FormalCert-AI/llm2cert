import LeanBarrier.GeneratedCache.Context_c09d91b82f328a70d734d9343fc042d019ca4a6517203a0a3dab8ef6f1c0cd31

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_fec95f333f90 (hV : ContDiff ℝ 1 barrier_fec95f333f90) : ¬ ∃ x : LeanBarrier.State 5, x ∈ violationSet_v_at_equilibrium_fec95f333f90 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, h2, h3, h4, hbad⟩
  simpa [h0, h1, h2, h3, h4] using hbad

#print axioms verify_v_at_equilibrium_fec95f333f90

end LeanBarrier.Generated
