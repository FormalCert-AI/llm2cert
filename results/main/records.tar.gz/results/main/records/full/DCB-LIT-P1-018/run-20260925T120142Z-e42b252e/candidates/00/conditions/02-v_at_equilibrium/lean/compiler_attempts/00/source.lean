import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fec95f333f90e0ecbfee8280e0b709d5777dd30419c0424f364c243e09f693c6
noncomputable def barrier_fec95f333f90 (x : LeanBarrier.State 5) : ℝ := ((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (8 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4))))
@[simp] theorem barrier_unfold_fec95f333f90 (x : LeanBarrier.State 5) : barrier_fec95f333f90 x = ((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (8 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4)))) := by
  rfl
def violationSet_v_at_equilibrium_fec95f333f90 : Set (LeanBarrier.State 5) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (x 3 = (0 : ℝ)) ∧ (x 4 = (0 : ℝ)) ∧ (((((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (8 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4)))) > (0 : ℝ))) ∨ ((((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (8 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4)))) < (0 : ℝ)))))}

#print axioms barrier_unfold_fec95f333f90

end LeanBarrier.Generated
