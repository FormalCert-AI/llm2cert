import LeanBarrier.GeneratedCache.Context_f8e929625b9a7c4e82f91a4ca1d31ba5422334c2bd3dec63889f10bf1203312c

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem cos_quadratic_lower_fec95f333f90 (t : ℝ)
    (hlo : ((-9 : ℝ) / 4) ≤ t) (hhi : t ≤ ((9 : ℝ) / 4)) :
    ((37 : ℝ) / 128) * t ^ 2 ≤ 1 - Real.cos t := by
  have hpoly_nonneg : ∀ s : ℝ, 0 ≤ s →
      0 ≤ 1 - s ^ 2 / 2 + s ^ 4 / 24 - Real.cos s := by
    intro s hs
    have hm2 : MonotoneOn
        (fun y : ℝ => -1 + y ^ 2 / 2 + Real.cos y) (Set.Ici 0) := by
      apply monotoneOn_of_deriv_nonneg (convex_Ici (0 : ℝ))
      · intro y hy
        fun_prop
      · intro y hy
        have hy0 : 0 ≤ y := by
          exact interior_subset hy
        have hd : HasDerivAt
            (fun z : ℝ => -1 + z ^ 2 / 2 + Real.cos z)
            (y - Real.sin y) y := by
          convert (((hasDerivAt_const y (-1 : ℝ)).add
            (((hasDerivAt_id y).pow 2).const_mul (1 / 2 : ℝ))).add
              (Real.hasDerivAt_cos y)) using 1 <;> ring
        rw [hd.deriv]
        linarith [Real.sin_le hy0]
    have hm1 : MonotoneOn
        (fun y : ℝ => -y + y ^ 3 / 6 + Real.sin y) (Set.Ici 0) := by
      apply monotoneOn_of_deriv_nonneg (convex_Ici (0 : ℝ))
      · intro y hy
        fun_prop
      · intro y hy
        have hyI : y ∈ Set.Ici (0 : ℝ) := interior_subset hy
        have hy0 : 0 ≤ y := hyI
        have h2 : 0 ≤ -1 + y ^ 2 / 2 + Real.cos y := by
          have h := hm2 (by simp) hyI hy0
          simpa using h
        have hd : HasDerivAt
            (fun z : ℝ => -z + z ^ 3 / 6 + Real.sin z)
            (-1 + y ^ 2 / 2 + Real.cos y) y := by
          convert (((hasDerivAt_id y).neg.add
            (((hasDerivAt_id y).pow 3).const_mul (1 / 6 : ℝ))).add
              (Real.hasDerivAt_sin y)) using 1 <;> ring
        rw [hd.deriv]
        exact h2
    have hm0 : MonotoneOn
        (fun y : ℝ => 1 - y ^ 2 / 2 + y ^ 4 / 24 - Real.cos y)
        (Set.Ici 0) := by
      apply monotoneOn_of_deriv_nonneg (convex_Ici (0 : ℝ))
      · intro y hy
        fun_prop
      · intro y hy
        have hyI : y ∈ Set.Ici (0 : ℝ) := interior_subset hy
        have hy0 : 0 ≤ y := hyI
        have h1 : 0 ≤ -y + y ^ 3 / 6 + Real.sin y := by
          have h := hm1 (by simp) hyI hy0
          simpa using h
        have hd : HasDerivAt
            (fun z : ℝ => 1 - z ^ 2 / 2 + z ^ 4 / 24 - Real.cos z)
            (-y + y ^ 3 / 6 + Real.sin y) y := by
          convert ((((hasDerivAt_const y (1 : ℝ)).sub
            (((hasDerivAt_id y).pow 2).const_mul (1 / 2 : ℝ))).add
              (((hasDerivAt_id y).pow 4).const_mul (1 / 24 : ℝ))).sub
                (Real.hasDerivAt_cos y)) using 1 <;> ring
        rw [hd.deriv]
        exact h1
    have hsI : s ∈ Set.Ici (0 : ℝ) := hs
    have h := hm0 (by simp) hsI hs
    simpa using h
  have hTaylor : Real.cos t ≤ 1 - t ^ 2 / 2 + t ^ 4 / 24 := by
    by_cases ht : 0 ≤ t
    · linarith [hpoly_nonneg t ht]
    · have hnt : 0 ≤ -t := by linarith
      have h := hpoly_nonneg (-t) hnt
      rw [Real.cos_neg] at h
      nlinarith
  have hi : 0 ≤ (t + (9 : ℝ) / 4) * ((9 : ℝ) / 4 - t) :=
    mul_nonneg (by linarith) (by linarith)
  have ht2 : t ^ 2 ≤ (81 : ℝ) / 16 := by
    nlinarith [hi]
  have hp : 0 ≤ t ^ 2 * ((81 : ℝ) / 16 - t ^ 2) :=
    mul_nonneg (sq_nonneg t) (by linarith)
  nlinarith [hTaylor, hp]

#print axioms cos_quadratic_lower_fec95f333f90

end LeanBarrier.Generated
