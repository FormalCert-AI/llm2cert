import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: edaa4ca0da6ca88f2d25d0a29f8970625c620e6566e8ca341d223b845045b95b
noncomputable def barrier_edaa4ca0da6c (x : LeanBarrier.State 5) : ℝ := ((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (2 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4))) + (((1 : ℝ) / (4 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + ((x 0 + x 1) ^ 2))))
@[simp] theorem barrier_unfold_edaa4ca0da6c (x : LeanBarrier.State 5) : barrier_edaa4ca0da6c x = ((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (2 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4))) + (((1 : ℝ) / (4 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + ((x 0 + x 1) ^ 2)))) := by
  rfl
def violationSet_positive_definite_edaa4ca0da6c : Set (LeanBarrier.State 5) := {x | ((x 0 ≥ ((-3 : ℝ) / (4 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (4 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (4 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (4 : ℝ))) ∧ (x 2 ≥ ((-6 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((6 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-6 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((6 : ℝ) / (5 : ℝ))) ∧ (x 4 ≥ ((-6 : ℝ) / (5 : ℝ))) ∧ (x 4 ≤ ((6 : ℝ) / (5 : ℝ))) ∧ ((x 0 + x 1) ≤ ((3 : ℝ) / (4 : ℝ))) ∧ ((x 0 + x 1) ≥ ((-3 : ℝ) / (4 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2)) > (0 : ℝ)) ∧ (((((1 : ℝ) / (2 : ℝ)) * ((x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2))) + (((1 : ℝ) / (2 : ℝ)) * (((1 : ℝ) - Real.cos ((x 0 - x 1))) + ((1 : ℝ) - Real.cos ((((2 : ℝ) * x 0) + x 1))) + ((1 : ℝ) - Real.cos ((x 0 + ((2 : ℝ) * x 1)))))) + (((1 : ℝ) / (2 : ℝ)) * (((x 0 * x 2) + (x 1 * x 3)) - ((x 0 + x 1) * x 4))) + (((1 : ℝ) / (4 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + ((x 0 + x 1) ^ 2)))) ≤ (0 : ℝ)))}

#print axioms barrier_unfold_edaa4ca0da6c

end LeanBarrier.Generated
