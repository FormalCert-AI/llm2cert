import LeanBarrier.GeneratedCache.Context_9840a9ccb1a88411db783ea66a8e73e19f3e25631ee4664fb0858cc57da01eb4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_4d3ace7a9d15 (hV : ContDiff ℝ 1 barrier_4d3ace7a9d15) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_4d3ace7a9d15 := by
  rintro ⟨x, hx⟩
  change
    (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧
      (((x 0 ^ 2) + (x 1 ^ 2)) *
          Real.exp ((((-10 : ℝ) * x 0 * x 1) /
            ((x 0 ^ 2) + (x 1 ^ 2)))) ≤ (0 : ℝ)) at hx
  rcases hx with ⟨hs, hnonpos⟩
  have hexp :
      0 < Real.exp ((((-10 : ℝ) * x 0 * x 1) /
        ((x 0 ^ 2) + (x 1 ^ 2)))) := Real.exp_pos _
  nlinarith

#print axioms verify_positive_definite_4d3ace7a9d15

end LeanBarrier.Generated
