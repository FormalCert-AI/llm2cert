import LeanBarrier.GeneratedCache.Context_0d48b4ec0fa639983967c86dd757a25ea8a75293d4ecb98dcb2cced7eff3bc52

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_4d3ace7a9d15 (hV : ContDiff ℝ 1 barrier_4d3ace7a9d15) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_4d3ace7a9d15 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hs, hD⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let s : ℝ := a ^ 2 + b ^ 2
  let e : ℝ := Real.exp (((-10 : ℝ) * a * b) / s)
  let f : ℝ := 4 * a ^ 3 - a ^ 2 * b - 6 * a * b ^ 2 - b ^ 3
  let g : ℝ := a ^ 3 + 4 * a ^ 2 * b + a * b ^ 2 - 6 * b ^ 3
  let D : ℝ :=
    (2 * a * e + s * e *
        (((-10 : ℝ) * b * s - (-20 : ℝ) * a * b * a) / s ^ 2)) * f +
      (2 * b * e + s * e *
        (((-10 : ℝ) * a * s - (-20 : ℝ) * a * b * b) / s ^ 2)) * g
  change 0 < s at hs
  change D ≥ 0 at hD
  have habpos : 0 < a ^ 2 + b ^ 2 := by
    simpa only [s] using hs
  have hDform : D = -2 * s ^ 2 * e := by
    dsimp only [D, f, g]
    rw [show s = a ^ 2 + b ^ 2 by rfl]
    field_simp [ne_of_gt habpos]
    <;> ring
  rw [hDform] at hD
  have he : 0 < e := by
    dsimp only [e]
    exact Real.exp_pos _
  have hs2 : 0 < s ^ 2 := pow_pos hs 2
  have hp : 0 < s ^ 2 * e := mul_pos hs2 he
  nlinarith [hp]

#print axioms verify_lie_negative_4d3ace7a9d15

end LeanBarrier.Generated
