import LeanBarrier.GeneratedCache.Context_8cdf4bfbc7399158e35c790329d70279a85c6c72f39443756324cf77ef7966d3

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_4d3ace7a9d15 (hV : ContDiff ℝ 1 barrier_4d3ace7a9d15) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_4d3ace7a9d15 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx⟩
  rcases hx with hpos | hneg
  · simp [hx0, hx1] at hpos
  · simp [hx0, hx1] at hneg

#print axioms verify_v_at_equilibrium_4d3ace7a9d15

end LeanBarrier.Generated
