import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 8fe286fd6b8f522fcf2fc746f75c3fba4432d504347490b711b052820d6bed03
noncomputable def barrier_8fe286fd6b8f (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_8fe286fd6b8f (x : LeanBarrier.State 2) : barrier_8fe286fd6b8f x = (((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2)) := by
  rfl
def violationSet_v_at_equilibrium_8fe286fd6b8f : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ ((((((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2)) > (0 : ℝ))) ∨ (((((x 0 ^ 2) * Real.exp (((40 : ℝ) * x 1))) + (x 1 ^ 2)) < (0 : ℝ)))))}

#print axioms barrier_unfold_8fe286fd6b8f

end LeanBarrier.Generated
