import LeanBarrier.GeneratedCache.Context_3054e0ca9d39d3cec5d78e84548e00345c22998214d6f3255057502256f86795

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_8fe286fd6b8f (hV : ContDiff ℝ 1 barrier_8fe286fd6b8f) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_8fe286fd6b8f := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, hbad⟩
  simp [h0, h1] at hbad

#print axioms verify_v_at_equilibrium_8fe286fd6b8f

end LeanBarrier.Generated
