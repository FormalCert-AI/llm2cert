import LeanBarrier.GeneratedCache.Context_da39cfd57a57aacceb7533af30ac880bf52d4d6bd6e18d8c970b745c2223d83f

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_e1faa1bcd0b3 (hV : ContDiff ℝ 1 barrier_e1faa1bcd0b3) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_e1faa1bcd0b3 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hq, hD⟩
  have ha2 : x 0 ^ 2 ≤ (43 : ℝ) / 100 := by
    nlinarith [sq_nonneg (x 1), sq_nonneg (x 2)]
  have hb2 : x 1 ^ 2 ≤ (43 : ℝ) / 100 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 2)]
  have hc2 : x 2 ^ 2 ≤ (43 : ℝ) / 100 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1)]
  have ha : |x 0| ≤ (7 : ℝ) / 10 := by
    apply abs_le.mpr
    constructor
    · nlinarith [sq_nonneg (x 0 + (7 : ℝ) / 10)]
    · nlinarith [sq_nonneg (x 0 - (7 : ℝ) / 10)]
  have hb : |x 1| ≤ (7 : ℝ) / 10 := by
    apply abs_le.mpr
    constructor
    · nlinarith [sq_nonneg (x 1 + (7 : ℝ) / 10)]
    · nlinarith [sq_nonneg (x 1 - (7 : ℝ) / 10)]
  have hc : |x 2| ≤ (7 : ℝ) / 10 := by
    apply abs_le.mpr
    constructor
    · nlinarith [sq_nonneg (x 2 + (7 : ℝ) / 10)]
    · nlinarith [sq_nonneg (x 2 - (7 : ℝ) / 10)]
  have hsin12 : |Real.sin (x 1 + x 2)| ≤ (1 : ℝ) :=
    Real.abs_sin_le_one _
  have hcos0 : |Real.cos (x 0)| ≤ (1 : ℝ) :=
    Real.abs_cos_le_one _
  have hsin1 : |Real.sin (x 1)| ≤ (1 : ℝ) :=
    Real.abs_sin_le_one _
  have htanh0 : |Real.tanh (x 0)| ≤ (1 : ℝ) :=
    (Real.abs_tanh_lt_one _).le
  have hexp0 : Real.exp (-(x 2 ^ 2)) ≤ (1 : ℝ) := by
    rw [← Real.exp_zero]
    exact Real.exp_le_exp.mpr (by nlinarith [sq_nonneg (x 2)])
  have habsexp0 : |Real.exp (-(x 2 ^ 2))| ≤ (1 : ℝ) := by
    rw [abs_of_pos (Real.exp_pos _)]
    exact hexp0
  have hcross0 : x 0 * Real.sin (x 1 + x 2) ≤ (7 : ℝ) / 10 := by
    calc
      x 0 * Real.sin (x 1 + x 2) ≤ |x 0 * Real.sin (x 1 + x 2)| := le_abs_self _
      _ = |x 0| * |Real.sin (x 1 + x 2)| := by rw [abs_mul]
      _ ≤ ((7 : ℝ) / 10) * 1 :=
        mul_le_mul ha hsin12 (abs_nonneg _) (by norm_num)
      _ = (7 : ℝ) / 10 := by norm_num
  have hbc : |x 1| * |Real.cos (x 0)| ≤ ((7 : ℝ) / 10) * 1 :=
    mul_le_mul hb hcos0 (abs_nonneg _) (by norm_num)
  have hbce :
      (|x 1| * |Real.cos (x 0)|) * |Real.exp (-(x 2 ^ 2))| ≤
        (((7 : ℝ) / 10) * 1) * 1 :=
    mul_le_mul hbc habsexp0 (abs_nonneg _) (by norm_num)
  have hcross1 :
      x 1 * Real.cos (x 0) * Real.exp (-(x 2 ^ 2)) ≤ (7 : ℝ) / 10 := by
    calc
      x 1 * Real.cos (x 0) * Real.exp (-(x 2 ^ 2)) ≤
          |x 1 * Real.cos (x 0) * Real.exp (-(x 2 ^ 2))| := le_abs_self _
      _ = (|x 1| * |Real.cos (x 0)|) * |Real.exp (-(x 2 ^ 2))| := by
        rw [abs_mul, abs_mul]
      _ ≤ (((7 : ℝ) / 10) * 1) * 1 := hbce
      _ = (7 : ℝ) / 10 := by norm_num
  have hct : |x 2| * |Real.tanh (x 0)| ≤ ((7 : ℝ) / 10) * 1 :=
    mul_le_mul hc htanh0 (abs_nonneg _) (by norm_num)
  have hcts :
      (|x 2| * |Real.tanh (x 0)|) * |Real.sin (x 1)| ≤
        (((7 : ℝ) / 10) * 1) * 1 :=
    mul_le_mul hct hsin1 (abs_nonneg _) (by norm_num)
  have hcross2 :
      x 2 * Real.tanh (x 0) * Real.sin (x 1) ≤ (7 : ℝ) / 10 := by
    calc
      x 2 * Real.tanh (x 0) * Real.sin (x 1) ≤
          |x 2 * Real.tanh (x 0) * Real.sin (x 1)| := le_abs_self _
      _ = (|x 2| * |Real.tanh (x 0)|) * |Real.sin (x 1)| := by
        rw [abs_mul, abs_mul]
      _ ≤ (((7 : ℝ) / 10) * 1) * 1 := hcts
      _ = (7 : ℝ) / 10 := by norm_num
  nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2)]

#print axioms verify_lie_strict_e1faa1bcd0b3

end LeanBarrier.Generated
