-- candidate-sha256: e1faa1bcd0b3bf4127d501dc01a0d6f0bc5ef4baea3b062a12c2042d31b1cf97
noncomputable def barrier_e1faa1bcd0b3 (x : LeanBarrier.State 3) : ℝ := (((((43 : ℝ) / (100 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2))
@[simp] theorem barrier_unfold_e1faa1bcd0b3 (x : LeanBarrier.State 3) : barrier_e1faa1bcd0b3 x = (((((43 : ℝ) / (100 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) := by
  rfl
def violationSet_lie_strict_e1faa1bcd0b3 : Set (LeanBarrier.State 3) := {x | (((((((43 : ℝ) / (100 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-31 : ℝ) / (50 : ℝ)) * x 0) + (((1 : ℝ) / (10 : ℝ)) * Real.sin ((x 1 + x 2))))) + ((-((2 : ℝ) * x 1)) * ((((-67 : ℝ) / (100 : ℝ)) * x 1) + (((2 : ℝ) / (25 : ℝ)) * Real.cos (x 0) * Real.exp ((-(x 2 ^ 2)))))) + ((-((2 : ℝ) * x 2)) * ((((-16 : ℝ) / (25 : ℝ)) * x 2) + (((9 : ℝ) / (100 : ℝ)) * Real.tanh (x 0) * Real.sin (x 1))))) ≤ (0 : ℝ)))}
def unsafeSet_e1faa1bcd0b3 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (2 : ℝ)) ∧ (x 0 ≤ ((13 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-12 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((21 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((27 : ℝ) / (10 : ℝ))))}
def initialSet_e1faa1bcd0b3 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-1 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((1 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((1 : ℝ) / (2 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((1 : ℝ) / (5 : ℝ))))}

theorem verify_lie_strict_e1faa1bcd0b3 (hV : ContDiff ℝ 1 barrier_e1faa1bcd0b3) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_e1faa1bcd0b3
