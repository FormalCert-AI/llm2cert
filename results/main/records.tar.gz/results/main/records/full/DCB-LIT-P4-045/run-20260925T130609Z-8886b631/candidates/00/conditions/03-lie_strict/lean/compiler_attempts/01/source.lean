import LeanBarrier

#check Real.sin
#check Real.abs_sin_le_one
#check Real.cos
#check Real.abs_cos_le_one
#check Real.tanh
#check Real.abs_tanh_lt_one
#check Real.exp
#check Real.exp_zero
#check Real.exp_le_exp.mpr
#check Real.exp_pos
