import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: df2e6f5a7edf0ad22e034e35a575686ba103748d4b2ab94156479c8c1217a847
noncomputable def barrier_df2e6f5a7edf (x : LeanBarrier.State 9) : ℝ := ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7))
@[simp] theorem barrier_unfold_df2e6f5a7edf (x : LeanBarrier.State 9) : barrier_df2e6f5a7edf x = ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) := by
  rfl
def violationSet_v_at_equilibrium_df2e6f5a7edf : Set (LeanBarrier.State 9) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (x 3 = (0 : ℝ)) ∧ (x 4 = (0 : ℝ)) ∧ (x 5 = (0 : ℝ)) ∧ (x 6 = (0 : ℝ)) ∧ (x 7 = (0 : ℝ)) ∧ (x 8 = (0 : ℝ)) ∧ (((((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) > (0 : ℝ))) ∨ ((((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) < (0 : ℝ)))))}

#print axioms barrier_unfold_df2e6f5a7edf

end LeanBarrier.Generated
