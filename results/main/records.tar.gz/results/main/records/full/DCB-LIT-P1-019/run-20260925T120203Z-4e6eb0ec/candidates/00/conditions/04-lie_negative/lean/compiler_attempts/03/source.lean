import LeanBarrier.GeneratedCache.Context_cdc46c97bf4d07dd16b0e9a48e248bace8122a4808552c494915b2db14a91022

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem trig_box_facts_53521fe36d27 (z : ℝ)
    (hl : (-3 : ℝ) / 2 ≤ z) (hu : z ≤ (3 : ℝ) / 2) :
    0 ≤ z * (Real.sin z * Real.cos z) ∧
    (Real.sin z * Real.cos z) ^ 2 ≤ z * (Real.sin z * Real.cos z) ∧
    (Real.sin z * Real.cos z = 0 ↔ z = 0) ∧
    (z * (Real.sin z * Real.cos z) = 0 ↔ z = 0) := by
  have hhalf : (3 : ℝ) / 2 < Real.pi / 2 := by
    nlinarith [Real.pi_gt_three]
  have hzlo : -(Real.pi / 2) < z := by
    nlinarith
  have hzhi : z < Real.pi / 2 := by
    nlinarith
  have hc : 0 < Real.cos z :=
    Real.cos_pos_of_mem_Ioo ⟨hzlo, hzhi⟩
  by_cases hz : z = 0
  · subst z
    simp
  rcases lt_or_gt_of_ne hz with hzneg | hzpos
  · have hmpos : 0 < -z := by linarith
    have hmpi : -z < Real.pi := by
      nlinarith [Real.pi_pos]
    have hsmp : 0 < Real.sin (-z) :=
      Real.sin_pos_of_pos_of_lt_pi hmpos hmpi
    have hsneg : Real.sin z < 0 := by
      rw [Real.sin_neg] at hsmp
      linarith
    have hsle : Real.sin (-z) ≤ -z :=
      Real.sin_le (le_of_lt hmpos)
    have hzsin : z ≤ Real.sin z := by
      rw [Real.sin_neg] at hsle
      linarith
    have hfac : 0 ≤ (-Real.sin z) * (1 - Real.cos z) :=
      mul_nonneg (by linarith) (by linarith [Real.cos_le_one z])
    have hsg : Real.sin z ≤ Real.sin z * Real.cos z := by
      nlinarith [hfac]
    have hzg : z ≤ Real.sin z * Real.cos z := by
      linarith
    have hgneg : Real.sin z * Real.cos z < 0 :=
      mul_neg_of_neg_of_pos hsneg hc
    have hp : 0 < z * (Real.sin z * Real.cos z) :=
      mul_pos_of_neg_of_neg hzneg hgneg
    have hm :
        0 ≤ (-(Real.sin z * Real.cos z)) *
          ((Real.sin z * Real.cos z) - z) :=
      mul_nonneg (by linarith) (by linarith)
    refine ⟨le_of_lt hp, ?_, ?_, ?_⟩
    · nlinarith [hm]
    · constructor
      · intro h
        nlinarith
      · intro h
        exact (hz h).elim
    · constructor
      · intro h
        nlinarith
      · intro h
        exact (hz h).elim
  · have hzpi : z < Real.pi := by
      nlinarith [Real.pi_pos]
    have hspos : 0 < Real.sin z :=
      Real.sin_pos_of_pos_of_lt_pi hzpos hzpi
    have hsle : Real.sin z ≤ z :=
      Real.sin_le (le_of_lt hzpos)
    have hfac : 0 ≤ Real.sin z * (1 - Real.cos z) :=
      mul_nonneg (le_of_lt hspos) (by linarith [Real.cos_le_one z])
    have hg_le : Real.sin z * Real.cos z ≤ z := by
      nlinarith [hfac]
    have hgpos : 0 < Real.sin z * Real.cos z :=
      mul_pos hspos hc
    have hp : 0 < z * (Real.sin z * Real.cos z) :=
      mul_pos hzpos hgpos
    have hm :
        0 ≤ (Real.sin z * Real.cos z) *
          (z - Real.sin z * Real.cos z) :=
      mul_nonneg (le_of_lt hgpos) (by linarith)
    refine ⟨le_of_lt hp, ?_, ?_, ?_⟩
    · nlinarith [hm]
    · constructor
      · intro h
        nlinarith
      · intro h
        exact (hz h).elim
    · constructor
      · intro h
        nlinarith
      · intro h
        exact (hz h).elim

#print axioms trig_box_facts_53521fe36d27

end LeanBarrier.Generated
