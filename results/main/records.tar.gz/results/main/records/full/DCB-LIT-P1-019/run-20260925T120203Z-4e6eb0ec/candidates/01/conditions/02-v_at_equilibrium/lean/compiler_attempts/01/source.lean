import LeanBarrier.GeneratedCache.Context_0d457838c7ddf20498566ee394340dbd5d306e489a112eeeca11179e97e83243

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_df2e6f5a7edf (hV : ContDiff ℝ 1 barrier_df2e6f5a7edf) : ¬ ∃ x : LeanBarrier.State 9, x ∈ violationSet_v_at_equilibrium_df2e6f5a7edf := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx2, hx3, hx4, hx5, hx6, hx7, hx8, hbad⟩
  norm_num [hx0, hx1, hx2, hx3, hx4, hx5, hx6, hx7, hx8] at hbad

#print axioms verify_v_at_equilibrium_df2e6f5a7edf

end LeanBarrier.Generated
