import LeanBarrier.GeneratedCache.Context_4fe76bc24718aa6bc07ee331b620075287ce6192c7e98e16cdb7aea2fc6ff241

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_53521fe36d27 (hV : ContDiff ℝ 1 barrier_53521fe36d27) : ¬ ∃ x : LeanBarrier.State 9, x ∈ violationSet_equilibrium_fixed_53521fe36d27 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_equilibrium_fixed_53521fe36d27, Set.mem_setOf_eq] at hx
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, h6, h7, h8, hbad⟩
  simp [h0, h1, h2, h3, h4, h5, h6, h7, h8] at hbad

#print axioms verify_equilibrium_fixed_53521fe36d27

end LeanBarrier.Generated
