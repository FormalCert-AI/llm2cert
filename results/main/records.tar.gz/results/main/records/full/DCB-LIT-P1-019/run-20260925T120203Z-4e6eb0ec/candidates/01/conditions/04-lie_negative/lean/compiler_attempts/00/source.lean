import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: df2e6f5a7edf0ad22e034e35a575686ba103748d4b2ab94156479c8c1217a847
noncomputable def barrier_df2e6f5a7edf (x : LeanBarrier.State 9) : ℝ := ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7))
@[simp] theorem barrier_unfold_df2e6f5a7edf (x : LeanBarrier.State 9) : barrier_df2e6f5a7edf x = ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((5 : ℝ) / (8 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) := by
  rfl
def violationSet_lie_negative_df2e6f5a7edf : Set (LeanBarrier.State 9) := {x | ((x 0 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 2 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 3 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 4 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 4 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 5 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 5 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 6 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 6 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 7 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 7 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 8 ≥ ((-3 : ℝ) / (2 : ℝ))) ∧ (x 8 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2) + (x 8 ^ 2)) > (0 : ℝ)) ∧ (((x 0 * (((-x 0) + (((1 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 4 ^ 2)))) + (x 1 * (((((-1 : ℝ) / (2 : ℝ)) * x 0) - x 1) + (((1 : ℝ) / (10 : ℝ)) * x 7))) + (x 2 * (((-x 2) + (((1 : ℝ) / (2 : ℝ)) * x 3)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 2)))) + (x 3 * ((((-1 : ℝ) / (2 : ℝ)) * x 2) - x 3)) + (x 4 * ((-x 4) + (((1 : ℝ) / (2 : ℝ)) * x 5))) + (x 5 * (((((-1 : ℝ) / (2 : ℝ)) * x 4) - x 5) + (((1 : ℝ) / (10 : ℝ)) * (x 1 ^ 2)))) + (((((5 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6)) + (((1 : ℝ) / (4 : ℝ)) * Real.cos (x 6) * Real.cos (x 6) * x 7) + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * (-Real.sin (x 6)) * x 7)) * x 7) + ((x 7 + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 6) * Real.cos (x 6))) * (((((-Real.sin (x 6)) * Real.cos (x 6)) - x 7) - (Real.sin (x 8) * Real.cos (x 8))) - (((1 : ℝ) / (10 : ℝ)) * x 1))) + (Real.sin (x 8) * Real.cos (x 8) * (x 7 - x 8))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_df2e6f5a7edf

end LeanBarrier.Generated
