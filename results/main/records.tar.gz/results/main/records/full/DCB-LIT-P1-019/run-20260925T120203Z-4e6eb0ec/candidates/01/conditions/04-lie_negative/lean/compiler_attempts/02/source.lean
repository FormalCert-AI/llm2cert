import LeanBarrier.GeneratedCache.Context_3883e9a43840fd0f58239d2108d902a85e2a1500079a61a047f0d0d41c4ea18a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem trig_box_df2e6f5a7edf (y : ℝ)
    (hyl : ((-3 : ℝ) / 2) ≤ y) (hyu : y ≤ ((3 : ℝ) / 2)) :
    0 ≤ y * (Real.sin y * Real.cos y) ∧
    (Real.sin y * Real.cos y) ^ 2 ≤ y * (Real.sin y * Real.cos y) ∧
    (y * (Real.sin y * Real.cos y) = 0 → y = 0) := by
  have hcos : 0 < Real.cos y := Real.cos_pos_of_mem_Ioo (by
    constructor <;> nlinarith [Real.pi_gt_three])
  have hcosle : Real.cos y ≤ 1 := Real.cos_le_one y
  by_cases hy0 : y = 0
  · subst y
    norm_num
  · by_cases hyp : 0 < y
    · have hsin : 0 < Real.sin y :=
        Real.sin_pos_of_pos_of_lt_pi hyp (by nlinarith [Real.pi_gt_three])
      have hg : 0 < Real.sin y * Real.cos y := mul_pos hsin hcos
      have hgsin : Real.sin y * Real.cos y ≤ Real.sin y := by
        have hm := mul_nonneg (le_of_lt hsin) (sub_nonneg.mpr hcosle)
        nlinarith
      have hgy : Real.sin y * Real.cos y ≤ y :=
        hgsin.trans (Real.sin_le (le_of_lt hyp))
      have hsq : (Real.sin y * Real.cos y) ^ 2 ≤
          y * (Real.sin y * Real.cos y) := by
        have hm := mul_nonneg (le_of_lt hg) (sub_nonneg.mpr hgy)
        nlinarith
      have hp : 0 < y * (Real.sin y * Real.cos y) := mul_pos hyp hg
      refine ⟨le_of_lt hp, hsq, ?_⟩
      intro hz
      exact False.elim ((ne_of_gt hp) hz)
    · have hyn : y < 0 := by
        by_contra h
        push_neg at h
        exact hy0 (le_antisymm (le_of_not_gt hyp) h)
      have hnyp : 0 < -y := by linarith
      have hsinn : 0 < Real.sin (-y) :=
        Real.sin_pos_of_pos_of_lt_pi hnyp (by nlinarith [Real.pi_gt_three])
      have hsin : Real.sin y < 0 := by
        rw [Real.sin_neg] at hsinn
        linarith
      have hg : Real.sin y * Real.cos y < 0 :=
        mul_neg_of_neg_of_pos hsin hcos
      have hysin : y ≤ Real.sin y := by
        have hs := Real.sin_le (le_of_lt hnyp)
        rw [Real.sin_neg] at hs
        linarith
      have hsing : Real.sin y ≤ Real.sin y * Real.cos y := by
        have hm := mul_nonneg (by linarith : 0 ≤ -Real.sin y)
          (sub_nonneg.mpr hcosle)
        nlinarith
      have hyg : y ≤ Real.sin y * Real.cos y := hysin.trans hsing
      have hsq : (Real.sin y * Real.cos y) ^ 2 ≤
          y * (Real.sin y * Real.cos y) := by
        have hm := mul_nonpos_of_nonpos_of_nonneg (le_of_lt hg)
          (sub_nonneg.mpr hyg)
        nlinarith
      have hp : 0 < y * (Real.sin y * Real.cos y) :=
        mul_pos_of_neg_of_neg hyn hg
      refine ⟨le_of_lt hp, hsq, ?_⟩
      intro hz
      exact False.elim ((ne_of_gt hp) hz)

#print axioms trig_box_df2e6f5a7edf

end LeanBarrier.Generated
