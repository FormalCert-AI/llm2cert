import LeanBarrier.GeneratedCache.Helper_3f6c413ce6f7751a247a05687d9e4d8aaa5f06612ca24fc7b7cb4f2a189aa5e7

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_decay_estimate_df2e6f5a7edf (x : LeanBarrier.State 9)
    (hx : x ∈ violationSet_lie_negative_df2e6f5a7edf) :
    ((17 : ℝ) / 20) * (x 0) ^ 2 +
    ((339 : ℝ) / 400) * (x 1) ^ 2 +
    (x 2) ^ 2 + (x 3) ^ 2 +
    ((17 : ℝ) / 20) * (x 4) ^ 2 +
    (x 5) ^ 2 +
    ((3 : ℝ) / 4) * (x 7) ^ 2 +
    ((1 : ℝ) / 16) * (Real.sin (x 6) * Real.cos (x 6)) ^ 2 +
    ((7 : ℝ) / 8) * (x 8 * (Real.sin (x 8) * Real.cos (x 8))) ≤ 0 := by
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hx2l, hx2u, hx3l, hx3u,
    hx4l, hx4u, hx5l, hx5u, hx6l, hx6u, hx7l, hx7u, hx8l, hx8u,
    hne, hD⟩
  have ht8 := trig_box_df2e6f5a7edf (x 8) hx8l hx8u
  have hc6sq : Real.cos (x 6) ^ 2 ≤ 1 := by
    nlinarith [Real.sin_sq_add_cos_sq (x 6)]
  have hcosfac : 0 ≤ (1 - Real.cos (x 6) ^ 2) * (x 7) ^ 2 :=
    mul_nonneg (sub_nonneg.mpr hc6sq) (sq_nonneg (x 7))
  have hsinfac : 0 ≤ Real.sin (x 6) ^ 2 * (x 7) ^ 2 :=
    mul_nonneg (sq_nonneg (Real.sin (x 6))) (sq_nonneg (x 7))
  have hcub4 :
      -((1 : ℝ) / 10) * x 0 * (x 4) ^ 2 ≤ ((3 : ℝ) / 20) * (x 4) ^ 2 := by
    have hm := mul_nonneg
      (show (0 : ℝ) ≤ x 0 + 3 / 2 by linarith)
      (sq_nonneg (x 4))
    nlinarith
  have hcub0 :
      -((1 : ℝ) / 10) * x 2 * (x 0) ^ 2 ≤ ((3 : ℝ) / 20) * (x 0) ^ 2 := by
    have hm := mul_nonneg
      (show (0 : ℝ) ≤ x 2 + 3 / 2 by linarith)
      (sq_nonneg (x 0))
    nlinarith
  have hcub1 :
      ((1 : ℝ) / 10) * x 5 * (x 1) ^ 2 ≤ ((3 : ℝ) / 20) * (x 1) ^ 2 := by
    have hm := mul_nonneg
      (show (0 : ℝ) ≤ 3 / 2 - x 5 by linarith)
      (sq_nonneg (x 1))
    nlinarith
  have hcross :
      -((1 : ℝ) / 4) * (Real.sin (x 6) * Real.cos (x 6)) *
          (Real.sin (x 8) * Real.cos (x 8)) ≤
        ((1 : ℝ) / 8) * (Real.sin (x 6) * Real.cos (x 6)) ^ 2 +
        ((1 : ℝ) / 8) * (Real.sin (x 8) * Real.cos (x 8)) ^ 2 := by
    nlinarith [sq_nonneg
      (Real.sin (x 6) * Real.cos (x 6) +
       Real.sin (x 8) * Real.cos (x 8))]
  have hlin :
      -((1 : ℝ) / 40) * (Real.sin (x 6) * Real.cos (x 6)) * x 1 ≤
        ((1 : ℝ) / 16) * (Real.sin (x 6) * Real.cos (x 6)) ^ 2 +
        ((1 : ℝ) / 400) * (x 1) ^ 2 := by
    nlinarith [sq_nonneg
      (5 * (Real.sin (x 6) * Real.cos (x 6)) + x 1)]
  ring_nf at hD
  nlinarith [hD, hcub4, hcub0, hcub1, hcosfac, hsinfac,
    hcross, hlin, ht8.2.1]

#print axioms lie_decay_estimate_df2e6f5a7edf

end LeanBarrier.Generated
