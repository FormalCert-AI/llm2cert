import LeanBarrier.GeneratedCache.Context_f72baf7af2663c33fc66ef607446053418f121b37395c8bb05e3b6ee9af4f5c9

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_53521fe36d27 (hV : ContDiff ℝ 1 barrier_53521fe36d27) : ¬ ∃ x : LeanBarrier.State 9, x ∈ violationSet_v_at_equilibrium_53521fe36d27 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, h6, h7, h8, hbad⟩
  norm_num [h0, h1, h2, h3, h4, h5, h6, h7, h8] at hbad

#print axioms verify_v_at_equilibrium_53521fe36d27

end LeanBarrier.Generated
