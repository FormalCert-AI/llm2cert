import LeanBarrier.GeneratedCache.Helper_5275ddec79ca3ff70cdcb3b8e2245a296810ddad88d3904199e336f4f2facc63

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_decay_contradiction_df2e6f5a7edf (x : LeanBarrier.State 9)
    (hx : x ∈ violationSet_lie_negative_df2e6f5a7edf)
    (hsum :
      ((17 : ℝ) / 20) * (x 0) ^ 2 +
      ((339 : ℝ) / 400) * (x 1) ^ 2 +
      (x 2) ^ 2 + (x 3) ^ 2 +
      ((17 : ℝ) / 20) * (x 4) ^ 2 +
      (x 5) ^ 2 +
      ((3 : ℝ) / 4) * (x 7) ^ 2 +
      ((1 : ℝ) / 16) * (Real.sin (x 6) * Real.cos (x 6)) ^ 2 +
      ((7 : ℝ) / 8) * (x 8 * (Real.sin (x 8) * Real.cos (x 8))) ≤ 0) : False := by
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hx2l, hx2u, hx3l, hx3u,
    hx4l, hx4u, hx5l, hx5u, hx6l, hx6u, hx7l, hx7u, hx8l, hx8u,
    hne, hD⟩
  have ht6 := trig_box_df2e6f5a7edf (x 6) hx6l hx6u
  have ht8 := trig_box_df2e6f5a7edf (x 8) hx8l hx8u
  have hg6sq0 : (Real.sin (x 6) * Real.cos (x 6)) ^ 2 = 0 := by
    nlinarith [hsum, ht8.1,
      sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4), sq_nonneg (x 5),
      sq_nonneg (x 7),
      sq_nonneg (Real.sin (x 6) * Real.cos (x 6))]
  have hg6zero : Real.sin (x 6) * Real.cos (x 6) = 0 := by
    have hm :
        (Real.sin (x 6) * Real.cos (x 6)) *
          (Real.sin (x 6) * Real.cos (x 6)) = 0 := by
      simpa [pow_two] using hg6sq0
    rcases mul_eq_zero.mp hm with hm | hm
    · exact hm
    · exact hm
  have hx6zero : x 6 = 0 := by
    apply ht6.2.2
    rw [hg6zero]
    simp
  have hp8zero : x 8 * (Real.sin (x 8) * Real.cos (x 8)) = 0 := by
    nlinarith [hsum, ht8.1,
      sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
      sq_nonneg (x 3), sq_nonneg (x 4), sq_nonneg (x 5),
      sq_nonneg (x 7),
      sq_nonneg (Real.sin (x 6) * Real.cos (x 6))]
  have hx8zero : x 8 = 0 := ht8.2.2 hp8zero
  simp [hx6zero, hx8zero] at hsum hne
  nlinarith [hsum,
    sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
    sq_nonneg (x 3), sq_nonneg (x 4), sq_nonneg (x 5),
    sq_nonneg (x 7)]

#print axioms lie_decay_contradiction_df2e6f5a7edf

end LeanBarrier.Generated
