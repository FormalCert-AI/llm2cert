import LeanBarrier.GeneratedCache.Helper_11542e78b35076a40706881ca68a95ab28aca35a2b2b7ff0b30b166515fd0b78

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_53521fe36d27 (hV : ContDiff ℝ 1 barrier_53521fe36d27) : ¬ ∃ x : LeanBarrier.State 9, x ∈ violationSet_lie_negative_53521fe36d27 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨haL, haU, hbL, hbU, hcL, hcU, hdL, hdU,
    heL, heU, hfL, hfU, htL, htU, hyL, hyU, hpL, hpU, hnorm, hD⟩
  set a : ℝ := x 0 with ha
  set b : ℝ := x 1 with hb
  set c : ℝ := x 2 with hc
  set d : ℝ := x 3 with hd
  set e : ℝ := x 4 with he
  set f : ℝ := x 5 with hf
  set t : ℝ := x 6 with ht
  set y : ℝ := x 7 with hy
  set p : ℝ := x 8 with hp
  set s : ℝ := Real.sin t with hs
  set k : ℝ := Real.cos t with hk
  set u : ℝ := Real.sin p * Real.cos p with hu
  have htrig : s ^ 2 + k ^ 2 = 1 := by
    simpa only [hs, hk] using Real.sin_sq_add_cos_sq t
  rcases trig_box_facts_53521fe36d27 t htL htU with
    ⟨htnonneg, htsq, htzero, htprodzero⟩
  rcases trig_box_facts_53521fe36d27 p hpL hpU with
    ⟨hpnonneg', hpsq', hpzero, hpprodzero'⟩
  have hpnonneg : 0 ≤ p * u := by
    simpa only [hu] using hpnonneg'
  have hpsq : u ^ 2 ≤ p * u := by
    simpa only [hu] using hpsq'
  have htgzero : s * k = 0 ↔ t = 0 := by
    simpa only [hs, hk] using htzero
  have hpprodzero : p * u = 0 ↔ p = 0 := by
    simpa only [hu] using hpprodzero'
  have hbase :
      0 ≤
        -a ^ 2 - b ^ 2 - c ^ 2 - d ^ 2 - e ^ 2 - f ^ 2
        - (1 - (1 / 2 : ℝ) * (k ^ 2 - s ^ 2)) * y ^ 2 - p * u
        - (1 / 10 : ℝ) * a * e ^ 2 - (1 / 10 : ℝ) * c * a ^ 2
        + (1 / 10 : ℝ) * f * b ^ 2
        - (1 / 2 : ℝ) * (s * k) ^ 2
        - (1 / 2 : ℝ) * (s * k) * u
        - (1 / 20 : ℝ) * (s * k) * b := by
    nlinarith [hD]
  have hcubA :
      -(1 / 10 : ℝ) * a * e ^ 2 ≤ (3 / 20 : ℝ) * e ^ 2 := by
    have hm : 0 ≤ (a + 3 / 2) * e ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg e)
    nlinarith
  have hcubC :
      -(1 / 10 : ℝ) * c * a ^ 2 ≤ (3 / 20 : ℝ) * a ^ 2 := by
    have hm : 0 ≤ (c + 3 / 2) * a ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg a)
    nlinarith
  have hcubF :
      (1 / 10 : ℝ) * f * b ^ 2 ≤ (3 / 20 : ℝ) * b ^ 2 := by
    have hm : 0 ≤ (3 / 2 - f) * b ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg b)
    nlinarith
  have hcoef :
      (1 / 2 : ℝ) ≤ 1 - (1 / 2 : ℝ) * (k ^ 2 - s ^ 2) := by
    nlinarith [htrig, sq_nonneg s]
  have hybound :
      -(1 - (1 / 2 : ℝ) * (k ^ 2 - s ^ 2)) * y ^ 2
        ≤ -(1 / 2 : ℝ) * y ^ 2 := by
    have hm :
        0 ≤ ((1 - (1 / 2 : ℝ) * (k ^ 2 - s ^ 2)) - 1 / 2) * y ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg y)
    nlinarith
  have hmixedU :
      -(1 / 2 : ℝ) * (s * k) * u
        ≤ (1 / 4 : ℝ) * (s * k) ^ 2 + (1 / 4 : ℝ) * u ^ 2 := by
    nlinarith [sq_nonneg ((s * k) + u)]
  have hmixedB :
      -(1 / 20 : ℝ) * (s * k) * b
        ≤ (1 / 8 : ℝ) * (s * k) ^ 2 + (1 / 200 : ℝ) * b ^ 2 := by
    nlinarith [sq_nonneg (5 * (s * k) + b)]
  have hfinal :
      (17 / 20 : ℝ) * a ^ 2 + (169 / 200 : ℝ) * b ^ 2
        + c ^ 2 + d ^ 2 + (17 / 20 : ℝ) * e ^ 2 + f ^ 2
        + (1 / 2 : ℝ) * y ^ 2 + (1 / 8 : ℝ) * (s * k) ^ 2
        + (3 / 4 : ℝ) * (p * u) ≤ 0 := by
    nlinarith [hbase, hcubA, hcubC, hcubF, hybound, hmixedU,
      hmixedB, hpsq]
  have hgzero : s * k = 0 := by
    nlinarith [hfinal, sq_nonneg a, sq_nonneg b, sq_nonneg c,
      sq_nonneg d, sq_nonneg e, sq_nonneg f, sq_nonneg y,
      sq_nonneg (s * k), hpnonneg]
  have hpuzero : p * u = 0 := by
    nlinarith [hfinal, sq_nonneg a, sq_nonneg b, sq_nonneg c,
      sq_nonneg d, sq_nonneg e, sq_nonneg f, sq_nonneg y,
      sq_nonneg (s * k), hpnonneg]
  have ht0 : t = 0 := htgzero.mp hgzero
  have hp0 : p = 0 := hpprodzero.mp hpuzero
  rw [ht0, hp0] at hnorm
  norm_num at hnorm
  nlinarith [hfinal, sq_nonneg a, sq_nonneg b, sq_nonneg c,
    sq_nonneg d, sq_nonneg e, sq_nonneg f, sq_nonneg y,
    sq_nonneg (s * k), hpnonneg]

#print axioms verify_lie_negative_53521fe36d27

end LeanBarrier.Generated
