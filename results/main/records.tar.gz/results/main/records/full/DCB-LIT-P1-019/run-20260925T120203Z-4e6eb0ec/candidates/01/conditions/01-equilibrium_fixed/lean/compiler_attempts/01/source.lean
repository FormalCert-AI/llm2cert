import LeanBarrier.GeneratedCache.Context_f81ba01bc542bc06b08b80743aa86b238384411e04428c443c2c451656f74a50

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_df2e6f5a7edf (hV : ContDiff ℝ 1 barrier_df2e6f5a7edf) : ¬ ∃ x : LeanBarrier.State 9, x ∈ violationSet_equilibrium_fixed_df2e6f5a7edf := by
  rintro ⟨x, hx⟩
  simp only [violationSet_equilibrium_fixed_df2e6f5a7edf] at hx
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, h6, h7, h8, hbad⟩
  norm_num [h0, h1, h2, h3, h4, h5, h6, h7, h8] at hbad

#print axioms verify_equilibrium_fixed_df2e6f5a7edf

end LeanBarrier.Generated
