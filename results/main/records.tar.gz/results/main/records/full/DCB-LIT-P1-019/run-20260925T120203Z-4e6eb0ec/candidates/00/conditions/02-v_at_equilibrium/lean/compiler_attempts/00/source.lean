import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 53521fe36d2761dcf66bf7b6e61c11804525d683706051d958578f89fb179379
noncomputable def barrier_53521fe36d27 (x : LeanBarrier.State 9) : ℝ := ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((3 : ℝ) / (4 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7))
@[simp] theorem barrier_unfold_53521fe36d27 (x : LeanBarrier.State 9) : barrier_53521fe36d27 x = ((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((3 : ℝ) / (4 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) := by
  rfl
def violationSet_v_at_equilibrium_53521fe36d27 : Set (LeanBarrier.State 9) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (x 3 = (0 : ℝ)) ∧ (x 4 = (0 : ℝ)) ∧ (x 5 = (0 : ℝ)) ∧ (x 6 = (0 : ℝ)) ∧ (x 7 = (0 : ℝ)) ∧ (x 8 = (0 : ℝ)) ∧ (((((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((3 : ℝ) / (4 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) > (0 : ℝ))) ∨ ((((((1 : ℝ) / (2 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 7 ^ 2) + (Real.sin (x 8) ^ 2))) + (((3 : ℝ) / (4 : ℝ)) * (Real.sin (x 6) ^ 2)) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 6) * Real.cos (x 6) * x 7)) < (0 : ℝ)))))}

#print axioms barrier_unfold_53521fe36d27

end LeanBarrier.Generated
