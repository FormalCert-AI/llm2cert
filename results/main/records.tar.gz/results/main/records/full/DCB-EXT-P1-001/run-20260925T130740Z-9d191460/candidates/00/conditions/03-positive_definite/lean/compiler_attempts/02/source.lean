import LeanBarrier.GeneratedCache.Context_0216f26cf345c6ba28652a49feb1e8501f518ce29935038acec3a419ca4ffb28

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_96dae1d24041 := by
  rintro ⟨x, hx⟩
  change
    (x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ)) ∧
      (x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) + x 1 ^ 2 ≤ (0 : ℝ)) at hx
  rcases hx with ⟨hpos, hnonpos⟩
  have he : 0 < Real.exp ((2 : ℝ) * x 1) := Real.exp_pos _
  have ha : 0 ≤ x 0 ^ 2 := sq_nonneg (x 0)
  have hb : 0 ≤ x 1 ^ 2 := sq_nonneg (x 1)
  have hprod : 0 ≤ x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) :=
    mul_nonneg ha (le_of_lt he)
  have hbzero : x 1 ^ 2 = 0 := by
    linarith
  have hprodzero : x 0 ^ 2 * Real.exp ((2 : ℝ) * x 1) = 0 := by
    linarith
  have hazero : x 0 ^ 2 = 0 :=
    (mul_eq_zero.mp hprodzero).resolve_right (ne_of_gt he)
  linarith

#print axioms verify_positive_definite_96dae1d24041

end LeanBarrier.Generated
