import LeanBarrier

#check Real.exp
#check Real.exp_pos
