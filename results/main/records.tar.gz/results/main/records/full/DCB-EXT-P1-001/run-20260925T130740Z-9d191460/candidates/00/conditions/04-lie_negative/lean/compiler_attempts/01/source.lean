import LeanBarrier.GeneratedCache.Context_d682e180433c33612352f0e0d2e0403a59efdd81fc6f2a56b96b4dabd767d66b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_96dae1d24041 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hpos, hder⟩
  have hexp : 0 < Real.exp ((2 : ℝ) * x 1) := Real.exp_pos _
  have hsq0 : 0 ≤ x 0 ^ 2 := sq_nonneg _
  have hsq1 : 0 ≤ x 1 ^ 2 := sq_nonneg _
  have hweighted :
      0 ≤ (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) :=
    mul_nonneg hsq0 (le_of_lt hexp)
  have hformula :
      ((2 : ℝ) * x 0 * Real.exp ((2 : ℝ) * x 1) *
          ((-x 0) + (x 0 * x 1)) +
        (((2 : ℝ) * (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) +
            (2 : ℝ) * x 1) * (-x 1))) =
        -((2 : ℝ) * ((x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1))) -
          ((2 : ℝ) * (x 1 ^ 2)) := by
    ring
  rw [hformula] at hder
  have hweighted_zero :
      (x 0 ^ 2) * Real.exp ((2 : ℝ) * x 1) = 0 := by
    linarith
  have hsq1_zero : x 1 ^ 2 = 0 := by
    linarith
  have hsq0_zero : x 0 ^ 2 = 0 := by
    rcases mul_eq_zero.mp hweighted_zero with h | h
    · exact h
    · exact False.elim ((ne_of_gt hexp) h)
  nlinarith

#print axioms verify_lie_negative_96dae1d24041

end LeanBarrier.Generated
