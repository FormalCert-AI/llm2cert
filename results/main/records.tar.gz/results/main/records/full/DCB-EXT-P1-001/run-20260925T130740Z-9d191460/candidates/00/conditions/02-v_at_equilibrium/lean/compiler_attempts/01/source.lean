import LeanBarrier.GeneratedCache.Context_eb76737d180f6cb87e06e4a07d3660c3b696b4fa1589c8254e689041a384d27c

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_96dae1d24041 (hV : ContDiff ℝ 1 barrier_96dae1d24041) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_96dae1d24041 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  rw [hx0, hx1] at hbad
  norm_num at hbad

#print axioms verify_v_at_equilibrium_96dae1d24041

end LeanBarrier.Generated
