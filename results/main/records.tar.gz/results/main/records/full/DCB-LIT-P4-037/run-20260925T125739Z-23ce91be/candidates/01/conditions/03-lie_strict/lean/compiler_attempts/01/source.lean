import LeanBarrier

#check Real.abs_sin_sub_le
