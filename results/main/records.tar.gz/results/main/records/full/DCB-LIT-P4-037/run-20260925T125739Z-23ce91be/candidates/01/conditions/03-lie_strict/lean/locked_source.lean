-- candidate-sha256: 9f5f6d6b70c0c788bb94d308ac008fe86b467652e6c64a4db7b2c146a6f48ab3
noncomputable def barrier_9f5f6d6b70c0 (x : LeanBarrier.State 3) : ℝ := (((4 : ℝ) / (25 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)))
@[simp] theorem barrier_unfold_9f5f6d6b70c0 (x : LeanBarrier.State 3) : barrier_9f5f6d6b70c0 x = (((4 : ℝ) / (25 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))) := by
  rfl
def violationSet_lie_strict_9f5f6d6b70c0 : Set (LeanBarrier.State 3) := {x | (((((4 : ℝ) / (25 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-3 : ℝ) / (10 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 1)))) + ((-((2 : ℝ) * x 1)) * (((((-2 : ℝ) / (5 : ℝ)) * x 1) - (((3 : ℝ) / (5 : ℝ)) * Real.sin (x 0))) + (((1 : ℝ) / (10 : ℝ)) * Real.sin (x 2)))) + ((-((2 : ℝ) * x 2)) * ((((-1 : ℝ) / (2 : ℝ)) * x 2) + (((1 : ℝ) / (5 : ℝ)) * Real.sin (x 0) * Real.sin (x 1))))) ≤ (0 : ℝ)))}
def unsafeSet_9f5f6d6b70c0 : Set (LeanBarrier.State 3) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≥ (9 : ℝ)))}
def initialSet_9f5f6d6b70c0 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ ((4 : ℝ) / (25 : ℝ))))}

theorem verify_lie_strict_9f5f6d6b70c0 (hV : ContDiff ℝ 1 barrier_9f5f6d6b70c0) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_9f5f6d6b70c0
