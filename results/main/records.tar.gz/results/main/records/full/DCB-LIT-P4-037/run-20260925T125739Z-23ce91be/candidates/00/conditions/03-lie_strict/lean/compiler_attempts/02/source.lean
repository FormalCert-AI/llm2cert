import LeanBarrier

#check Real.pi
#check Real.pi_gt_three
#check Real.sin_nonneg_of_nonneg_of_le_pi
#check Real.sin_neg
