import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 05b43e67ecaaf57f18bbfa173302400fb25a2b5b6bf8f3335f483ce453a409cb
noncomputable def barrier_05b43e67ecaa (x : LeanBarrier.State 3) : ℝ := (((1 : ℝ) / (4 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)))
@[simp] theorem barrier_unfold_05b43e67ecaa (x : LeanBarrier.State 3) : barrier_05b43e67ecaa x = (((1 : ℝ) / (4 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))) := by
  rfl
def violationSet_lie_strict_05b43e67ecaa : Set (LeanBarrier.State 3) := {x | (((((1 : ℝ) / (4 : ℝ)) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2))) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-3 : ℝ) / (10 : ℝ)) * x 0) + (((1 : ℝ) / (2 : ℝ)) * Real.sin (x 1)))) + ((-((2 : ℝ) * x 1)) * (((((-2 : ℝ) / (5 : ℝ)) * x 1) - (((3 : ℝ) / (5 : ℝ)) * Real.sin (x 0))) + (((1 : ℝ) / (10 : ℝ)) * Real.sin (x 2)))) + ((-((2 : ℝ) * x 2)) * ((((-1 : ℝ) / (2 : ℝ)) * x 2) + (((1 : ℝ) / (5 : ℝ)) * Real.sin (x 0) * Real.sin (x 1))))) ≤ (0 : ℝ)))}
def unsafeSet_05b43e67ecaa : Set (LeanBarrier.State 3) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≥ (9 : ℝ)))}
def initialSet_05b43e67ecaa : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-2 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ ((4 : ℝ) / (25 : ℝ))))}

#print axioms barrier_unfold_05b43e67ecaa

end LeanBarrier.Generated
