import LeanBarrier

#check Real.sqrt
#check Real.sqrt_pos
#check Real.sq_sqrt
#check Real.sqrt_nonneg
#check Real.sin
#check Real.abs_sin_le_abs
