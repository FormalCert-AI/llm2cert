import LeanBarrier.GeneratedCache.Context_d6c6f01d3132e6a8d67d95fba26fa54c6bde1c486f71bd9c882f3165ac90d70a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
lemma sq_div_sqrt_lower_a7ad635fb238 (t : ℝ) (h : t ^ 2 ≤ (5 : ℝ) / 4) :
    (2 : ℝ) / 3 * t ^ 2 ≤ t ^ 2 / Real.sqrt (t ^ 2 + 1) := by
  have harg : 0 < t ^ 2 + 1 := by
    nlinarith [sq_nonneg t]
  have hspos : 0 < Real.sqrt (t ^ 2 + 1) := Real.sqrt_pos.2 harg
  have hs_sq : (Real.sqrt (t ^ 2 + 1)) ^ 2 = t ^ 2 + 1 :=
    Real.sq_sqrt (le_of_lt harg)
  have hs_le : Real.sqrt (t ^ 2 + 1) ≤ (3 : ℝ) / 2 := by
    nlinarith [Real.sqrt_nonneg (t ^ 2 + 1), hs_sq]
  apply (le_div_iff₀ hspos).2
  have hm : 0 ≤ t ^ 2 * ((3 : ℝ) / 2 - Real.sqrt (t ^ 2 + 1)) :=
    mul_nonneg (sq_nonneg t) (sub_nonneg.mpr hs_le)
  nlinarith

#print axioms sq_div_sqrt_lower_a7ad635fb238

end LeanBarrier.Generated
