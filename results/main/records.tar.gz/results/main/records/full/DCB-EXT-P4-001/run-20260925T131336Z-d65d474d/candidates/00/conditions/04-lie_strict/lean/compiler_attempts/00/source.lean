import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: a7ad635fb2383c3d1c93d38488a758eeaa0a2966dc98154eb49136d3d266af7f
noncomputable def barrier_a7ad635fb238 (x : LeanBarrier.State 4) : ℝ := ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2))
@[simp] theorem barrier_unfold_a7ad635fb238 (x : LeanBarrier.State 4) : barrier_a7ad635fb238 x = ((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) := by
  rfl
def violationSet_lie_strict_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((((((((5 : ℝ) / (4 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * (x 1 + (((-3 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 1)) * (((((-19 : ℝ) / (20 : ℝ)) * Real.sin (x 0)) - (((1 : ℝ) / (50 : ℝ)) * x 1)) + (((1 : ℝ) / (100 : ℝ)) * x 2) + (((-3 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 1 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 2)) * ((((-1 : ℝ) / (10 : ℝ)) * x 2) + (((1 : ℝ) / (50 : ℝ)) * x 0) + (((-3 : ℝ) * x 2) / ((2 : ℝ) * Real.sqrt (((x 2 ^ 2) + (1 : ℝ))))))) + ((-((2 : ℝ) * x 3)) * ((((-3 : ℝ) / (100 : ℝ)) * x 3) + (((1 : ℝ) / (100 : ℝ)) * x 1) + (((-3 : ℝ) * x 3) / ((2 : ℝ) * Real.sqrt (((x 3 ^ 2) + (1 : ℝ)))))))) ≤ (0 : ℝ)))}
def unsafeSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≥ ((25 : ℝ) / (4 : ℝ))))}
def initialSet_a7ad635fb238 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≤ ((9 : ℝ) / (100 : ℝ))))}

#print axioms barrier_unfold_a7ad635fb238

end LeanBarrier.Generated
