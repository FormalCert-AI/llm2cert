import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: f0aec9d9ce56a68bf49891a9ec9f6f785872209ef69eb50ee9ec182fe16d02bd
noncomputable def barrier_f0aec9d9ce56 (x : LeanBarrier.State 6) : ℝ := (((1 : ℝ) / (50 : ℝ)) - ((x 1 ^ 2) + (x 1 * x 4) + (x 4 ^ 2) + (x 0 ^ 2) + ((x 0 + x 3) ^ 2) + ((x 0 + ((2 : ℝ) * x 3) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2)))) ^ 2) + ((x 0 + ((3 : ℝ) * x 3) + ((3 : ℝ) * ((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2))) + (x 1 * (Real.sin (x 2) / Real.cos (x 2))) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (((Real.sin (x 2) / Real.cos (x 2)) ^ 2) + (1 : ℝ)) * x 5)) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * ((((5 : ℝ) * x 2) ^ 20) + (((5 : ℝ) * x 5) ^ 20)))))
@[simp] theorem barrier_unfold_f0aec9d9ce56 (x : LeanBarrier.State 6) : barrier_f0aec9d9ce56 x = (((1 : ℝ) / (50 : ℝ)) - ((x 1 ^ 2) + (x 1 * x 4) + (x 4 ^ 2) + (x 0 ^ 2) + ((x 0 + x 3) ^ 2) + ((x 0 + ((2 : ℝ) * x 3) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2)))) ^ 2) + ((x 0 + ((3 : ℝ) * x 3) + ((3 : ℝ) * ((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2))) + (x 1 * (Real.sin (x 2) / Real.cos (x 2))) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (((Real.sin (x 2) / Real.cos (x 2)) ^ 2) + (1 : ℝ)) * x 5)) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * ((((5 : ℝ) * x 2) ^ 20) + (((5 : ℝ) * x 5) ^ 20))))) := by
  rfl
def violationSet_certified_set_in_X_f0aec9d9ce56 : Set (LeanBarrier.State 6) := {x | (((((1 : ℝ) / (50 : ℝ)) - ((x 1 ^ 2) + (x 1 * x 4) + (x 4 ^ 2) + (x 0 ^ 2) + ((x 0 + x 3) ^ 2) + ((x 0 + ((2 : ℝ) * x 3) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2)))) ^ 2) + ((x 0 + ((3 : ℝ) * x 3) + ((3 : ℝ) * ((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (Real.sin (x 2) / Real.cos (x 2))) + (x 1 * (Real.sin (x 2) / Real.cos (x 2))) + (((((981 : ℝ) / (100 : ℝ)) - x 1) - x 4) * (((Real.sin (x 2) / Real.cos (x 2)) ^ 2) + (1 : ℝ)) * x 5)) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * ((((5 : ℝ) * x 2) ^ 20) + (((5 : ℝ) * x 5) ^ 20))))) ≥ (0 : ℝ)) ∧ (((x 0 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 0 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 1 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 1 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 2 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 2 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 3 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 3 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 4 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 4 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 5 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 5 > ((1 : ℝ) / (5 : ℝ))))))}
def unsafeSet_f0aec9d9ce56 : Set (LeanBarrier.State 6) := {x | ((((x 0 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 0 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 1 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 1 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 2 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 2 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 3 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 3 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 4 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 4 > ((1 : ℝ) / (5 : ℝ)))) ∨ ((x 5 < ((-1 : ℝ) / (5 : ℝ)))) ∨ ((x 5 > ((1 : ℝ) / (5 : ℝ))))))}

#print axioms barrier_unfold_f0aec9d9ce56

end LeanBarrier.Generated
