import LeanBarrier.GeneratedCache.Context_069d6aab5b11f2efa65394fc7cf5b2706dcb1fef79b3104e7f945724e162bca4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_certified_set_in_X_f0aec9d9ce56 (hV : ContDiff ℝ 1 barrier_f0aec9d9ce56) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_certified_set_in_X_f0aec9d9ce56 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hout⟩
  have hq :
      0 ≤ x 1 ^ 2 + x 1 * x 4 + x 4 ^ 2 := by
    nlinarith [sq_nonneg (x 1 + x 4), sq_nonneg (x 1), sq_nonneg (x 4)]
  have hq1 :
      ((3 : ℝ) / 4) * x 1 ^ 2 ≤ x 1 ^ 2 + x 1 * x 4 + x 4 ^ 2 := by
    nlinarith [sq_nonneg (x 1 + 2 * x 4)]
  have hq4 :
      ((3 : ℝ) / 4) * x 4 ^ 2 ≤ x 1 ^ 2 + x 1 * x 4 + x 4 ^ 2 := by
    nlinarith [sq_nonneg (2 * x 1 + x 4)]
  have hs0 : 0 ≤ x 0 ^ 2 := sq_nonneg _
  have hs03 : 0 ≤ (x 0 + x 3) ^ 2 := sq_nonneg _
  have hs2 :
      0 ≤
        (x 0 + 2 * x 3 +
          (((((981 : ℝ) / 100) - x 1) - x 4) *
            (Real.sin (x 2) / Real.cos (x 2)))) ^ 2 :=
    sq_nonneg _
  have hs3 :
      0 ≤
        (x 0 + 3 * x 3 +
          3 * (((((981 : ℝ) / 100) - x 1) - x 4) *
            (Real.sin (x 2) / Real.cos (x 2))) +
          x 1 * (Real.sin (x 2) / Real.cos (x 2)) +
          (((((981 : ℝ) / 100) - x 1) - x 4) *
            ((Real.sin (x 2) / Real.cos (x 2)) ^ 2 + 1) * x 5)) ^ 2 :=
    sq_nonneg _
  have hp2n : 0 ≤ ((5 : ℝ) * x 2) ^ 20 := by positivity
  have hp5n : 0 ≤ ((5 : ℝ) * x 5) ^ 20 := by positivity
  have hqle :
      x 1 ^ 2 + x 1 * x 4 + x 4 ^ 2 ≤ (1 : ℝ) / 50 := by
    nlinarith [hs0, hs03, hs2, hs3, hp2n, hp5n]
  have hx0le : x 0 ^ 2 ≤ (1 : ℝ) / 50 := by
    nlinarith [hq, hs03, hs2, hs3, hp2n, hp5n]
  have hpair :
      x 3 ^ 2 / 2 ≤ x 0 ^ 2 + (x 0 + x 3) ^ 2 := by
    nlinarith [sq_nonneg (2 * x 0 + x 3)]
  have hpairle :
      x 0 ^ 2 + (x 0 + x 3) ^ 2 ≤ (1 : ℝ) / 50 := by
    nlinarith [hq, hs2, hs3, hp2n, hp5n]
  have hp2le : ((5 : ℝ) * x 2) ^ 20 ≤ 1 := by
    nlinarith [hq, hs0, hs03, hs2, hs3, hp5n]
  have hp5le : ((5 : ℝ) * x 5) ^ 20 ≤ 1 := by
    nlinarith [hq, hs0, hs03, hs2, hs3, hp2n]
  have pow20_gt_one (y : ℝ) (hy : 1 < y) : 1 < y ^ 20 := by
    have hy2 : 1 < y ^ 2 := by
      nlinarith [sq_nonneg (y - 1)]
    have hy4 : 1 < y ^ 4 := by
      nlinarith [sq_nonneg (y ^ 2 - 1)]
    have hy8 : 1 < y ^ 8 := by
      nlinarith [sq_nonneg (y ^ 4 - 1)]
    have hy16 : 1 < y ^ 16 := by
      nlinarith [sq_nonneg (y ^ 8 - 1)]
    have hm : 0 < (y ^ 16 - 1) * (y ^ 4 - 1) :=
      mul_pos (sub_pos.mpr hy16) (sub_pos.mpr hy4)
    nlinarith
  have hn0l : ¬ x 0 < (-1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 0 + (1 : ℝ) / 5)]
  have hn0u : ¬ x 0 > (1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 0 - (1 : ℝ) / 5)]
  have hn1l : ¬ x 1 < (-1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 1 + (1 : ℝ) / 5)]
  have hn1u : ¬ x 1 > (1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 1 - (1 : ℝ) / 5)]
  have hn2l : ¬ x 2 < (-1 : ℝ) / 5 := by
    intro h
    have hy : 1 < -((5 : ℝ) * x 2) := by linarith
    have hpraw : 1 < (-((5 : ℝ) * x 2)) ^ 20 := pow20_gt_one _ hy
    have heq : (-((5 : ℝ) * x 2)) ^ 20 = ((5 : ℝ) * x 2) ^ 20 := by ring
    linarith
  have hn2u : ¬ x 2 > (1 : ℝ) / 5 := by
    intro h
    have hy : 1 < (5 : ℝ) * x 2 := by linarith
    have hp : 1 < ((5 : ℝ) * x 2) ^ 20 := pow20_gt_one _ hy
    linarith
  have hn3l : ¬ x 3 < (-1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 3 + (1 : ℝ) / 5)]
  have hn3u : ¬ x 3 > (1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 3 - (1 : ℝ) / 5)]
  have hn4l : ¬ x 4 < (-1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 4 + (1 : ℝ) / 5)]
  have hn4u : ¬ x 4 > (1 : ℝ) / 5 := by
    intro h
    nlinarith [sq_nonneg (x 4 - (1 : ℝ) / 5)]
  have hn5l : ¬ x 5 < (-1 : ℝ) / 5 := by
    intro h
    have hy : 1 < -((5 : ℝ) * x 5) := by linarith
    have hpraw : 1 < (-((5 : ℝ) * x 5)) ^ 20 := pow20_gt_one _ hy
    have heq : (-((5 : ℝ) * x 5)) ^ 20 = ((5 : ℝ) * x 5) ^ 20 := by ring
    linarith
  have hn5u : ¬ x 5 > (1 : ℝ) / 5 := by
    intro h
    have hy : 1 < (5 : ℝ) * x 5 := by linarith
    have hp : 1 < ((5 : ℝ) * x 5) ^ 20 := pow20_gt_one _ hy
    linarith
  rcases hout with h | h | h | h | h | h | h | h | h | h | h | h
  · exact hn0l h
  · exact hn0u h
  · exact hn1l h
  · exact hn1u h
  · exact hn2l h
  · exact hn2u h
  · exact hn3l h
  · exact hn3u h
  · exact hn4l h
  · exact hn4u h
  · exact hn5l h
  · exact hn5u h

#print axioms verify_certified_set_in_X_f0aec9d9ce56

end LeanBarrier.Generated
