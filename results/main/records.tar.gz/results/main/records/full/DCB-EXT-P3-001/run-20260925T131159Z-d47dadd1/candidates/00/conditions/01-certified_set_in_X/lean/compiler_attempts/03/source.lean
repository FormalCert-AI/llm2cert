import LeanBarrier.GeneratedCache.Context_069d6aab5b11f2efa65394fc7cf5b2706dcb1fef79b3104e7f945724e162bca4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
lemma pow_twenty_gt_one_f0aec9d9ce56 (y : ℝ) (hy : 1 < y) : 1 < y ^ 20 := by
  have hy2 : 1 < y ^ 2 := by
    nlinarith only [hy, sq_nonneg (y - 1)]
  have hy4 : 1 < y ^ 4 := by
    nlinarith only [hy2, sq_nonneg (y ^ 2 - 1)]
  have hy8 : 1 < y ^ 8 := by
    nlinarith only [hy4, sq_nonneg (y ^ 4 - 1)]
  have hy16 : 1 < y ^ 16 := by
    nlinarith only [hy8, sq_nonneg (y ^ 8 - 1)]
  have hm : 0 < (y ^ 16 - 1) * (y ^ 4 - 1) :=
    mul_pos (sub_pos.mpr hy16) (sub_pos.mpr hy4)
  nlinarith only [hm, hy16, hy4]

#print axioms pow_twenty_gt_one_f0aec9d9ce56

end LeanBarrier.Generated
