import LeanBarrier.GeneratedCache.Context_ed566aaee9aee9d2cb4b1637c373771c9ae70f631673989d5cd0e85cc7cd608e

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_certified_set_in_X_db0a38e9ad57 (hV : ContDiff ℝ 1 barrier_db0a38e9ad57) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_certified_set_in_X_db0a38e9ad57 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_certified_set_in_X_db0a38e9ad57, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hB, hout⟩
  let q : ℝ := (x 1) ^ 2 + (x 1) * (x 4) + (x 4) ^ 2
  let z0 : ℝ := x 0
  let z1 : ℝ := x 0 + x 3
  let z2 : ℝ :=
    x 0 + (2 : ℝ) * x 3 +
      (((((981 : ℝ) / 100) - x 1) - x 4) *
        (Real.sin (x 2) / Real.cos (x 2)))
  let z3 : ℝ :=
    x 0 + (3 : ℝ) * x 3 +
      (3 : ℝ) *
        (((((981 : ℝ) / 100) - x 1) - x 4) *
          (Real.sin (x 2) / Real.cos (x 2))) +
      x 1 * (Real.sin (x 2) / Real.cos (x 2)) +
      (((((981 : ℝ) / 100) - x 1) - x 4) *
        ((Real.sin (x 2) / Real.cos (x 2)) ^ 2 + 1) * x 5)
  let p : ℝ := ((5 : ℝ) * x 2) ^ 10 + ((5 : ℝ) * x 5) ^ 10
  change
    0 ≤ (1 : ℝ) / 100 -
      (q + z0 ^ 2 + z1 ^ 2 + z2 ^ 2 + z3 ^ 2) -
      ((1 : ℝ) / 100) * p at hB
  have hq1 : (3 : ℝ) / 4 * (x 1) ^ 2 ≤ q := by
    dsimp [q]
    nlinarith [sq_nonneg (x 4 + x 1 / 2)]
  have hq4 : (3 : ℝ) / 4 * (x 4) ^ 2 ≤ q := by
    dsimp [q]
    nlinarith [sq_nonneg (x 1 + x 4 / 2)]
  have hq : 0 ≤ q := by
    nlinarith [hq1, sq_nonneg (x 1)]
  have hz0 : 0 ≤ z0 ^ 2 := sq_nonneg z0
  have hz1 : 0 ≤ z1 ^ 2 := sq_nonneg z1
  have hz2 : 0 ≤ z2 ^ 2 := sq_nonneg z2
  have hz3 : 0 ≤ z3 ^ 2 := sq_nonneg z3
  have hp : 0 ≤ p := by
    dsimp [p]
    positivity
  have hbudget :
      q + z0 ^ 2 + z1 ^ 2 + z2 ^ 2 + z3 ^ 2 +
        ((1 : ℝ) / 100) * p ≤ (1 : ℝ) / 100 := by
    linarith
  have hq_le : q ≤ (1 : ℝ) / 100 := by
    nlinarith [hbudget, hz0, hz1, hz2, hz3, hp]
  have hz0_le : z0 ^ 2 ≤ (1 : ℝ) / 100 := by
    nlinarith [hbudget, hq, hz1, hz2, hz3, hp]
  have hz01_le : z0 ^ 2 + z1 ^ 2 ≤ (1 : ℝ) / 100 := by
    nlinarith [hbudget, hq, hz2, hz3, hp]
  have hp_le : p ≤ 1 := by
    nlinarith [hbudget, hq, hz0, hz1, hz2, hz3]
  have hp2 : ((5 : ℝ) * x 2) ^ 10 ≤ p := by
    dsimp [p]
    positivity
  have hp5 : ((5 : ℝ) * x 5) ^ 10 ≤ p := by
    dsimp [p]
    positivity
  have hzpair : (x 3) ^ 2 / 2 ≤ z0 ^ 2 + z1 ^ 2 := by
    dsimp [z0, z1]
    nlinarith [sq_nonneg ((2 : ℝ) * x 0 + x 3)]
  have hpow : ∀ t : ℝ, 1 < t ^ 2 → 1 < t ^ 10 := by
    intro t ht2
    have ht4 : 1 < t ^ 4 := by
      nlinarith [sq_nonneg (t ^ 2 - 1)]
    have ht8 : 1 < t ^ 8 := by
      nlinarith [sq_nonneg (t ^ 4 - 1)]
    have hm : 0 < (t ^ 8 - 1) * (t ^ 2 - 1) :=
      mul_pos (sub_pos.mpr ht8) (sub_pos.mpr ht2)
    nlinarith [hm]
  rcases hout with h0l | h0u | h1l | h1u | h2l | h2u |
    h3l | h3u | h4l | h4u | h5l | h5u
  · have hs : (1 : ℝ) / 25 < (x 0) ^ 2 := by
      nlinarith [sq_nonneg (x 0 + (1 : ℝ) / 5)]
    dsimp [z0] at hz0_le
    nlinarith
  · have hs : (1 : ℝ) / 25 < (x 0) ^ 2 := by
      nlinarith [sq_nonneg (x 0 - (1 : ℝ) / 5)]
    dsimp [z0] at hz0_le
    nlinarith
  · have hs : (1 : ℝ) / 25 < (x 1) ^ 2 := by
      nlinarith [sq_nonneg (x 1 + (1 : ℝ) / 5)]
    nlinarith [hq1, hq_le]
  · have hs : (1 : ℝ) / 25 < (x 1) ^ 2 := by
      nlinarith [sq_nonneg (x 1 - (1 : ℝ) / 5)]
    nlinarith [hq1, hq_le]
  · have ht2 : 1 < ((5 : ℝ) * x 2) ^ 2 := by
      nlinarith [sq_nonneg ((5 : ℝ) * x 2 + 1)]
    have ht10 := hpow ((5 : ℝ) * x 2) ht2
    nlinarith [hp2, hp_le]
  · have ht2 : 1 < ((5 : ℝ) * x 2) ^ 2 := by
      nlinarith [sq_nonneg ((5 : ℝ) * x 2 - 1)]
    have ht10 := hpow ((5 : ℝ) * x 2) ht2
    nlinarith [hp2, hp_le]
  · have hs : (1 : ℝ) / 25 < (x 3) ^ 2 := by
      nlinarith [sq_nonneg (x 3 + (1 : ℝ) / 5)]
    nlinarith [hzpair, hz01_le]
  · have hs : (1 : ℝ) / 25 < (x 3) ^ 2 := by
      nlinarith [sq_nonneg (x 3 - (1 : ℝ) / 5)]
    nlinarith [hzpair, hz01_le]
  · have hs : (1 : ℝ) / 25 < (x 4) ^ 2 := by
      nlinarith [sq_nonneg (x 4 + (1 : ℝ) / 5)]
    nlinarith [hq4, hq_le]
  · have hs : (1 : ℝ) / 25 < (x 4) ^ 2 := by
      nlinarith [sq_nonneg (x 4 - (1 : ℝ) / 5)]
    nlinarith [hq4, hq_le]
  · have ht2 : 1 < ((5 : ℝ) * x 5) ^ 2 := by
      nlinarith [sq_nonneg ((5 : ℝ) * x 5 + 1)]
    have ht10 := hpow ((5 : ℝ) * x 5) ht2
    nlinarith [hp5, hp_le]
  · have ht2 : 1 < ((5 : ℝ) * x 5) ^ 2 := by
      nlinarith [sq_nonneg ((5 : ℝ) * x 5 - 1)]
    have ht10 := hpow ((5 : ℝ) * x 5) ht2
    nlinarith [hp5, hp_le]

#print axioms verify_certified_set_in_X_db0a38e9ad57

end LeanBarrier.Generated
