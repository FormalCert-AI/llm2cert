import LeanBarrier

#check Real.sin
#check Real.cos
