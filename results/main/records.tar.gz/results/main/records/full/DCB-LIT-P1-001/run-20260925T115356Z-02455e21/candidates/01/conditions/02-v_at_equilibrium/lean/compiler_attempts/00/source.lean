import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: f732608c241f2f2bb8a120447525ddc0ce0a58335e382fadfba3e8053648862e
noncomputable def barrier_f732608c241f (x : LeanBarrier.State 2) : ℝ := ((((((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi) - (((1 : ℝ) / (2 : ℝ)) * x 0)) + ((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi)) - (((1 : ℝ) / (2 : ℝ)) * x 1)) - (x 0 * x 1))
@[simp] theorem barrier_unfold_f732608c241f (x : LeanBarrier.State 2) : barrier_f732608c241f x = ((((((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi) - (((1 : ℝ) / (2 : ℝ)) * x 0)) + ((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi)) - (((1 : ℝ) / (2 : ℝ)) * x 1)) - (x 0 * x 1)) := by
  rfl
def violationSet_v_at_equilibrium_f732608c241f : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((((((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi) - (((1 : ℝ) / (2 : ℝ)) * x 0)) + ((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi)) - (((1 : ℝ) / (2 : ℝ)) * x 1)) - (x 0 * x 1)) > (0 : ℝ))) ∨ ((((((((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi) - (((1 : ℝ) / (2 : ℝ)) * x 0)) + ((Real.log (Real.cos ((((1 : ℝ) / (4 : ℝ)) * Real.pi))) - Real.log (Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) / Real.pi)) - (((1 : ℝ) / (2 : ℝ)) * x 1)) - (x 0 * x 1)) < (0 : ℝ)))))}

#print axioms barrier_unfold_f732608c241f

end LeanBarrier.Generated
