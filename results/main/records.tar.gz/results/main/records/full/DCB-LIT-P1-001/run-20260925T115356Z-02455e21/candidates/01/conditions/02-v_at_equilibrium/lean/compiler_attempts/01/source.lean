import LeanBarrier.GeneratedCache.Context_25dcda349110bbeea31f38bc8c1b9266e4c62a3cde4875fb100e225ca12e51fe

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_f732608c241f (hV : ContDiff ℝ 1 barrier_f732608c241f) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_f732608c241f := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_f732608c241f, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0, hx1, hx⟩
  simp [hx0, hx1] at hx

#print axioms verify_v_at_equilibrium_f732608c241f

end LeanBarrier.Generated
