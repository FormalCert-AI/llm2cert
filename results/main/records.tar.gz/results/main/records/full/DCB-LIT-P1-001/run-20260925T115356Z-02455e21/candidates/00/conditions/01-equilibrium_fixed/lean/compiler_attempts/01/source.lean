import LeanBarrier

#check Real.sin
#check Real.pi
#check Real.cos
#check Real.sin_pi_div_four
#check Real.cos_pi_div_four
