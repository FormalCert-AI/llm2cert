import LeanBarrier.GeneratedCache.Context_a0297adc8990bbb0d2ce7d8fd57e3f3ebe02ce0acbcd447c86f541a6c26343b4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_f732608c241f (hV : ContDiff ℝ 1 barrier_f732608c241f) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_f732608c241f := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  have hquarter : ((1 : ℝ) / 4) * Real.pi = Real.pi / 4 := by
    ring
  have hs : Real.sin (((1 : ℝ) / 4) * Real.pi) = Real.sqrt 2 / 2 := by
    rw [hquarter]
    exact Real.sin_pi_div_four
  have hc : Real.cos (((1 : ℝ) / 4) * Real.pi) = Real.sqrt 2 / 2 := by
    rw [hquarter]
    exact Real.cos_pi_div_four
  have htan :
      Real.sin (((1 : ℝ) / 4) * Real.pi) /
          Real.cos (((1 : ℝ) / 4) * Real.pi) = 1 := by
    rw [hs, hc]
    apply div_self
    positivity
  simp only [hx0, hx1, mul_zero, zero_add, add_zero] at hbad
  simp only [htan] at hbad
  norm_num at hbad

#print axioms verify_equilibrium_fixed_f732608c241f

end LeanBarrier.Generated
