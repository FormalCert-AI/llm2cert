import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 00550cacd40b2e58ea2f97009102c7591a10beb00d5901292d8e39bad53bb08d
noncomputable def barrier_00550cacd40b (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_00550cacd40b (x : LeanBarrier.State 2) : barrier_00550cacd40b x = ((x 0 ^ 2) + (x 1 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_00550cacd40b : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((((-1 : ℝ) / (2 : ℝ)) * (Real.sin (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))) / Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) + x 1 + ((1 : ℝ) / (2 : ℝ))) > (0 : ℝ))) ∨ ((((((-1 : ℝ) / (2 : ℝ)) * (Real.sin (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))) / Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 0) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))))) + x 1 + ((1 : ℝ) / (2 : ℝ))) < (0 : ℝ))) ∨ ((((x 0 - (((1 : ℝ) / (2 : ℝ)) * (Real.sin (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))) / Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi)))))) + ((1 : ℝ) / (2 : ℝ))) > (0 : ℝ))) ∨ ((((x 0 - (((1 : ℝ) / (2 : ℝ)) * (Real.sin (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi))) / Real.cos (((((1 : ℝ) / (2 : ℝ)) * Real.pi * x 1) + (((1 : ℝ) / (4 : ℝ)) * Real.pi)))))) + ((1 : ℝ) / (2 : ℝ))) < (0 : ℝ)))))}

#print axioms barrier_unfold_00550cacd40b

end LeanBarrier.Generated
