import LeanBarrier.GeneratedCache.Context_fe82834de2aeb02b1f59260a6e4f616809987eaba80fac4ffbf858d17437ece6

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_exponential_decay_5d7aa54f12d2 (hV : ContDiff ℝ 1 barrier_5d7aa54f12d2) : ¬ ∃ x : LeanBarrier.State 8, x ∈ violationSet_exponential_decay_5d7aa54f12d2 := by
  rintro ⟨x, hx⟩
  have cross_bound : ∀ u v c d : ℝ,
      1 ≤ d → -1 ≤ c → c ≤ 1 →
      2 * u * ((v * c) / d) ≤ u ^ 2 + v ^ 2 := by
    intro u v c d hd hcl hcu
    have hdpos : 0 < d := by linarith
    have hal : -1 ≤ c / d := by
      apply (le_div_iff₀ hdpos).2
      nlinarith
    have hau : c / d ≤ 1 := by
      apply (div_le_iff₀ hdpos).2
      nlinarith
    have hprod : 0 ≤ (c / d + 1) * (1 - c / d) :=
      mul_nonneg (by linarith) (by linarith)
    have hasq : (c / d) ^ 2 ≤ 1 := by
      nlinarith [hprod]
    have hrest : 0 ≤ (1 - (c / d) ^ 2) * v ^ 2 :=
      mul_nonneg (by linarith) (sq_nonneg v)
    have hs := sq_nonneg (u - (c / d) * v)
    have hcore : 2 * u * (v * (c / d)) ≤ u ^ 2 + v ^ 2 := by
      nlinarith [hs, hrest]
    calc
      2 * u * ((v * c) / d) = 2 * u * (v * (c / d)) := by ring
      _ ≤ u ^ 2 + v ^ 2 := hcore
  have h01 := cross_bound (x 0) (x 1) (Real.cos (x 0)) ((x 7) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 7)])
    (Real.neg_one_le_cos (x 0)) (Real.cos_le_one (x 0))
  have h12 := cross_bound (x 1) (x 2) (Real.cos (x 1)) ((x 0) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 0)])
    (Real.neg_one_le_cos (x 1)) (Real.cos_le_one (x 1))
  have h23 := cross_bound (x 2) (x 3) (Real.cos (x 2)) ((x 1) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 1)])
    (Real.neg_one_le_cos (x 2)) (Real.cos_le_one (x 2))
  have h34 := cross_bound (x 3) (x 4) (Real.cos (x 3)) ((x 2) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 2)])
    (Real.neg_one_le_cos (x 3)) (Real.cos_le_one (x 3))
  have h45 := cross_bound (x 4) (x 5) (Real.cos (x 0)) ((x 3) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 3)])
    (Real.neg_one_le_cos (x 0)) (Real.cos_le_one (x 0))
  have h56 := cross_bound (x 5) (x 6) (Real.cos (x 1)) ((x 4) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 4)])
    (Real.neg_one_le_cos (x 1)) (Real.cos_le_one (x 1))
  have h67 := cross_bound (x 6) (x 7) (Real.cos (x 2)) ((x 5) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 5)])
    (Real.neg_one_le_cos (x 2)) (Real.cos_le_one (x 2))
  have h70 := cross_bound (x 7) (x 0) (Real.cos (x 3)) ((x 6) ^ 2 + 1)
    (by nlinarith [sq_nonneg (x 6)])
    (Real.neg_one_le_cos (x 3)) (Real.cos_le_one (x 3))
  simp only [violationSet_exponential_decay_5d7aa54f12d2, Set.mem_setOf_eq] at hx
  nlinarith [h01, h12, h23, h34, h45, h56, h67, h70]

#print axioms verify_exponential_decay_5d7aa54f12d2

end LeanBarrier.Generated
