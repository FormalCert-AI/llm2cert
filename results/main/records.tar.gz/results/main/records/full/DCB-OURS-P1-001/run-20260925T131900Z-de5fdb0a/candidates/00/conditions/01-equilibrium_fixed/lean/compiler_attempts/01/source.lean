import LeanBarrier.GeneratedCache.Context_e99e6188bbc33bc345d89de73b4e834569a356ec265bca0af0caddfc5b55c57b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_5d7aa54f12d2 (hV : ContDiff ℝ 1 barrier_5d7aa54f12d2) : ¬ ∃ x : LeanBarrier.State 8, x ∈ violationSet_equilibrium_fixed_5d7aa54f12d2 := by
  rintro ⟨x, hx⟩
  unfold violationSet_equilibrium_fixed_5d7aa54f12d2 at hx
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, h6, h7, hbad⟩
  norm_num [h0, h1, h2, h3, h4, h5, h6, h7] at hbad

#print axioms verify_equilibrium_fixed_5d7aa54f12d2

end LeanBarrier.Generated
