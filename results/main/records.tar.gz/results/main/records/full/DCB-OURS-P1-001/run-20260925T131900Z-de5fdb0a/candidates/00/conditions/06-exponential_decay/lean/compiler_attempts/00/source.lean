import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 5d7aa54f12d248d2a8f9831d840b8f7cd66ec34abf375ee76ef4ec3ebfbc98ee
noncomputable def barrier_5d7aa54f12d2 (x : LeanBarrier.State 8) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2))
@[simp] theorem barrier_unfold_5d7aa54f12d2 (x : LeanBarrier.State 8) : barrier_5d7aa54f12d2 x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2)) := by
  rfl
def violationSet_exponential_decay_5d7aa54f12d2 : Set (LeanBarrier.State 8) := {x | (((((2 : ℝ) * x 0 * (((-3 : ℝ) * x 0) + ((x 1 * Real.cos (x 0)) / ((x 7 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 1 * (((-3 : ℝ) * x 1) + ((x 2 * Real.cos (x 1)) / ((x 0 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 2 * (((-3 : ℝ) * x 2) + ((x 3 * Real.cos (x 2)) / ((x 1 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 3 * (((-3 : ℝ) * x 3) + ((x 4 * Real.cos (x 3)) / ((x 2 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 4 * (((-3 : ℝ) * x 4) + ((x 5 * Real.cos (x 0)) / ((x 3 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 5 * (((-3 : ℝ) * x 5) + ((x 6 * Real.cos (x 1)) / ((x 4 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 6 * (((-3 : ℝ) * x 6) + ((x 7 * Real.cos (x 2)) / ((x 5 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 7 * (((-3 : ℝ) * x 7) + ((x 0 * Real.cos (x 3)) / ((x 6 ^ 2) + (1 : ℝ))))) + ((4 : ℝ) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2) + (x 7 ^ 2)))) > (0 : ℝ)))}

#print axioms barrier_unfold_5d7aa54f12d2

end LeanBarrier.Generated
