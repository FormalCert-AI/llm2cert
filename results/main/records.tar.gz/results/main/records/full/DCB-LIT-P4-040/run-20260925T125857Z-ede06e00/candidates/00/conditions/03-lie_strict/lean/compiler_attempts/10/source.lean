import LeanBarrier.GeneratedCache.Helper_e1f117e4f0e3085efcbb8862e359876ce405fa173bce6ff238fbf42b7a6bcf19

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_scalar_contradiction_75b60a1fd818 (a b c d : ℝ)
    (hB : (((((3 : ℝ) / 5) - a ^ 2) - b ^ 2) - c ^ 2) - d ^ 2 = 0)
    (hL :
      ((-((2 : ℝ) * a)) * ((((-13 : ℝ) / 20) * a) +
          (((1 : ℝ) / 10) * b ^ 2 * Real.cos c)) +
        (-((2 : ℝ) * b)) * ((((-7 : ℝ) / 10) * b) +
          (((3 : ℝ) / 25) * Real.sin a * Real.tanh d)) +
        (-((2 : ℝ) * c)) * ((((-3 : ℝ) / 4) * c) +
          (((2 : ℝ) / 25) * a * b)) +
        (-((2 : ℝ) * d)) * ((((-3 : ℝ) / 5) * d) +
          (((3 : ℝ) / 50) * (a + b)))) ≤ 0) : False := by
  have hs : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 = (3 : ℝ) / 5 := by
    nlinarith [hB]
  obtain ⟨ha, hc⟩ := lie_abs_bounds_75b60a1fd818 a b c d hs
  have hcos := lie_cos_lower_75b60a1fd818 a b c ha
  have hsin := lie_sin_tanh_lower_75b60a1fd818 a b d
  have hcubic := lie_cubic_lower_75b60a1fd818 a b c hc
  have hlinear := lie_linear_coupling_lower_75b60a1fd818 a b d
  rw [lie_expansion_75b60a1fd818 a b c d] at hL
  nlinarith [hL, hcos, hsin, hcubic, hlinear, hs,
    sq_nonneg a, sq_nonneg b, sq_nonneg c, sq_nonneg d]

#print axioms lie_scalar_contradiction_75b60a1fd818

end LeanBarrier.Generated
