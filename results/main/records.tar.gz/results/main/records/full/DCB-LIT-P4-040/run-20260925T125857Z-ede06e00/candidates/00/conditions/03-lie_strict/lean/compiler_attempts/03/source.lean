import LeanBarrier.GeneratedCache.Helper_b5f18eb7e21c1efa2b0461946a1700a20acd73b064719f1e51fe17281b9ace67

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_young_abs_75b60a1fd818 (u v : ℝ) :
    2 * |u * v| ≤ u ^ 2 + v ^ 2 := by
  have hp : 2 * (u * v) ≤ u ^ 2 + v ^ 2 := by
    nlinarith [sq_nonneg (u - v)]
  have hn : -(u ^ 2 + v ^ 2) ≤ 2 * (u * v) := by
    nlinarith [sq_nonneg (u + v)]
  have hh : |2 * (u * v)| ≤ u ^ 2 + v ^ 2 :=
    (abs_le).2 ⟨hn, hp⟩
  simpa [abs_mul] using hh

#print axioms lie_young_abs_75b60a1fd818

end LeanBarrier.Generated
