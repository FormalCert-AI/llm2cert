import LeanBarrier.GeneratedCache.Helper_306bd6c928c3fc131ba815bcbd67e3e62f5d15dda95665672a20b458d3b75551

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_cos_lower_75b60a1fd818 (a b c : ℝ) (ha : |a| ≤ 1) :
    -((1 : ℝ) / 5) * a * b ^ 2 * Real.cos c ≥
      -((1 : ℝ) / 5) * b ^ 2 := by
  have hcos : |Real.cos c| ≤ 1 := Real.abs_cos_le_one c
  have hacosabs : |a * Real.cos c| ≤ 1 := by
    calc
      |a * Real.cos c| = |a| * |Real.cos c| := by rw [abs_mul]
      _ ≤ 1 * |Real.cos c| :=
        mul_le_mul_of_nonneg_right ha (abs_nonneg _)
      _ ≤ 1 := by simpa using hcos
  have hacos : a * Real.cos c ≤ 1 :=
    le_trans (le_abs_self _) hacosabs
  have hp := mul_nonneg (sq_nonneg b) (sub_nonneg.mpr hacos)
  nlinarith

#print axioms lie_cos_lower_75b60a1fd818

end LeanBarrier.Generated
