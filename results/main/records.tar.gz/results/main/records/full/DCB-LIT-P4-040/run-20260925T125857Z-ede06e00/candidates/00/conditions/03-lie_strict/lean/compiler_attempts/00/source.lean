import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 75b60a1fd818d6e23a79cb65a6aa08ef0d2899f3ad6d26121cafdf56d5643dd8
noncomputable def barrier_75b60a1fd818 (x : LeanBarrier.State 4) : ℝ := ((((((3 : ℝ) / (5 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2))
@[simp] theorem barrier_unfold_75b60a1fd818 (x : LeanBarrier.State 4) : barrier_75b60a1fd818 x = ((((((3 : ℝ) / (5 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) := by
  rfl
def violationSet_lie_strict_75b60a1fd818 : Set (LeanBarrier.State 4) := {x | ((((((((3 : ℝ) / (5 : ℝ)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) - (x 3 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-13 : ℝ) / (20 : ℝ)) * x 0) + (((1 : ℝ) / (10 : ℝ)) * (x 1 ^ 2) * Real.cos (x 2)))) + ((-((2 : ℝ) * x 1)) * ((((-7 : ℝ) / (10 : ℝ)) * x 1) + (((3 : ℝ) / (25 : ℝ)) * Real.sin (x 0) * Real.tanh (x 3)))) + ((-((2 : ℝ) * x 2)) * ((((-3 : ℝ) / (4 : ℝ)) * x 2) + (((2 : ℝ) / (25 : ℝ)) * x 0 * x 1))) + ((-((2 : ℝ) * x 3)) * ((((-3 : ℝ) / (5 : ℝ)) * x 3) + (((3 : ℝ) / (50 : ℝ)) * (x 0 + x 1))))) ≤ (0 : ℝ)))}
def unsafeSet_75b60a1fd818 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-11 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((-17 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((8 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((21 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((-19 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((-7 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((13 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((9 : ℝ) / (5 : ℝ))))}
def initialSet_75b60a1fd818 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((1 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((1 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ (0 : ℝ)) ∧ (x 2 ≥ ((1 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((2 : ℝ) / (5 : ℝ))) ∧ (x 3 ≥ ((-1 : ℝ) / (5 : ℝ))) ∧ (x 3 ≤ ((1 : ℝ) / (10 : ℝ))))}

#print axioms barrier_unfold_75b60a1fd818

end LeanBarrier.Generated
