import LeanBarrier.GeneratedCache.Helper_21a73d8f65760914dc6fe6a991a0bac71d729a39d3b18fe2b22ab55c4d4ac465

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_75b60a1fd818 (hV : ContDiff ℝ 1 barrier_75b60a1fd818) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_75b60a1fd818 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hL⟩
  exact lie_scalar_contradiction_75b60a1fd818
    (x 0) (x 1) (x 2) (x 3) hB hL

#print axioms verify_lie_strict_75b60a1fd818

end LeanBarrier.Generated
