import LeanBarrier.GeneratedCache.Helper_9503bc74bc23261bdc75731d26700c5e3fd2a8c7b22cc2ce119aa776c1f452ad

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_linear_coupling_lower_75b60a1fd818 (a b d : ℝ) :
    -((3 : ℝ) / 25) * (d * (a + b)) ≥
      -((3 : ℝ) / 50) * (a ^ 2 + b ^ 2 + 2 * d ^ 2) := by
  nlinarith [le_abs_self (d * a), le_abs_self (d * b),
    lie_young_abs_75b60a1fd818 d a,
    lie_young_abs_75b60a1fd818 d b]

#print axioms lie_linear_coupling_lower_75b60a1fd818

end LeanBarrier.Generated
