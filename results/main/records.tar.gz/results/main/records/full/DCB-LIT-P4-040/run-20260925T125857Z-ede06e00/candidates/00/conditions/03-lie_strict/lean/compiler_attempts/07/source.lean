import LeanBarrier.GeneratedCache.Helper_2f92e8b4662301eff5387bb5ac7618343b5409c9ef304461c72969785c71b5c4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_cubic_lower_75b60a1fd818 (a b c : ℝ) (hc : |c| ≤ 1) :
    -((4 : ℝ) / 25) * (a * b * c) ≥
      -((2 : ℝ) / 25) * (a ^ 2 + b ^ 2) := by
  have hprod : |a * b * c| ≤ |a * b| := by
    calc
      |a * b * c| = |a * b| * |c| := by rw [abs_mul]
      _ ≤ |a * b| * 1 :=
        mul_le_mul_of_nonneg_left hc (abs_nonneg (a * b))
      _ = |a * b| := by ring
  nlinarith [le_abs_self (a * b * c), hprod,
    lie_young_abs_75b60a1fd818 a b]

#print axioms lie_cubic_lower_75b60a1fd818

end LeanBarrier.Generated
