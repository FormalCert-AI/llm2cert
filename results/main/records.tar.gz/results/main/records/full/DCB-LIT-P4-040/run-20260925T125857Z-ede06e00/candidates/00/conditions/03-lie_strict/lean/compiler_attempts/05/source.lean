import LeanBarrier.GeneratedCache.Helper_3192b72280754987a824eaaac452ebcd53e4d79cf8df284a1def5a662b637d8a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_sin_tanh_lower_75b60a1fd818 (a b d : ℝ) :
    -((6 : ℝ) / 25) * (b * Real.sin a * Real.tanh d) ≥
      -((3 : ℝ) / 25) * (a ^ 2 + b ^ 2) := by
  have htanh : |Real.tanh d| ≤ 1 :=
    le_of_lt (Real.abs_tanh_lt_one d)
  have hsina : |Real.sin a| ≤ |a| := Real.abs_sin_le_abs a
  have hsinprod : |b * Real.sin a * Real.tanh d| ≤ |a * b| := by
    have h₁ : |b| * |Real.sin a| ≤ |b| * |a| :=
      mul_le_mul_of_nonneg_left hsina (abs_nonneg b)
    calc
      |b * Real.sin a * Real.tanh d| =
          |b| * |Real.sin a| * |Real.tanh d| := by
            simp only [abs_mul]
      _ ≤ (|b| * |a|) * |Real.tanh d| :=
        mul_le_mul_of_nonneg_right h₁ (abs_nonneg _)
      _ ≤ (|b| * |a|) * 1 :=
        mul_le_mul_of_nonneg_left htanh
          (mul_nonneg (abs_nonneg b) (abs_nonneg a))
      _ = |a * b| := by rw [abs_mul]; ring
  nlinarith [le_abs_self (b * Real.sin a * Real.tanh d),
    hsinprod, lie_young_abs_75b60a1fd818 a b]

#print axioms lie_sin_tanh_lower_75b60a1fd818

end LeanBarrier.Generated
