import LeanBarrier.GeneratedCache.Helper_7c1e1b0b2c56f785f9ed607f369aada0e8abfa15959a129f1d8875716b57d1a1

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem lie_expansion_75b60a1fd818 (a b c d : ℝ) :
    ((-((2 : ℝ) * a)) * ((((-13 : ℝ) / 20) * a) +
        (((1 : ℝ) / 10) * b ^ 2 * Real.cos c)) +
      (-((2 : ℝ) * b)) * ((((-7 : ℝ) / 10) * b) +
        (((3 : ℝ) / 25) * Real.sin a * Real.tanh d)) +
      (-((2 : ℝ) * c)) * ((((-3 : ℝ) / 4) * c) +
        (((2 : ℝ) / 25) * a * b)) +
      (-((2 : ℝ) * d)) * ((((-3 : ℝ) / 5) * d) +
        (((3 : ℝ) / 50) * (a + b)))) =
    ((13 : ℝ) / 10) * a ^ 2 -
      ((1 : ℝ) / 5) * a * b ^ 2 * Real.cos c +
      ((7 : ℝ) / 5) * b ^ 2 -
      ((6 : ℝ) / 25) * (b * Real.sin a * Real.tanh d) +
      ((3 : ℝ) / 2) * c ^ 2 -
      ((4 : ℝ) / 25) * (a * b * c) +
      ((6 : ℝ) / 5) * d ^ 2 -
      ((3 : ℝ) / 25) * (d * (a + b)) := by
  ring

#print axioms lie_expansion_75b60a1fd818

end LeanBarrier.Generated
