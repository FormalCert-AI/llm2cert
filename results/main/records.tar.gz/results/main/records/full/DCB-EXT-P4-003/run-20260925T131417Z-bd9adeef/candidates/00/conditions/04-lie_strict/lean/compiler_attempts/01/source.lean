import LeanBarrier.GeneratedCache.Context_ea966478a7c6aa848cdbcac73e3efe44381025658155194e7dc02aa9b54e213e

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_af26935702e7 (hV : ContDiff ℝ 1 barrier_af26935702e7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_af26935702e7 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hL⟩
  ring_nf at hL
  have hx0 : x 0 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have hx1 : x 1 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have hx2 : x 2 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  have hx3 : x 3 = 0 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]
  norm_num [hx0, hx1, hx2, hx3] at hB

#print axioms verify_lie_strict_af26935702e7

end LeanBarrier.Generated
