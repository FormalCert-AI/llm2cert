import LeanBarrier.GeneratedCache.Context_af9d579cb58dd55e5cb5e04d37af108209a0f4ef824b80c9385d0384c9d298e3

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_control_admissible_af26935702e7 (hV : ContDiff ℝ 1 barrier_af26935702e7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_control_admissible_af26935702e7 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_control_admissible_af26935702e7, Set.mem_setOf_eq] at hx
  norm_num at hx
  have hs_lower : (-1 : ℝ) ≤ Real.sin (x 2) := Real.neg_one_le_sin (x 2)
  have hs_upper : Real.sin (x 2) ≤ (1 : ℝ) := Real.sin_le_one (x 2)
  rcases hx with hx | hx
  · nlinarith
  · nlinarith

#print axioms verify_control_admissible_af26935702e7

end LeanBarrier.Generated
