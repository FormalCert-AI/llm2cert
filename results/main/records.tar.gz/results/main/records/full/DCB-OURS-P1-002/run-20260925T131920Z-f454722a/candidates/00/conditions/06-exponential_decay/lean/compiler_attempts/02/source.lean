import LeanBarrier.GeneratedCache.Context_5610782b35aff36eeca0ab68be26b94f7a5a2d3adfd1c8c856ae3d77d574572a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem bounded_quotient_54663d54d00c (t d : ℝ)
    (htl : -1 ≤ t) (htu : t ≤ 1) (hd : 1 ≤ d) :
    -1 ≤ t / d ∧ t / d ≤ 1 := by
  have hd0 : 0 < d := by linarith
  constructor
  · apply (le_div_iff₀ hd0).2
    nlinarith
  · apply (div_le_iff₀ hd0).2
    nlinarith

#print axioms bounded_quotient_54663d54d00c

end LeanBarrier.Generated
