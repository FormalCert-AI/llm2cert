import LeanBarrier.GeneratedCache.Helper_dd4984f18f36a56f9754db01ed644466cf7378a90542a0ef05ca5e9a53bca441

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_exponential_decay_54663d54d00c (hV : ContDiff ℝ 1 barrier_54663d54d00c) : ¬ ∃ x : LeanBarrier.State 7, x ∈ violationSet_exponential_decay_54663d54d00c := by
  rintro ⟨x, hx⟩
  simp only [violationSet_exponential_decay_54663d54d00c, Set.mem_setOf_eq] at hx
  have hq01 :
      -1 ≤ Real.cos (x 0) / (x 6 ^ 2 + 1) ∧
        Real.cos (x 0) / (x 6 ^ 2 + 1) ≤ 1 := by
    apply bounded_quotient_54663d54d00c
    · exact Real.neg_one_le_cos (x 0)
    · exact Real.cos_le_one (x 0)
    · nlinarith [sq_nonneg (x 6)]
  have hq13 :
      -1 ≤ Real.sin (2 * x 1) / (2 * x 0 ^ 2 + 1) ∧
        Real.sin (2 * x 1) / (2 * x 0 ^ 2 + 1) ≤ 1 := by
    apply bounded_quotient_54663d54d00c
    · exact Real.neg_one_le_sin (2 * x 1)
    · exact Real.sin_le_one (2 * x 1)
    · nlinarith [sq_nonneg (x 0)]
  have hq25 :
      -1 ≤ Real.cos ((1 / 2 : ℝ) * x 2) / ((3 / 2 : ℝ) * x 1 ^ 2 + 1) ∧
        Real.cos ((1 / 2 : ℝ) * x 2) / ((3 / 2 : ℝ) * x 1 ^ 2 + 1) ≤ 1 := by
    apply bounded_quotient_54663d54d00c
    · exact Real.neg_one_le_cos ((1 / 2 : ℝ) * x 2)
    · exact Real.cos_le_one ((1 / 2 : ℝ) * x 2)
    · nlinarith [sq_nonneg (x 1)]
  have hq36 :
      -1 ≤ Real.sin ((3 / 2 : ℝ) * x 3) / (3 * x 2 ^ 2 + 1) ∧
        Real.sin ((3 / 2 : ℝ) * x 3) / (3 * x 2 ^ 2 + 1) ≤ 1 := by


#print axioms verify_exponential_decay_54663d54d00c

end LeanBarrier.Generated
