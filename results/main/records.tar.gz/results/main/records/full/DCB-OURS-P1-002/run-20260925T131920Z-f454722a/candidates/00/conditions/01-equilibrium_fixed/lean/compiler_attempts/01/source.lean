import LeanBarrier.GeneratedCache.Context_4de7a061929f58a39e9da1d306ef824f59b44fa16106d6911262cd6fd5f026bb

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_54663d54d00c (hV : ContDiff ℝ 1 barrier_54663d54d00c) : ¬ ∃ x : LeanBarrier.State 7, x ∈ violationSet_equilibrium_fixed_54663d54d00c := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, h2, h3, h4, h5, h6, hbad⟩
  norm_num [h0, h1, h2, h3, h4, h5, h6] at hbad

#print axioms verify_equilibrium_fixed_54663d54d00c

end LeanBarrier.Generated
