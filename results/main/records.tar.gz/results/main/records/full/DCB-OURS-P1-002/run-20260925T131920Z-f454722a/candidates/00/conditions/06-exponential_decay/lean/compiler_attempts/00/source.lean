import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 54663d54d00c17827888edeacc3c16089051c3fb9f6aa3e0aff1fde46b513c45
noncomputable def barrier_54663d54d00c (x : LeanBarrier.State 7) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2))
@[simp] theorem barrier_unfold_54663d54d00c (x : LeanBarrier.State 7) : barrier_54663d54d00c x = ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2)) := by
  rfl
def violationSet_exponential_decay_54663d54d00c : Set (LeanBarrier.State 7) := {x | (((((2 : ℝ) * x 0 * (((-5 : ℝ) * x 0) + ((x 1 * Real.cos (x 0)) / ((x 6 ^ 2) + (1 : ℝ))))) + ((2 : ℝ) * x 1 * ((((-9 : ℝ) / (2 : ℝ)) * x 1) + ((((6 : ℝ) / (5 : ℝ)) * x 3 * Real.sin (((2 : ℝ) * x 1))) / (((2 : ℝ) * (x 0 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 2 * (((-6 : ℝ) * x 2) + ((((4 : ℝ) / (5 : ℝ)) * x 5 * Real.cos ((((1 : ℝ) / (2 : ℝ)) * x 2))) / ((((3 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 3 * ((((-11 : ℝ) / (2 : ℝ)) * x 3) + ((((3 : ℝ) / (2 : ℝ)) * x 6 * Real.sin ((((3 : ℝ) / (2 : ℝ)) * x 3))) / (((3 : ℝ) * (x 2 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 4 * (((-5 : ℝ) * x 4) + ((((9 : ℝ) / (10 : ℝ)) * x 0 * Real.cos (((2 : ℝ) * x 4))) / ((((4 : ℝ) / (3 : ℝ)) * (x 3 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 5 * ((((-9 : ℝ) / (2 : ℝ)) * x 5) + ((((7 : ℝ) / (5 : ℝ)) * x 4 * Real.sin ((((1 : ℝ) / (3 : ℝ)) * x 5))) / ((((5 : ℝ) / (2 : ℝ)) * (x 4 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 6 * (((-6 : ℝ) * x 6) + ((((1 : ℝ) / (2 : ℝ)) * x 2 * Real.cos ((((5 : ℝ) / (2 : ℝ)) * x 6))) / ((((1 : ℝ) / (2 : ℝ)) * (x 4 ^ 2)) + (1 : ℝ))))) + (((34 : ℝ) / (5 : ℝ)) * ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2) + (x 6 ^ 2)))) > (0 : ℝ)))}

#print axioms barrier_unfold_54663d54d00c

end LeanBarrier.Generated
