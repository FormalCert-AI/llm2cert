import LeanBarrier.GeneratedCache.Context_84bf9cadad4175a105f7a19b2105e9c21fefc9dd910e8f281d164d72bea0f0dd

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem quotient_abs_le_one_d56e3ddecc65 (u d : ℝ) (hu : |u| ≤ 1) (hd : 1 ≤ d) :
    |u / d| ≤ 1 := by
  have hd0 : 0 < d := lt_of_lt_of_le zero_lt_one hd
  rw [abs_div, abs_of_pos hd0]
  apply (div_le_iff₀ hd0).2
  nlinarith

#print axioms quotient_abs_le_one_d56e3ddecc65

end LeanBarrier.Generated
