import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: d56e3ddecc65cc4a148fb2efe449da1be1457b9bc68178c80bf29b30a642a50d
noncomputable def barrier_d56e3ddecc65 (x : LeanBarrier.State 7) : ℝ := ((x 0 ^ 2) + ((2 : ℝ) * (x 1 ^ 2)) + (x 2 ^ 2) + ((2 : ℝ) * (x 3 ^ 2)) + (x 4 ^ 2) + ((2 : ℝ) * (x 5 ^ 2)) + (x 6 ^ 2))
@[simp] theorem barrier_unfold_d56e3ddecc65 (x : LeanBarrier.State 7) : barrier_d56e3ddecc65 x = ((x 0 ^ 2) + ((2 : ℝ) * (x 1 ^ 2)) + (x 2 ^ 2) + ((2 : ℝ) * (x 3 ^ 2)) + (x 4 ^ 2) + ((2 : ℝ) * (x 5 ^ 2)) + (x 6 ^ 2)) := by
  rfl
def violationSet_exponential_decay_d56e3ddecc65 : Set (LeanBarrier.State 7) := {x | (((((2 : ℝ) * x 0 * (((-5 : ℝ) * x 0) + ((x 1 * Real.cos (x 0)) / ((x 6 ^ 2) + (1 : ℝ))))) + ((4 : ℝ) * x 1 * ((((-9 : ℝ) / (2 : ℝ)) * x 1) + ((((6 : ℝ) / (5 : ℝ)) * x 3 * Real.sin (((2 : ℝ) * x 1))) / (((2 : ℝ) * (x 0 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 2 * (((-6 : ℝ) * x 2) + ((((4 : ℝ) / (5 : ℝ)) * x 5 * Real.cos ((((1 : ℝ) / (2 : ℝ)) * x 2))) / ((((3 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (1 : ℝ))))) + ((4 : ℝ) * x 3 * ((((-11 : ℝ) / (2 : ℝ)) * x 3) + ((((3 : ℝ) / (2 : ℝ)) * x 6 * Real.sin ((((3 : ℝ) / (2 : ℝ)) * x 3))) / (((3 : ℝ) * (x 2 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 4 * (((-5 : ℝ) * x 4) + ((((9 : ℝ) / (10 : ℝ)) * x 0 * Real.cos (((2 : ℝ) * x 4))) / ((((4 : ℝ) / (3 : ℝ)) * (x 3 ^ 2)) + (1 : ℝ))))) + ((4 : ℝ) * x 5 * ((((-9 : ℝ) / (2 : ℝ)) * x 5) + ((((7 : ℝ) / (5 : ℝ)) * x 4 * Real.sin ((((1 : ℝ) / (3 : ℝ)) * x 5))) / ((((5 : ℝ) / (2 : ℝ)) * (x 4 ^ 2)) + (1 : ℝ))))) + ((2 : ℝ) * x 6 * (((-6 : ℝ) * x 6) + ((((1 : ℝ) / (2 : ℝ)) * x 2 * Real.cos ((((5 : ℝ) / (2 : ℝ)) * x 6))) / ((((1 : ℝ) / (2 : ℝ)) * (x 4 ^ 2)) + (1 : ℝ))))) + ((6 : ℝ) * ((x 0 ^ 2) + ((2 : ℝ) * (x 1 ^ 2)) + (x 2 ^ 2) + ((2 : ℝ) * (x 3 ^ 2)) + (x 4 ^ 2) + ((2 : ℝ) * (x 5 ^ 2)) + (x 6 ^ 2)))) > (0 : ℝ)))}

#print axioms barrier_unfold_d56e3ddecc65

end LeanBarrier.Generated
