import LeanBarrier.GeneratedCache.Helper_042cc62e30499ac76908db96a0f92305e9d75780fd95b9adc2dfc97c45386835

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem cross_term_bound_54663d54d00c (a b q : ℝ)
    (hql : -1 ≤ q) (hqu : q ≤ 1) :
    2 * a * b * q ≤ a ^ 2 + b ^ 2 := by
  by_cases hab : 0 ≤ a * b
  · have hm := mul_le_mul_of_nonneg_left hqu hab
    have hs := sq_nonneg (a - b)
    nlinarith
  · have hab' : a * b ≤ 0 := le_of_not_ge hab
    have hm := mul_le_mul_of_nonpos_left hql hab'
    have hs := sq_nonneg (a + b)
    nlinarith

#print axioms cross_term_bound_54663d54d00c

end LeanBarrier.Generated
