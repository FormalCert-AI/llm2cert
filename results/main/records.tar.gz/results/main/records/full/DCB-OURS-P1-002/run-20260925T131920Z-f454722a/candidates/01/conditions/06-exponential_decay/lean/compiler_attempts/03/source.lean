import LeanBarrier.GeneratedCache.Helper_fb6e8b9e84ea41593c4532dfcdd27fed3343f2173d012fcd130d3f95f91b6cc1

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_exponential_decay_d56e3ddecc65 (hV : ContDiff ℝ 1 barrier_d56e3ddecc65) : ¬ ∃ x : LeanBarrier.State 7, x ∈ violationSet_exponential_decay_d56e3ddecc65 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_exponential_decay_d56e3ddecc65, Set.mem_setOf_eq] at hx

  have hd0 : 1 ≤ (x 6) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 6)]
  have hq0 :
      |Real.cos (x 0) / ((x 6) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_cos _, Real.cos_le_one _⟩
    exact hd0

  have hd1 : 1 ≤ 2 * (x 0) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 0)]
  have hq1 :
      |Real.sin (2 * x 1) / (2 * (x 0) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_sin _, Real.sin_le_one _⟩
    exact hd1

  have hd2 : 1 ≤ (3 / 2 : ℝ) * (x 1) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 1)]
  have hq2 :
      |Real.cos ((1 / 2 : ℝ) * x 2) /
          ((3 / 2 : ℝ) * (x 1) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_cos _, Real.cos_le_one _⟩
    exact hd2

  have hd3 : 1 ≤ 3 * (x 2) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 2)]
  have hq3 :
      |Real.sin ((3 / 2 : ℝ) * x 3) / (3 * (x 2) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_sin _, Real.sin_le_one _⟩
    exact hd3

  have hd4 : 1 ≤ (4 / 3 : ℝ) * (x 3) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 3)]
  have hq4 :
      |Real.cos (2 * x 4) / ((4 / 3 : ℝ) * (x 3) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_cos _, Real.cos_le_one _⟩
    exact hd4

  have hd5 : 1 ≤ (5 / 2 : ℝ) * (x 4) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 4)]
  have hq5 :
      |Real.sin ((1 / 3 : ℝ) * x 5) /
          ((5 / 2 : ℝ) * (x 4) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_sin _, Real.sin_le_one _⟩
    exact hd5

  have hd6 : 1 ≤ (1 / 2 : ℝ) * (x 4) ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 4)]
  have hq6 :
      |Real.cos ((5 / 2 : ℝ) * x 6) /
          ((1 / 2 : ℝ) * (x 4) ^ 2 + 1)| ≤ 1 := by
    apply quotient_abs_le_one_d56e3ddecc65
    exact abs_le.mpr ⟨Real.neg_one_le_cos _, Real.cos_le_one _⟩
    exact hd6

  have hy0 := young_of_abs_le_one_d56e3ddecc65
    (x 0) (x 1) (Real.cos (x 0) / ((x 6) ^ 2 + 1)) hq0
  have hy1 := young_of_abs_le_one_d56e3ddecc65
    (x 1) (x 3) (Real.sin (2 * x 1) / (2 * (x 0) ^ 2 + 1)) hq1
  have hy2 := young_of_abs_le_one_d56e3ddecc65
    (x 2) (x 5)
    (Real.cos ((1 / 2 : ℝ) * x 2) /
      ((3 / 2 : ℝ) * (x 1) ^ 2 + 1)) hq2
  have hy3 := young_of_abs_le_one_d56e3ddecc65
    (x 3) (x 6)
    (Real.sin ((3 / 2 : ℝ) * x 3) / (3 * (x 2) ^ 2 + 1)) hq3
  have hy4 := young_of_abs_le_one_d56e3ddecc65
    (x 4) (x 0)
    (Real.cos (2 * x 4) / ((4 / 3 : ℝ) * (x 3) ^ 2 + 1)) hq4
  have hy5 := young_of_abs_le_one_d56e3ddecc65
    (x 5) (x 4)
    (Real.sin ((1 / 3 : ℝ) * x 5) /
      ((5 / 2 : ℝ) * (x 4) ^ 2 + 1)) hq5
  have hy6 := young_of_abs_le_one_d56e3ddecc65
    (x 6) (x 2)
    (Real.cos ((5 / 2 : ℝ) * x 6) /
      ((1 / 2 : ℝ) * (x 4) ^ 2 + 1)) hq6

  ring_nf at hx hy0 hy1 hy2 hy3 hy4 hy5 hy6
  nlinarith [hy0, hy1, hy2, hy3, hy4, hy5, hy6,
    sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2),
    sq_nonneg (x 3), sq_nonneg (x 4), sq_nonneg (x 5),
    sq_nonneg (x 6)]

#print axioms verify_exponential_decay_d56e3ddecc65

end LeanBarrier.Generated
