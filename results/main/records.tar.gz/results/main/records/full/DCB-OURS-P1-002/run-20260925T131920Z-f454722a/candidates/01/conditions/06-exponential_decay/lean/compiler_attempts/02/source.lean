import LeanBarrier.GeneratedCache.Helper_80425c373da27534f1151ceac0f0724dbf6fc377bf39f1932868e88e0da65d28

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem young_of_abs_le_one_d56e3ddecc65 (a b q : ℝ) (hq : |q| ≤ 1) :
    2 * a * b * q ≤ a ^ 2 + b ^ 2 := by
  have hqb : -1 ≤ q ∧ q ≤ 1 := abs_le.mp hq
  have hp : 0 ≤ (1 - q) * (1 + q) :=
    mul_nonneg (sub_nonneg.mpr hqb.2) (by linarith [hqb.1])
  have hq2 : q ^ 2 ≤ 1 := by
    nlinarith [hp]
  have ham : 0 ≤ a ^ 2 * (1 - q ^ 2) :=
    mul_nonneg (sq_nonneg a) (sub_nonneg.mpr hq2)
  nlinarith [sq_nonneg (a * q - b), ham]

#print axioms young_of_abs_le_one_d56e3ddecc65

end LeanBarrier.Generated
