import LeanBarrier.GeneratedCache.Context_ec2330d5b266843d72af5afe0b5aea5576318fa3edc73e7c7568d509113b7bf6

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_99bc96eb727c (hV : ContDiff ℝ 1 barrier_99bc96eb727c) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_99bc96eb727c := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx2, hbad⟩
  simp [hx0, hx1, hx2] at hbad

#print axioms verify_equilibrium_fixed_99bc96eb727c

end LeanBarrier.Generated
