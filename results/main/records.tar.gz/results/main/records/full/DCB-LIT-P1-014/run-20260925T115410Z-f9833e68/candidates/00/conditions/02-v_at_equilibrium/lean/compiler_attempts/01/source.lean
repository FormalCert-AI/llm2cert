import LeanBarrier.GeneratedCache.Context_2adddfa8bcc095179ab4b879b803aad3255651a54b1745b8f9478edfc1ccc5be

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_98b3e0854be8 (hV : ContDiff ℝ 1 barrier_98b3e0854be8) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_v_at_equilibrium_98b3e0854be8 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨h0, h1, h2, hbad⟩
  rcases hbad with hpos | hneg
  · norm_num [h0, h1, h2] at hpos
  · norm_num [h0, h1, h2] at hneg

#print axioms verify_v_at_equilibrium_98b3e0854be8

end LeanBarrier.Generated
