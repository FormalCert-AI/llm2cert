import LeanBarrier

#check Real.sin
#check Real.cos
#check Real.one_sub_sq_div_two_le_cos
#check Real.sin_two_mul
#check Real.sin_neg
