import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 98b3e0854be8a823ae5f5a48863246b5d6e5afcd3daeb0813fffcf87c2f0ff8c
noncomputable def barrier_98b3e0854be8 (x : LeanBarrier.State 3) : ℝ := ((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * x 0 * x 1))
@[simp] theorem barrier_unfold_98b3e0854be8 (x : LeanBarrier.State 3) : barrier_98b3e0854be8 x = ((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * x 0 * x 1)) := by
  rfl
def violationSet_v_at_equilibrium_98b3e0854be8 : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * x 0 * x 1)) > (0 : ℝ))) ∨ ((((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (50 : ℝ)) * x 0 * x 1)) < (0 : ℝ)))))}

#print axioms barrier_unfold_98b3e0854be8

end LeanBarrier.Generated
