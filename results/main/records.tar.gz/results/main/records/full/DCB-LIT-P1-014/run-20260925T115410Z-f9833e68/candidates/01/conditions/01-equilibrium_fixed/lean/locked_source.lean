-- candidate-sha256: 99bc96eb727c75497be50f5b49df4d9a6614ed068824548dffb7b82f7f9dd01c
noncomputable def barrier_99bc96eb727c (x : LeanBarrier.State 3) : ℝ := ((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (100 : ℝ)) * x 1 * ((Real.sin (x 0) * Real.cos (x 0)) + (Real.sin (x 2) * Real.cos (x 2)))))
@[simp] theorem barrier_unfold_99bc96eb727c (x : LeanBarrier.State 3) : barrier_99bc96eb727c x = ((Real.sin (x 0) ^ 2) + (x 1 ^ 2) + (Real.sin (x 2) ^ 2) + (((1 : ℝ) / (100 : ℝ)) * x 1 * ((Real.sin (x 0) * Real.cos (x 0)) + (Real.sin (x 2) * Real.cos (x 2))))) := by
  rfl
def violationSet_equilibrium_fixed_99bc96eb727c : Set (LeanBarrier.State 3) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (((x 1 > (0 : ℝ))) ∨ ((x 1 < (0 : ℝ))) ∨ ((((((-Real.sin (x 0)) * Real.cos (x 0)) - x 1) - (Real.sin (x 2) * Real.cos (x 2))) > (0 : ℝ))) ∨ ((((((-Real.sin (x 0)) * Real.cos (x 0)) - x 1) - (Real.sin (x 2) * Real.cos (x 2))) < (0 : ℝ))) ∨ (((x 1 - x 2) > (0 : ℝ))) ∨ (((x 1 - x 2) < (0 : ℝ)))))}

theorem verify_equilibrium_fixed_99bc96eb727c (hV : ContDiff ℝ 1 barrier_99bc96eb727c) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_99bc96eb727c
