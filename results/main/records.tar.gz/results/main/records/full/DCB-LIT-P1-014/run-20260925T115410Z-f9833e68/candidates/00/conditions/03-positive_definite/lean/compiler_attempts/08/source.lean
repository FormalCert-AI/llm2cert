import LeanBarrier.GeneratedCache.Helper_d011b2f33b05fe36daad9ac8fd45da9e71e86b29c7b44bfa5199b3803f0ab68b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_98b3e0854be8 (hV : ContDiff ℝ 1 barrier_98b3e0854be8) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_positive_definite_98b3e0854be8 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_positive_definite_98b3e0854be8, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hx2l, hx2u, hne, hnonpos⟩
  have hs0 : (x 0) ^ 2 / 4 ≤ Real.sin (x 0) ^ 2 :=
    sin_sq_ge_quarter_sq_on_three_halves (x 0) hx0l hx0u
  have hs2 : (x 2) ^ 2 / 4 ≤ Real.sin (x 2) ^ 2 :=
    sin_sq_ge_quarter_sq_on_three_halves (x 2) hx2l hx2u
  have hcross : 0 ≤ (x 0 + x 1) ^ 2 := sq_nonneg (x 0 + x 1)
  nlinarith

#print axioms verify_positive_definite_98b3e0854be8

end LeanBarrier.Generated
