import LeanBarrier

#check Real.continuous_cos.intervalIntegrable
