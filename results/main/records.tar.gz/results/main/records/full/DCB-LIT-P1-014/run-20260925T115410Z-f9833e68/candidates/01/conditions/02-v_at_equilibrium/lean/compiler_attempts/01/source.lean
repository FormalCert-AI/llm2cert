import LeanBarrier.GeneratedCache.Context_5bf111024baaf4824076a6b0dfd57fc6d0946df9df9b91a46c87b5c76b5f966a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_99bc96eb727c (hV : ContDiff ℝ 1 barrier_99bc96eb727c) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_v_at_equilibrium_99bc96eb727c := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_99bc96eb727c, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0, hx1, hx2, hx⟩
  simp [hx0, hx1, hx2] at hx

#print axioms verify_v_at_equilibrium_99bc96eb727c

end LeanBarrier.Generated
