import LeanBarrier

#check Real.cos_two_mul
#check Real.pi
#check Real.pi_gt_three
#check Real.mul_cos_le_sin
#check Real.cos_neg
#check Real.abs_sin_le_abs
#check Real.abs_cos_le_one
