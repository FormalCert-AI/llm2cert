import LeanBarrier.GeneratedCache.Context_de9a9c9f02be31c1f7b4aeff6f2e54b05e35a0ac700fe3e9f3df289163e28dcc

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_98b3e0854be8 (hV : ContDiff ℝ 1 barrier_98b3e0854be8) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_98b3e0854be8 := by
  rintro ⟨x, h0, h1, h2, hbad⟩
  norm_num [h0, h1, h2] at hbad

#print axioms verify_equilibrium_fixed_98b3e0854be8

end LeanBarrier.Generated
