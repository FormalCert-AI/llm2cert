import LeanBarrier

#check Real.abs_sin_le_abs
#check Real.cos_two_mul
#check Real.sin_sq_add_cos_sq
#check Real.mul_cos_le_sin
#check Real.pi_gt_three
