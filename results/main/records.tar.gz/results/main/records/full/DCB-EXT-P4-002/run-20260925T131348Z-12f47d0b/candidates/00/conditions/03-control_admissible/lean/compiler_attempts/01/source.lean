import LeanBarrier.GeneratedCache.Context_580d22064b582ac5653edae799bebe148f7a9c5adb05f3bb11871a61f61f3f02

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_control_admissible_25de0385df95 (hV : ContDiff ℝ 1 barrier_25de0385df95) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_control_admissible_25de0385df95 := by
  rintro ⟨x, hx⟩
  change
    ((-x 0) / (x 0 ^ 2 + (1 : ℝ)) < (-1 : ℝ)) ∨
      ((-x 0) / (x 0 ^ 2 + (1 : ℝ)) > (1 : ℝ)) ∨
      ((-x 1) / (x 1 ^ 2 + (1 : ℝ)) < (-1 : ℝ)) ∨
      ((-x 1) / (x 1 ^ 2 + (1 : ℝ)) > (1 : ℝ)) at hx
  rcases hx with h | h | h | h
  · have hd : 0 < x 0 ^ 2 + (1 : ℝ) := by
      nlinarith [sq_nonneg (x 0)]
    have hm := (div_lt_iff₀ hd).mp h
    nlinarith [sq_nonneg (2 * x 0 - 1)]
  · have hd : 0 < x 0 ^ 2 + (1 : ℝ) := by
      nlinarith [sq_nonneg (x 0)]
    have hm := (lt_div_iff₀ hd).mp h
    nlinarith [sq_nonneg (2 * x 0 + 1)]
  · have hd : 0 < x 1 ^ 2 + (1 : ℝ) := by
      nlinarith [sq_nonneg (x 1)]
    have hm := (div_lt_iff₀ hd).mp h
    nlinarith [sq_nonneg (2 * x 1 - 1)]
  · have hd : 0 < x 1 ^ 2 + (1 : ℝ) := by
      nlinarith [sq_nonneg (x 1)]
    have hm := (lt_div_iff₀ hd).mp h
    nlinarith [sq_nonneg (2 * x 1 + 1)]

#print axioms verify_control_admissible_25de0385df95

end LeanBarrier.Generated
