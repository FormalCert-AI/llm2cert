import LeanBarrier.GeneratedCache.Context_62dc7e9f62270b103016db0660a0200f225e79447c8e2a4799ece68c2f1ec394

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_fcd4d2914585 (hV : ContDiff ℝ 1 barrier_fcd4d2914585) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_fcd4d2914585 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_fcd4d2914585, Set.mem_setOf_eq] at hx
  rcases hx with ⟨ha0, ha1, hb0, hb1, hball, hpos, hlie⟩
  have hs : |Real.sin (x 0)| ≤ |x 0| := Real.abs_sin_le_abs (x 0)
  have hyoung :
      |x 1 * x 0| ≤ 2 * (x 0) ^ 2 + (x 1) ^ 2 / 8 := by
    rw [abs_le]
    constructor
    · nlinarith [sq_nonneg (4 * x 0 + x 1)]
    · nlinarith [sq_nonneg (4 * x 0 - x 1)]
  have hcross :
      x 1 * Real.sin (x 0) ≤ 2 * (x 0) ^ 2 + (x 1) ^ 2 / 8 := by
    calc
      x 1 * Real.sin (x 0) ≤ |x 1 * Real.sin (x 0)| := le_abs_self _
      _ = |x 1| * |Real.sin (x 0)| := abs_mul _ _
      _ ≤ |x 1| * |x 0| :=
        mul_le_mul_of_nonneg_left hs (abs_nonneg _)
      _ = |x 1 * x 0| := (abs_mul _ _).symm
      _ ≤ 2 * (x 0) ^ 2 + (x 1) ^ 2 / 8 := hyoung
  ring_nf at hlie
  have hupper :
      (-80 : ℝ) * (x 0) ^ 2
          + ((981 : ℝ) / 25) * (x 1 * Real.sin (x 0))
          - ((16 : ℝ) / 3) * (x 1) ^ 2
        ≤ -((38 : ℝ) / 25) * (x 0) ^ 2
          - ((257 : ℝ) / 600) * (x 1) ^ 2 := by
    nlinarith [hcross]
  nlinarith [sq_nonneg (x 0), sq_nonneg (x 1)]

#print axioms verify_lie_negative_fcd4d2914585

end LeanBarrier.Generated
