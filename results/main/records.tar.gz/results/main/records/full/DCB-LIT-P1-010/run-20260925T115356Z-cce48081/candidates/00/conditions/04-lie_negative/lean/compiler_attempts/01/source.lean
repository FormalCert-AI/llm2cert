import LeanBarrier

#check Real.sin
#check Real.abs_sin_le_abs
