import LeanBarrier.GeneratedCache.Context_7b78b1f72334adf110322c606c145deb03b7172bd2da258bce4eb7d227323a3b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_fcd4d2914585 (hV : ContDiff ℝ 1 barrier_fcd4d2914585) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_fcd4d2914585 := by
  rintro ⟨x, hx⟩
  change x 0 = (0 : ℝ) ∧ x 1 = (0 : ℝ) ∧ _ at hx
  rcases hx with ⟨h0, h1, hbad⟩
  norm_num [h0, h1] at hbad

#print axioms verify_equilibrium_fixed_fcd4d2914585

end LeanBarrier.Generated
