import LeanBarrier.GeneratedCache.Context_548cd76ba5bd75428d166cf77b331496295204b31f791936c4215474adc7bb90

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_discrete_inductive_739b738b38ae (hV : ContDiff ℝ 1 barrier_739b738b38ae) : ¬ ∃ x : LeanBarrier.State 6, x ∈ workingSet_739b738b38ae ∧ barrier_739b738b38ae x ≥ 0 ∧ barrier_739b738b38ae (closedLoop_739b738b38ae x) < 0 := by
  rintro ⟨x, _hx, hBx, hBnext⟩
  rw [barrier_unfold_739b738b38ae] at hBx
  have hr : x 0 ^ 2 + x 1 ^ 2 - 1 = 0 := by
    nlinarith [
      sq_nonneg (x 0 ^ 2 + x 1 ^ 2 - 1),
      sq_nonneg (x 2), sq_nonneg (x 3),
      sq_nonneg (x 4), sq_nonneg (x 5)]
  have hx2 : x 2 = 0 := by
    nlinarith [
      sq_nonneg (x 0 ^ 2 + x 1 ^ 2 - 1),
      sq_nonneg (x 2), sq_nonneg (x 3),
      sq_nonneg (x 4), sq_nonneg (x 5)]
  have hx3 : x 3 = 0 := by
    nlinarith [
      sq_nonneg (x 0 ^ 2 + x 1 ^ 2 - 1),
      sq_nonneg (x 2), sq_nonneg (x 3),
      sq_nonneg (x 4), sq_nonneg (x 5)]
  have hx4 : x 4 = 0 := by
    nlinarith [
      sq_nonneg (x 0 ^ 2 + x 1 ^ 2 - 1),
      sq_nonneg (x 2), sq_nonneg (x 3),
      sq_nonneg (x 4), sq_nonneg (x 5)]
  have hx5 : x 5 = 0 := by
    nlinarith [
      sq_nonneg (x 0 ^ 2 + x 1 ^ 2 - 1),
      sq_nonneg (x 2), sq_nonneg (x 3),
      sq_nonneg (x 4), sq_nonneg (x 5)]
  have hclosed : barrier_739b738b38ae (closedLoop_739b738b38ae x) = 0 := by
    rw [barrier_unfold_739b738b38ae]
    simp [hx2, hx3, hx4, hx5, hr]
  rw [hclosed] at hBnext
  exact (lt_irrefl 0) hBnext

#print axioms verify_discrete_inductive_739b738b38ae

end LeanBarrier.Generated
