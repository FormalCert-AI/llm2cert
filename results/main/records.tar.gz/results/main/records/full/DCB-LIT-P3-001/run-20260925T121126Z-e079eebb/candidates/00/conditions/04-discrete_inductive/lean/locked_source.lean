-- candidate-sha256: 739b738b38ae182fa803cea153e3804bdb758582d01ec7d6494f3e88ae940b18
noncomputable def barrier_739b738b38ae (x : LeanBarrier.State 6) : ℝ := (-(((((x 0 ^ 2) + (x 1 ^ 2)) - (1 : ℝ)) ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2)))
@[simp] theorem barrier_unfold_739b738b38ae (x : LeanBarrier.State 6) : barrier_739b738b38ae x = (-(((((x 0 ^ 2) + (x 1 ^ 2)) - (1 : ℝ)) ^ 2) + (x 2 ^ 2) + (x 3 ^ 2) + (x 4 ^ 2) + (x 5 ^ 2))) := by
  rfl
noncomputable def closedLoop_739b738b38ae (x : LeanBarrier.State 6) : LeanBarrier.State 6 := ![(x 0 + (((1 : ℝ) / (20 : ℝ)) * ((x 3 * Real.cos (x 2)) - (x 4 * Real.sin (x 2))))), (x 1 + (((1 : ℝ) / (20 : ℝ)) * ((x 3 * Real.sin (x 2)) + (x 4 * Real.cos (x 2))))), (x 2 + (((1 : ℝ) / (20 : ℝ)) * x 5)), (x 3 + (((1 : ℝ) / (20 : ℝ)) * ((x 4 * x 5) - (((49 : ℝ) / (5 : ℝ)) * Real.sin (x 2))))), (x 4 + (((1 : ℝ) / (20 : ℝ)) * ((((-x 3) * x 5) - (((49 : ℝ) / (5 : ℝ)) * Real.cos (x 2))) + ((49 : ℝ) / (5 : ℝ))))), x 5]
@[simp] theorem closedLoop_apply_0_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 0 = (x 0 + (((1 : ℝ) / (20 : ℝ)) * ((x 3 * Real.cos (x 2)) - (x 4 * Real.sin (x 2))))) := by
  simp [closedLoop_739b738b38ae]
@[simp] theorem closedLoop_apply_1_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 1 = (x 1 + (((1 : ℝ) / (20 : ℝ)) * ((x 3 * Real.sin (x 2)) + (x 4 * Real.cos (x 2))))) := by
  simp [closedLoop_739b738b38ae]
@[simp] theorem closedLoop_apply_2_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 2 = (x 2 + (((1 : ℝ) / (20 : ℝ)) * x 5)) := by
  simp [closedLoop_739b738b38ae]
@[simp] theorem closedLoop_apply_3_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 3 = (x 3 + (((1 : ℝ) / (20 : ℝ)) * ((x 4 * x 5) - (((49 : ℝ) / (5 : ℝ)) * Real.sin (x 2))))) := by
  simp [closedLoop_739b738b38ae]
@[simp] theorem closedLoop_apply_4_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 4 = (x 4 + (((1 : ℝ) / (20 : ℝ)) * ((((-x 3) * x 5) - (((49 : ℝ) / (5 : ℝ)) * Real.cos (x 2))) + ((49 : ℝ) / (5 : ℝ))))) := by
  simp [closedLoop_739b738b38ae]
@[simp] theorem closedLoop_apply_5_739b738b38ae (x : LeanBarrier.State 6) : closedLoop_739b738b38ae x 5 = x 5 := by
  simp [closedLoop_739b738b38ae]
def workingSet_739b738b38ae : Set (LeanBarrier.State 6) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (x 2 ≥ (-1 : ℝ)) ∧ (x 2 ≤ (1 : ℝ)) ∧ (x 3 ≥ (-1 : ℝ)) ∧ (x 3 ≤ (1 : ℝ)) ∧ (x 4 ≥ (-1 : ℝ)) ∧ (x 4 ≤ (1 : ℝ)) ∧ (x 5 ≥ (-1 : ℝ)) ∧ (x 5 ≤ (1 : ℝ)))}
def unsafeSet_739b738b38ae : Set (LeanBarrier.State 6) := {x | ((((x 0 < (-1 : ℝ))) ∨ ((x 0 > (1 : ℝ))) ∨ ((x 1 < (-1 : ℝ))) ∨ ((x 1 > (1 : ℝ))) ∨ ((x 2 < (-1 : ℝ))) ∨ ((x 2 > (1 : ℝ))) ∨ ((x 3 < (-1 : ℝ))) ∨ ((x 3 > (1 : ℝ))) ∨ ((x 4 < (-1 : ℝ))) ∨ ((x 4 > (1 : ℝ))) ∨ ((x 5 < (-1 : ℝ))) ∨ ((x 5 > (1 : ℝ)))))}

theorem verify_discrete_inductive_739b738b38ae (hV : ContDiff ℝ 1 barrier_739b738b38ae) : ¬ ∃ x : LeanBarrier.State 6, x ∈ workingSet_739b738b38ae ∧ barrier_739b738b38ae x ≥ 0 ∧ barrier_739b738b38ae (closedLoop_739b738b38ae x) < 0
