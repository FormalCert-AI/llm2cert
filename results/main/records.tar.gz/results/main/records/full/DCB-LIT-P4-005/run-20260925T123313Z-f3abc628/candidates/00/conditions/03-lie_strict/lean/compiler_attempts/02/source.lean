import LeanBarrier.GeneratedCache.Context_4018398c59a09bf0dcd8e17d19ace47faeda73ad2befeec47429c28824ce1b95

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_c7a97cd8c5f6 (hV : ContDiff ℝ 1 barrier_c7a97cd8c5f6) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_c7a97cd8c5f6 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_strict_c7a97cd8c5f6, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0l, hx0u, hx1l, hx1u, hx2l, hx2u, hzero, hderiv⟩
  ring_nf at hderiv
  have hpi : (157 : ℝ) / 50 < Real.pi := by
    nlinarith [Real.pi_gt_d20]
  have hxt : x 2 ∈ Set.Ioo (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> nlinarith
  have hcos : 0 < Real.cos (x 2) := Real.cos_pos_of_mem_Ioo hxt
  nlinarith

#print axioms verify_lie_strict_c7a97cd8c5f6

end LeanBarrier.Generated
