import LeanBarrier

#check Real.pi
#check Real.pi_gt_d20
#check Real.cos
#check Real.cos_pos_of_mem_Ioo
