import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c7a97cd8c5f6e5ef5b21251f98f2d974af953e00d433b005e2b6c2dd8b5569a5
noncomputable def barrier_c7a97cd8c5f6 (x : LeanBarrier.State 3) : ℝ := ((((-1 : ℝ) - x 2) - x 0) + (((3 : ℝ) / (2 : ℝ)) * Real.log (((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))) + (((1 : ℝ) / (10 : ℝ)) * x 1))
@[simp] theorem barrier_unfold_c7a97cd8c5f6 (x : LeanBarrier.State 3) : barrier_c7a97cd8c5f6 x = ((((-1 : ℝ) - x 2) - x 0) + (((3 : ℝ) / (2 : ℝ)) * Real.log (((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))) + (((1 : ℝ) / (10 : ℝ)) * x 1)) := by
  rfl
def violationSet_lie_strict_c7a97cd8c5f6 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-2 : ℝ)) ∧ (x 0 ≤ (2 : ℝ)) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ ((-157 : ℝ) / (100 : ℝ))) ∧ (x 2 ≤ ((157 : ℝ) / (100 : ℝ))) ∧ (((((-1 : ℝ) - x 2) - x 0) + (((3 : ℝ) / (2 : ℝ)) * Real.log (((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))) + (((1 : ℝ) / (10 : ℝ)) * x 1)) = (0 : ℝ)) ∧ (((((((3 : ℝ) / (2 : ℝ)) * (((2 : ℝ) * x 0) / ((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))) + (-1 : ℝ)) * Real.sin (x 2)) + (((((3 : ℝ) / (2 : ℝ)) * (((2 : ℝ) * x 1) / ((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))) + ((1 : ℝ) / (10 : ℝ))) * Real.cos (x 2)) + ((-1 : ℝ) * ((-Real.sin (x 2)) + (((3 : ℝ) * ((x 0 * Real.sin (x 2)) + (x 1 * Real.cos (x 2)))) / ((x 0 ^ 2) + (x 1 ^ 2) + ((1 : ℝ) / (2 : ℝ))))))) ≤ (0 : ℝ)))}
def unsafeSet_c7a97cd8c5f6 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ (-2 : ℝ)) ∧ (x 0 ≤ (2 : ℝ)) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ (2 : ℝ)) ∧ (x 2 ≥ ((-157 : ℝ) / (100 : ℝ))) ∧ (x 2 ≤ ((157 : ℝ) / (100 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((1 : ℝ) / (25 : ℝ))))}
def initialSet_c7a97cd8c5f6 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-1 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((1 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ (-2 : ℝ)) ∧ (x 1 ≤ ((-9 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-13 : ℝ) / (25 : ℝ))) ∧ (x 2 ≤ ((13 : ℝ) / (25 : ℝ))))}

#print axioms barrier_unfold_c7a97cd8c5f6

end LeanBarrier.Generated
