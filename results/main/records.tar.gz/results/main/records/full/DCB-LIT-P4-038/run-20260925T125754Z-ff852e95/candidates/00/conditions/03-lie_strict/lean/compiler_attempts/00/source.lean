import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 3176a882566db012fc624183511507303814c7f36529651be01a74da10995fab
noncomputable def barrier_3176a882566d (x : LeanBarrier.State 3) : ℝ := ((((10 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2))
@[simp] theorem barrier_unfold_3176a882566d (x : LeanBarrier.State 3) : barrier_3176a882566d x = ((((10 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) := by
  rfl
def violationSet_lie_strict_3176a882566d : Set (LeanBarrier.State 3) := {x | ((((((10 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-3 : ℝ) / (10 : ℝ)) * x 0) + (((1 : ℝ) / (5 : ℝ)) * Real.sin (x 1) * Real.exp ((-(x 2 ^ 2)))))) + ((-((2 : ℝ) * x 1)) * ((((-2 : ℝ) / (5 : ℝ)) * x 1) + (((3 : ℝ) / (20 : ℝ)) * Real.cos (x 0) * Real.exp ((-(x 0 ^ 2)))))) + ((-((2 : ℝ) * x 2)) * ((((-1 : ℝ) / (2 : ℝ)) * x 2) + (((1 : ℝ) / (10 : ℝ)) * Real.sin ((x 0 + x 1)))))) ≤ (0 : ℝ)))}
def unsafeSet_3176a882566d : Set (LeanBarrier.State 3) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≥ ((256 : ℝ) / (25 : ℝ))))}
def initialSet_3176a882566d : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-9 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((9 : ℝ) / (20 : ℝ))) ∧ (x 1 ≥ ((-9 : ℝ) / (20 : ℝ))) ∧ (x 1 ≤ ((9 : ℝ) / (20 : ℝ))) ∧ (x 2 ≥ ((-9 : ℝ) / (20 : ℝ))) ∧ (x 2 ≤ ((9 : ℝ) / (20 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2)) ≤ ((81 : ℝ) / (400 : ℝ))))}

#print axioms barrier_unfold_3176a882566d

end LeanBarrier.Generated
