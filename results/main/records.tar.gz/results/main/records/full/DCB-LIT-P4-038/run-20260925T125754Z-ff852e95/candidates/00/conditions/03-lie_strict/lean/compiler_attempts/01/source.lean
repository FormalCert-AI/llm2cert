import LeanBarrier

#check Real.sin
#check Real.exp
#check Real.cos
#check Real.abs_sin_le_one
#check Real.exp_pos
#check Real.exp_le_exp.mpr
#check Real.exp_zero
#check Real.abs_cos_le_one
