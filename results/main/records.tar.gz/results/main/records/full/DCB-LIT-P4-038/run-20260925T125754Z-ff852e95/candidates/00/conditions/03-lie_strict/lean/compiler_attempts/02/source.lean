import LeanBarrier.GeneratedCache.Context_79cc69b3d09cc992d496c63d1653185ab8c98cc00949d580a05159be720ffc13

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_3176a882566d (hV : ContDiff ℝ 1 barrier_3176a882566d) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_strict_3176a882566d := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_strict_3176a882566d, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hB, hL⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let c : ℝ := x 2
  let p : ℝ := Real.sin b * Real.exp (-(c ^ 2))
  let q : ℝ := Real.cos a * Real.exp (-(a ^ 2))
  let r : ℝ := Real.sin (a + b)
  have hsphere : a ^ 2 + b ^ 2 + c ^ 2 = 10 := by
    dsimp only [a, b, c]
    nlinarith [hB]
  have hsp_abs : |Real.sin b| ≤ (1 : ℝ) := Real.abs_sin_le_one b
  have hsp_lo : -(1 : ℝ) ≤ Real.sin b := (abs_le.mp hsp_abs).1
  have hsp_hi : Real.sin b ≤ (1 : ℝ) := (abs_le.mp hsp_abs).2
  have hep0 : 0 ≤ Real.exp (-(c ^ 2)) := (Real.exp_pos _).le
  have hep1 : Real.exp (-(c ^ 2)) ≤ 1 := by
    calc
      Real.exp (-(c ^ 2)) ≤ Real.exp 0 :=
        Real.exp_le_exp.mpr (by nlinarith [sq_nonneg c])
      _ = 1 := Real.exp_zero
  have hp_lo : -(1 : ℝ) ≤ p := by
    dsimp only [p]
    have hm := mul_le_mul_of_nonneg_right hsp_lo hep0
    nlinarith
  have hp_hi : p ≤ (1 : ℝ) := by
    dsimp only [p]
    have hm := mul_le_mul_of_nonneg_right hsp_hi hep0
    nlinarith
  have hcp_abs : |Real.cos a| ≤ (1 : ℝ) := Real.abs_cos_le_one a
  have hcp_lo : -(1 : ℝ) ≤ Real.cos a := (abs_le.mp hcp_abs).1
  have hcp_hi : Real.cos a ≤ (1 : ℝ) := (abs_le.mp hcp_abs).2
  have heq0 : 0 ≤ Real.exp (-(a ^ 2)) := (Real.exp_pos _).le
  have heq1 : Real.exp (-(a ^ 2)) ≤ 1 := by
    calc
      Real.exp (-(a ^ 2)) ≤ Real.exp 0 :=
        Real.exp_le_exp.mpr (by nlinarith [sq_nonneg a])
      _ = 1 := Real.exp_zero
  have hq_lo : -(1 : ℝ) ≤ q := by
    dsimp only [q]
    have hm := mul_le_mul_of_nonneg_right hcp_lo heq0
    nlinarith
  have hq_hi : q ≤ (1 : ℝ) := by
    dsimp only [q]
    have hm := mul_le_mul_of_nonneg_right hcp_hi heq0
    nlinarith
  have hr_abs : |Real.sin (a + b)| ≤ (1 : ℝ) := Real.abs_sin_le_one (a + b)
  have hr_lo : -(1 : ℝ) ≤ r := by
    dsimp only [r]
    exact (abs_le.mp hr_abs).1
  have hr_hi : r ≤ (1 : ℝ) := by
    dsimp only [r]
    exact (abs_le.mp hr_abs).2
  have hp_sq : p ^ 2 ≤ (1 : ℝ) := by
    have hleft : 0 ≤ 1 - p := by linarith
    have hright : 0 ≤ 1 + p := by linarith
    nlinarith [mul_nonneg hleft hright]
  have hq_sq : q ^ 2 ≤ (1 : ℝ) := by
    have hleft : 0 ≤ 1 - q := by linarith
    have hright : 0 ≤ 1 + q := by linarith
    nlinarith [mul_nonneg hleft hright]
  have hr_sq : r ^ 2 ≤ (1 : ℝ) := by
    have hleft : 0 ≤ 1 - r := by linarith
    have hright : 0 ≤ 1 + r := by linarith
    nlinarith [mul_nonneg hleft hright]
  have hyp : 2 * a * p ≤ a ^ 2 + 1 := by
    nlinarith [sq_nonneg (a - p), hp_sq]
  have hyq : 2 * b * q ≤ b ^ 2 + 1 := by
    nlinarith [sq_nonneg (b - q), hq_sq]
  have hyr : 2 * c * r ≤ c ^ 2 + 1 := by
    nlinarith [sq_nonneg (c - r), hr_sq]
  let ell : ℝ :=
    ((3 : ℝ) / 5) * a ^ 2 - ((2 : ℝ) / 5) * a * p
      + ((4 : ℝ) / 5) * b ^ 2 - ((3 : ℝ) / 10) * b * q
      + c ^ 2 - ((1 : ℝ) / 5) * c * r
  have hL' : ell ≤ 0 := by
    dsimp only [ell, a, b, c, p, q, r]
    ring_nf at hL ⊢
    exact hL
  have hell : 0 < ell := by
    dsimp only [ell]
    nlinarith [hyp, hyq, hyr, hsphere, sq_nonneg a, sq_nonneg b, sq_nonneg c]
  exact (not_lt_of_ge hL') hell

#print axioms verify_lie_strict_3176a882566d

end LeanBarrier.Generated
