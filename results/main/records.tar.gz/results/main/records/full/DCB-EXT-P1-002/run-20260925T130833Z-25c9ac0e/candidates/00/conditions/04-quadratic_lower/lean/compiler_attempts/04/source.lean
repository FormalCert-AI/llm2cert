import LeanBarrier.GeneratedCache.Context_0792df8c108fbac868dfcbcb0f4a94de996705541a8838aeab65729daa8cc0c7

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem abs_arctan_le_abs_b6deee9d2a9b (x : ℝ) : |Real.arctan x| ≤ |x| := by
  let f : ℝ → ℝ := fun y => y - Real.arctan y
  have hd (y : ℝ) : HasDerivAt f (1 - 1 / (1 + y ^ 2)) y := by
    simpa [f, one_div] using
      (hasDerivAt_id y).sub (Real.hasDerivAt_arctan y)
  have hfdiff : Differentiable ℝ f := fun y => (hd y).differentiableAt
  have hfderiv (y : ℝ) : 0 ≤ deriv f y := by
    rw [(hd y).deriv]
    have hden : 0 < 1 + y ^ 2 := by
      nlinarith [sq_nonneg y]
    have hfrac : (1 : ℝ) / (1 + y ^ 2) ≤ 1 := by
      apply (div_le_iff₀ hden).2
      nlinarith [sq_nonneg y]
    linarith
  have hmono : Monotone f := by
    apply monotone_of_deriv_nonneg
    all_goals
      first
      | exact hfdiff
      | exact hfdiff.continuous
      | exact hfderiv
  by_cases hx : 0 ≤ x
  · have hfx : f 0 ≤ f x := hmono hx
    have hupper : Real.arctan x ≤ x := by
      dsimp [f] at hfx
      simp at hfx
      linarith
    have hatnonneg : 0 ≤ Real.arctan x := Real.arctan_nonneg.mpr hx
    rw [abs_of_nonneg hatnonneg, abs_of_nonneg hx]
    exact hupper
  · have hxneg : x < 0 := lt_of_not_ge hx
    have hfx : f x ≤ f 0 := hmono (le_of_lt hxneg)
    have hlower : x ≤ Real.arctan x := by
      dsimp [f] at hfx
      simp at hfx
      linarith
    have hatnonpos : Real.arctan x ≤ 0 := by
      apply le_of_not_gt
      intro hatpos
      have hxnonneg : 0 ≤ x :=
        Real.arctan_nonneg.mp (le_of_lt hatpos)
      exact (not_le_of_gt hxneg) hxnonneg
    rw [abs_of_nonpos hatnonpos, abs_of_nonpos (le_of_lt hxneg)]
    linarith

#print axioms abs_arctan_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
