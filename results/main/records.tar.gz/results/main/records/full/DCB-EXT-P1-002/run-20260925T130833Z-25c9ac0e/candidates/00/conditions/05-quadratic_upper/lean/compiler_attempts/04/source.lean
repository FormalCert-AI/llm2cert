import LeanBarrier.GeneratedCache.Context_70195e136e88dffdb40cc7e0f32a3b2644f85caef52268d7bee1cc279db3edf5

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem abs_arctan_le_abs_b6deee9d2a9b (x : ℝ) : |Real.arctan x| ≤ |x| := by
  let f : ℝ → ℝ := fun y => y - Real.arctan y
  have hfderiv (y : ℝ) : HasDerivAt f (1 - 1 / (1 + y ^ 2)) y := by
    simpa [f] using (hasDerivAt_id y).sub (Real.hasDerivAt_arctan y)
  have hfdiff : Differentiable ℝ f := fun y => (hfderiv y).differentiableAt
  have hfmono : Monotone f := by
    apply monotone_of_deriv_nonneg hfdiff
    intro y
    rw [(hfderiv y).deriv]
    rw [sub_nonneg]
    apply (div_le_one (by nlinarith [sq_nonneg y])).2
    nlinarith [sq_nonneg y]
  have hnonneg_bound (y : ℝ) (hy : 0 ≤ y) : |Real.arctan y| ≤ |y| := by
    have hle : Real.arctan y ≤ y := by
      have h := hfmono hy
      simpa [f] using h
    rw [abs_of_nonneg ((Real.arctan_nonneg).2 hy), abs_of_nonneg hy]
    exact hle
  by_cases hx : 0 ≤ x
  · exact hnonneg_bound x hx
  · have hneg : 0 ≤ -x := by linarith
    have h := hnonneg_bound (-x) hneg
    simpa only [Real.arctan_neg, abs_neg] using h

#print axioms abs_arctan_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
