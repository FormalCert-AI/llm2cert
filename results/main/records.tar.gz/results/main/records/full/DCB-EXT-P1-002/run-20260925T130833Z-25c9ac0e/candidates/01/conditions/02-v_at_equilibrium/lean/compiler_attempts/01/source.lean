import LeanBarrier.GeneratedCache.Context_822201fc5a045a5325ecda3a26dfe8d951e1ff4cae56ef201a106463bc1d6cd4

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_33b7f823b870 (hV : ContDiff ℝ 1 barrier_33b7f823b870) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_33b7f823b870 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  simp [hx0, hx1] at hbad

#print axioms verify_v_at_equilibrium_33b7f823b870

end LeanBarrier.Generated
