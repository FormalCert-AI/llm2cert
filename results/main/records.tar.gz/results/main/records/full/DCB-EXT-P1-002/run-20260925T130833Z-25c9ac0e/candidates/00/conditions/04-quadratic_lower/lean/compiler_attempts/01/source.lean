import LeanBarrier

#check Real.arctan
#check Real.abs_arctan_le_abs
