import LeanBarrier.GeneratedCache.Context_8a74f0970cf2f3f9ad6a933718b13147ec5a60ccb4246d3cff0d3ce726ef8ba0

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem abs_arctan_le_abs_b6deee9d2a9b (x : ℝ) : |Real.arctan x| ≤ |x| := by
  have hcont : Continuous Real.arctan :=
    continuous_iff_continuousAt.2 fun z =>
      (Real.hasDerivAt_arctan z).continuousAt
  have hderiv (z : ℝ) : ‖deriv Real.arctan z‖ ≤ (1 : ℝ) := by
    rw [(Real.hasDerivAt_arctan z).deriv, norm_eq_abs,
      abs_of_nonneg (by positivity)]
    change 1 / (1 + z ^ 2) ≤ 1
    have hd : 0 < 1 + z ^ 2 := by positivity
    exact (div_le_one hd).2 (by nlinarith [sq_nonneg z])
  have h :=
    convex_univ.norm_image_sub_le_of_norm_deriv_le hcont.continuousOn
      (fun z _ => hderiv z) (Set.mem_univ x) (Set.mem_univ (0 : ℝ))
  simpa [norm_eq_abs] using h

#print axioms abs_arctan_le_abs_b6deee9d2a9b

end LeanBarrier.Generated
