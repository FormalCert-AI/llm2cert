import LeanBarrier.GeneratedCache.Context_c948d97bc86b6b44261b82af457004c18d605d02adacaf48c750812b5a81d193

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_exponential_decay_33b7f823b870 (hV : ContDiff ℝ 1 barrier_33b7f823b870) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_exponential_decay_33b7f823b870 := by
  rintro ⟨x, hx⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let d : ℝ := a ^ 2 + 1
  let q : ℝ := (1 + 2 * a ^ 2 - (a ^ 2) ^ 2) / d ^ 2
  change
    ((2 * a +
          (((1 / 4 : ℝ) * b * (a ^ 2 + 1) -
              (1 / 2 : ℝ) * a * b * a) /
            (a ^ 2 + 1) ^ 2)) * (-(a ^ 3) + b) +
      (2 * b +
          ((1 / 4 : ℝ) * a * (a ^ 2 + 1) /
            (a ^ 2 + 1) ^ 2)) * (-a - b) +
      (1 / 9 : ℝ) *
        (a ^ 2 + b ^ 2 +
          ((1 / 4 : ℝ) * a * b) / (a ^ 2 + 1))) > 0 at hx
  have had0 : a ^ 2 + 1 ≠ 0 := by
    nlinarith [sq_nonneg a]
  have hd : 0 < d := by
    dsimp [d]
    nlinarith [sq_nonneg a]
  have hd2 : 0 < d ^ 2 := by positivity
  have hdge : 1 ≤ d := by
    dsimp [d]
    nlinarith [sq_nonneg a]
  have hx' :
      (-2 * (a ^ 2) ^ 2 - 2 * b ^ 2 +
          (1 / 4 : ℝ) * (1 - a ^ 2) * b ^ 2 / d ^ 2 -
          (1 / 4 : ℝ) * a ^ 2 / d -
          (1 / 4 : ℝ) * a * q * b +
          (1 / 9 : ℝ) *
            (a ^ 2 + b ^ 2 + (1 / 4 : ℝ) * a * b / d)) > 0 := by
    convert hx using 1 <;>
      dsimp [d, q] <;>
      field_simp [had0] <;>
      ring
  have hqU : q ≤ 1 := by
    change (1 + 2 * a ^ 2 - (a ^ 2) ^ 2) / d ^ 2 ≤ 1
    rw [div_le_iff₀ hd2]
    dsimp [d]
    nlinarith [sq_nonneg (a ^ 2)]
  have hqL : -1 ≤ q := by
    change -1 ≤ (1 + 2 * a ^ 2 - (a ^ 2) ^ 2) / d ^ 2
    rw [le_div_iff₀ hd2]
    dsimp [d]
    nlinarith [sq_nonneg a]
  have hqSq : q ^ 2 ≤ 1 := by
    have hp : 0 ≤ (1 - q) * (1 + q) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith
  have hqb : q ^ 2 * b ^ 2 ≤ b ^ 2 := by
    simpa using mul_le_mul_of_nonneg_right hqSq (sq_nonneg b)
  have hcross : -(a * q * b) ≤ (a ^ 2 + b ^ 2) / 2 := by
    nlinarith [sq_nonneg (a + q * b), hqb]
  have hr : (1 - a ^ 2) / d ^ 2 ≤ 1 := by
    rw [div_le_iff₀ hd2]
    dsimp [d]
    nlinarith [sq_nonneg a, sq_nonneg (a ^ 2)]
  have hrb : ((1 - a ^ 2) / d ^ 2) * b ^ 2 ≤ b ^ 2 := by
    simpa using mul_le_mul_of_nonneg_right hr (sq_nonneg b)
  have h4d : 0 < 4 * d := by positivity
  have hinv : (1 : ℝ) / (4 * d) ≤ 1 / 4 := by
    rw [div_le_iff₀ h4d]
    nlinarith [hdge]
  have hcoef : -2 + (1 : ℝ) / (4 * d) ≤ 0 := by
    linarith [hinv]
  have hprod :
      (a ^ 2) ^ 2 * (-2 + (1 : ℝ) / (4 * d)) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (a ^ 2)) hcoef
  have hident :
      -2 * (a ^ 2) ^ 2 - (1 / 4 : ℝ) * a ^ 2 / d +
          (1 / 4 : ℝ) * a ^ 2 =
        (a ^ 2) ^ 2 * (-2 + (1 : ℝ) / (4 * d)) := by
    dsimp [d]
    field_simp [had0]
    ring
  have hcore :
      -2 * (a ^ 2) ^ 2 - (1 / 4 : ℝ) * a ^ 2 / d +
          (1 / 8 : ℝ) * a ^ 2 ≤
        -(1 / 8 : ℝ) * a ^ 2 := by
    nlinarith [hident, hprod]
  have hterm :
      (1 / 4 : ℝ) * (1 - a ^ 2) * b ^ 2 / d ^ 2 ≤
        (1 / 4 : ℝ) * b ^ 2 := by
    calc
      (1 / 4 : ℝ) * (1 - a ^ 2) * b ^ 2 / d ^ 2 =
          (1 / 4 : ℝ) * (((1 - a ^ 2) / d ^ 2) * b ^ 2) := by ring
      _ ≤ (1 / 4 : ℝ) * b ^ 2 := by nlinarith [hrb]
  have hqterm :
      -(1 / 4 : ℝ) * a * q * b ≤
        (1 / 8 : ℝ) * (a ^ 2 + b ^ 2) := by
    nlinarith [hcross]
  have hLie :
      -2 * (a ^ 2) ^ 2 - 2 * b ^ 2 +
          (1 / 4 : ℝ) * (1 - a ^ 2) * b ^ 2 / d ^ 2 -
          (1 / 4 : ℝ) * a ^ 2 / d -
          (1 / 4 : ℝ) * a * q * b ≤
        -(1 / 8 : ℝ) * a ^ 2 - (13 / 8 : ℝ) * b ^ 2 := by
    nlinarith [hterm, hqterm, hcore]
  have hab : a * b ≤ (a ^ 2 + b ^ 2) / 2 := by
    nlinarith [sq_nonneg (a - b)]
  have hsum : 0 ≤ (a ^ 2 + b ^ 2) / 2 := by positivity
  have hscale :
      (a ^ 2 + b ^ 2) / 2 ≤ d * ((a ^ 2 + b ^ 2) / 2) := by
    have ht := mul_le_mul_of_nonneg_right hdge hsum
    nlinarith [ht]
  have habd : a * b / d ≤ (a ^ 2 + b ^ 2) / 2 := by
    rw [div_le_iff₀ hd]
    nlinarith [hab, hscale]
  have hVb :
      a ^ 2 + b ^ 2 + (1 / 4 : ℝ) * a * b / d ≤
        (9 / 8 : ℝ) * (a ^ 2 + b ^ 2) := by
    nlinarith [habd]
  nlinarith [hx', hLie, hVb, sq_nonneg b]

#print axioms verify_exponential_decay_33b7f823b870

end LeanBarrier.Generated
