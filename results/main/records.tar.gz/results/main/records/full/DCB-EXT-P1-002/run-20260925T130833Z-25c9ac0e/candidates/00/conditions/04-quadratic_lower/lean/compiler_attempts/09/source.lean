import LeanBarrier.GeneratedCache.Helper_76d1c5a567b4222c04566ac12ed4b057e044bb837c8424a4b8edcaa66902ee43

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_quadratic_lower_b6deee9d2a9b (hV : ContDiff ℝ 1 barrier_b6deee9d2a9b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_quadratic_lower_b6deee9d2a9b := by
  rintro ⟨x, hx⟩
  change
    x 0 ^ 2 + x 1 ^ 2 + ((1 : ℝ) / 4) * Real.arctan (x 0) * x 1 <
      ((7 : ℝ) / 8) * (x 0 ^ 2 + x 1 ^ 2) at hx
  have hat : |Real.arctan (x 0)| ≤ |x 0| :=
    abs_arctan_le_abs_b6deee9d2a9b (x 0)
  have habs_sq (r : ℝ) : |r| ^ 2 = r ^ 2 := by
    rw [pow_two, ← abs_mul, abs_of_nonneg (mul_self_nonneg r)]
    ring
  have ht_sq : Real.arctan (x 0) ^ 2 ≤ x 0 ^ 2 := by
    calc
      Real.arctan (x 0) ^ 2 = |Real.arctan (x 0)| ^ 2 :=
        (habs_sq (Real.arctan (x 0))).symm
      _ ≤ |x 0| ^ 2 := by
        have hp :
            0 ≤ (|x 0| - |Real.arctan (x 0)|) *
              (|x 0| + |Real.arctan (x 0)|) :=
          mul_nonneg (sub_nonneg.mpr hat)
            (add_nonneg (abs_nonneg _) (abs_nonneg _))
        nlinarith
      _ = x 0 ^ 2 := habs_sq (x 0)
  have hcross :
      -((1 : ℝ) / 8) * (x 0 ^ 2 + x 1 ^ 2) ≤
        ((1 : ℝ) / 4) * Real.arctan (x 0) * x 1 := by
    nlinarith [sq_nonneg (Real.arctan (x 0) + x 1)]
  nlinarith

#print axioms verify_quadratic_lower_b6deee9d2a9b

end LeanBarrier.Generated
