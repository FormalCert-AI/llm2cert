import LeanBarrier.GeneratedCache.Helper_4447a3051db1d7a1f9ee15af2723e8459e3aa83df8e918b35028c7053072cc9a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_quadratic_upper_b6deee9d2a9b (hV : ContDiff ℝ 1 barrier_b6deee9d2a9b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_quadratic_upper_b6deee9d2a9b := by
  rintro ⟨x, hx⟩
  change
    x 0 ^ 2 + x 1 ^ 2 + (1 / 4) * Real.arctan (x 0) * x 1 >
      (9 / 8) * (x 0 ^ 2 + x 1 ^ 2) at hx
  have hatan : |Real.arctan (x 0)| ≤ |x 0| :=
    abs_arctan_le_abs_b6deee9d2a9b (x 0)
  have hmul : |Real.arctan (x 0)| * |x 1| ≤ |x 0| * |x 1| :=
    mul_le_mul_of_nonneg_right hatan (abs_nonneg (x 1))
  have ha_sq : |x 0| ^ 2 = x 0 ^ 2 := by
    rw [← abs_pow, abs_of_nonneg (sq_nonneg (x 0))]
  have hb_sq : |x 1| ^ 2 = x 1 ^ 2 := by
    rw [← abs_pow, abs_of_nonneg (sq_nonneg (x 1))]
  have hprod :
      |Real.arctan (x 0)| * |x 1| ≤ (x 0 ^ 2 + x 1 ^ 2) / 2 := by
    nlinarith [sq_nonneg (|x 0| - |x 1|)]
  have hcross :
      Real.arctan (x 0) * x 1 ≤ (x 0 ^ 2 + x 1 ^ 2) / 2 := by
    calc
      Real.arctan (x 0) * x 1 ≤ |Real.arctan (x 0) * x 1| :=
        le_abs_self _
      _ = |Real.arctan (x 0)| * |x 1| := abs_mul _ _
      _ ≤ (x 0 ^ 2 + x 1 ^ 2) / 2 := hprod
  nlinarith

#print axioms verify_quadratic_upper_b6deee9d2a9b

end LeanBarrier.Generated
