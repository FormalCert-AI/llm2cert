import LeanBarrier

#check Real.abs_arctan_le_abs
