import LeanBarrier

#check Real.hasDerivAt_arctan
