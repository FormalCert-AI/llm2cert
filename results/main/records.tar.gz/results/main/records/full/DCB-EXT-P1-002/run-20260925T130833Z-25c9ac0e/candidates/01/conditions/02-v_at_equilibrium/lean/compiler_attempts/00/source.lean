import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 33b7f823b870a712007d70ab0009e28ba01339a9cfb0fb0c27411735bda8428d
noncomputable def barrier_33b7f823b870 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 1 ^ 2) + ((((1 : ℝ) / (4 : ℝ)) * x 0 * x 1) / ((x 0 ^ 2) + (1 : ℝ))))
@[simp] theorem barrier_unfold_33b7f823b870 (x : LeanBarrier.State 2) : barrier_33b7f823b870 x = ((x 0 ^ 2) + (x 1 ^ 2) + ((((1 : ℝ) / (4 : ℝ)) * x 0 * x 1) / ((x 0 ^ 2) + (1 : ℝ)))) := by
  rfl
def violationSet_v_at_equilibrium_33b7f823b870 : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((x 0 ^ 2) + (x 1 ^ 2) + ((((1 : ℝ) / (4 : ℝ)) * x 0 * x 1) / ((x 0 ^ 2) + (1 : ℝ)))) > (0 : ℝ))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2) + ((((1 : ℝ) / (4 : ℝ)) * x 0 * x 1) / ((x 0 ^ 2) + (1 : ℝ)))) < (0 : ℝ)))))}

#print axioms barrier_unfold_33b7f823b870

end LeanBarrier.Generated
