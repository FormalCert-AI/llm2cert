import LeanBarrier

#check Real.arctan_nonneg
#check Real.arctan_le_self
#check Real.arctan_neg
