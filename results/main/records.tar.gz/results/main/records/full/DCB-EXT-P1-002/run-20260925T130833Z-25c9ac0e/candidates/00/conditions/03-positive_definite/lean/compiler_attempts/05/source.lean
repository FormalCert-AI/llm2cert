import LeanBarrier.GeneratedCache.Helper_fc96dea8e9b404d7f625eaad0659674e4c8870c19855ec49775f82007fa8dc78

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_b6deee9d2a9b (hV : ContDiff ℝ 1 barrier_b6deee9d2a9b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_b6deee9d2a9b := by
  rintro ⟨x, hx⟩
  change
    (x 0 ^ 2 + x 1 ^ 2 > (0 : ℝ)) ∧
      (x 0 ^ 2 + x 1 ^ 2 +
          ((1 : ℝ) / 4 * Real.arctan (x 0) * x 1) ≤ 0) at hx
  rcases hx with ⟨hpos, hnonpos⟩
  have hatan : |Real.arctan (x 0)| ≤ |x 0| :=
    abs_arctan_le_abs_b6deee9d2a9b (x 0)
  have hprodabs :
      |Real.arctan (x 0) * x 1| ≤ |x 0| * |x 1| := by
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_right hatan (abs_nonneg (x 1))
  have habs0 : |x 0| ^ 2 = (x 0) ^ 2 := by
    by_cases h0 : 0 ≤ x 0
    · rw [abs_of_nonneg h0]
    · have h0' : x 0 ≤ 0 := le_of_not_ge h0
      rw [abs_of_nonpos h0']
      ring
  have habs1 : |x 1| ^ 2 = (x 1) ^ 2 := by
    by_cases h1 : 0 ≤ x 1
    · rw [abs_of_nonneg h1]
    · have h1' : x 1 ≤ 0 := le_of_not_ge h1
      rw [abs_of_nonpos h1']
      ring
  have hyoung :
      2 * (|x 0| * |x 1|) ≤ (x 0) ^ 2 + (x 1) ^ 2 := by
    nlinarith [sq_nonneg (|x 0| - |x 1|), habs0, habs1]
  have hcross :
      -((x 0) ^ 2 + (x 1) ^ 2) / 2 ≤
        Real.arctan (x 0) * x 1 := by
    have hneg := neg_abs_le (Real.arctan (x 0) * x 1)
    linarith
  nlinarith

#print axioms verify_positive_definite_b6deee9d2a9b

end LeanBarrier.Generated
