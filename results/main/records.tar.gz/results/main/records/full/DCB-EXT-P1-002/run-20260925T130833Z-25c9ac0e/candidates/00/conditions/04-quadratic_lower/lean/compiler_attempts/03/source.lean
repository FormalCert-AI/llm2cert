import LeanBarrier

#check Real.arctan_nonneg.mp
