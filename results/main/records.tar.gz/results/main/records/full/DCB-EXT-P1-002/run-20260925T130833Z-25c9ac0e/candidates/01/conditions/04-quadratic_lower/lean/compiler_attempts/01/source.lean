import LeanBarrier.GeneratedCache.Context_8edc9b8a4e9010df52907507e44480d320a961265c7238b0a0577d847888724b

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_quadratic_lower_33b7f823b870 (hV : ContDiff ℝ 1 barrier_33b7f823b870) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_quadratic_lower_33b7f823b870 := by
  rintro ⟨x, hx⟩
  change
    x 0 ^ 2 + x 1 ^ 2 +
        ((1 / 4 : ℝ) * x 0 * x 1) / (x 0 ^ 2 + 1) <
      (7 / 8 : ℝ) * (x 0 ^ 2 + x 1 ^ 2) at hx
  have hd : 0 < x 0 ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 0)]
  have hfrac :
      ((1 / 4 : ℝ) * x 0 * x 1) / (x 0 ^ 2 + 1) <
        -(1 / 8 : ℝ) * (x 0 ^ 2 + x 1 ^ 2) := by
    nlinarith [hx]
  have hmul :
      (1 / 4 : ℝ) * x 0 * x 1 <
        (-(1 / 8 : ℝ) * (x 0 ^ 2 + x 1 ^ 2)) * (x 0 ^ 2 + 1) :=
    (div_lt_iff₀ hd).mp hfrac
  have hp :
      0 ≤ x 0 ^ 2 * (x 0 ^ 2 + x 1 ^ 2) :=
    mul_nonneg (sq_nonneg (x 0))
      (add_nonneg (sq_nonneg (x 0)) (sq_nonneg (x 1)))
  have hsq : 0 ≤ (x 0 + x 1) ^ 2 := sq_nonneg (x 0 + x 1)
  nlinarith [hmul, hp, hsq]

#print axioms verify_quadratic_lower_33b7f823b870

end LeanBarrier.Generated
