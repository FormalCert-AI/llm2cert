import LeanBarrier

#check Real.arctan_zero
