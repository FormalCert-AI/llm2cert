import LeanBarrier.GeneratedCache.Context_6d793df041024a1bc57c540d6163602af70be303f117648f6e81b23edbd7c280

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_b6deee9d2a9b (hV : ContDiff ℝ 1 barrier_b6deee9d2a9b) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_b6deee9d2a9b := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_b6deee9d2a9b, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0, hx1, hbad⟩
  norm_num [hx0, hx1, Real.arctan_zero] at hbad

#print axioms verify_v_at_equilibrium_b6deee9d2a9b

end LeanBarrier.Generated
