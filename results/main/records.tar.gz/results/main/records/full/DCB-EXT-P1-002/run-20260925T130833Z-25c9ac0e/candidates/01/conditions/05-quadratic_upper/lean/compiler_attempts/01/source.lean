import LeanBarrier.GeneratedCache.Context_04aa787fd6617623d2f1e1f39a896e53b3e23203511dac44c880b08d9d5bb81d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_quadratic_upper_33b7f823b870 (hV : ContDiff ℝ 1 barrier_33b7f823b870) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_quadratic_upper_33b7f823b870 := by
  rintro ⟨x, hx⟩
  change
    x 0 ^ 2 + x 1 ^ 2 +
          ((1 / 4 : ℝ) * x 0 * x 1 / (x 0 ^ 2 + 1)) >
        (9 / 8 : ℝ) * (x 0 ^ 2 + x 1 ^ 2)
    at hx
  have hd : 0 < x 0 ^ 2 + 1 := by
    nlinarith [sq_nonneg (x 0)]
  have hsum : 0 ≤ x 0 ^ 2 + x 1 ^ 2 := by
    nlinarith [sq_nonneg (x 0), sq_nonneg (x 1)]
  have hmore :
      0 ≤ (x 0 ^ 2 + x 1 ^ 2) * ((x 0 ^ 2 + 1) - 1) := by
    apply mul_nonneg hsum
    nlinarith [sq_nonneg (x 0)]
  have hcross :
      (1 / 4 : ℝ) * x 0 * x 1 / (x 0 ^ 2 + 1) ≤
        (1 / 8 : ℝ) * (x 0 ^ 2 + x 1 ^ 2) := by
    apply (div_le_iff₀ hd).2
    nlinarith [sq_nonneg (x 0 - x 1), hmore]
  nlinarith [hcross]

#print axioms verify_quadratic_upper_33b7f823b870

end LeanBarrier.Generated
