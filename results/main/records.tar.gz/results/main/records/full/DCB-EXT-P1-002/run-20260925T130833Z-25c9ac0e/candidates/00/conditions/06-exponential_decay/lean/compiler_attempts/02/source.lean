import LeanBarrier

#check Real.strictMono_arctan
#check Real.arctan_le_self
