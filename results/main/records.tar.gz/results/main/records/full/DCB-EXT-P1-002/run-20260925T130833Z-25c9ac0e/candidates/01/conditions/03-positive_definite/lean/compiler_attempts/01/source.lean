import LeanBarrier.GeneratedCache.Context_d3d243238bb62eaf45272410b1ddce21f192391e853f211a97e4f49716f56298

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_33b7f823b870 (hV : ContDiff ℝ 1 barrier_33b7f823b870) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_33b7f823b870 := by
  rintro ⟨x, hx⟩
  let a : ℝ := x 0
  let b : ℝ := x 1
  let s : ℝ := a ^ 2 + b ^ 2
  let d : ℝ := a ^ 2 + 1
  change s > 0 ∧ s + ((((1 : ℝ) / 4) * a * b) / d) ≤ 0 at hx
  rcases hx with ⟨hspos, hnonpos⟩
  have hs : 0 ≤ s := by
    dsimp [s]
    positivity
  have hd : 0 < d := by
    dsimp [d]
    nlinarith [sq_nonneg a]
  have hbase : 0 ≤ s + 2 * a * b := by
    dsimp [s]
    nlinarith [sq_nonneg (a + b)]
  have hprod : 0 ≤ s * a ^ 2 := mul_nonneg hs (sq_nonneg a)
  have hab : -(s / 2) * d ≤ a * b := by
    dsimp [d]
    nlinarith [hbase, hprod]
  have hcross : -(s / 8) ≤ (((1 : ℝ) / 4) * a * b) / d := by
    apply (le_div_iff₀ hd).2
    nlinarith [hab]
  nlinarith

#print axioms verify_positive_definite_33b7f823b870

end LeanBarrier.Generated
