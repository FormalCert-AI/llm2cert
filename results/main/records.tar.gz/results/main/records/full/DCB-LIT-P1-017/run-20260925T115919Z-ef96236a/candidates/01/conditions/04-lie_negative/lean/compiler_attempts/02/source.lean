import LeanBarrier.GeneratedCache.Context_234204bbce8a7ff65957c71048a03cbe83eab8f0a1ae8a15726e631aaceed476

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_c6ceabff07cb (hV : ContDiff ℝ 1 barrier_c6ceabff07cb) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_lie_negative_c6ceabff07cb := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_c6ceabff07cb, Set.mem_setOf_eq] at hx
  rcases hx with
    ⟨h0l, h0u, h1l, h1u, h2l, h2u, h3l, h3u, h4l, h4u, h5l, h5u, hpos, hder⟩
  have hsabs : |Real.sin (x 1)| ≤ (1 : ℝ) :=
    abs_le.mpr ⟨Real.neg_one_le_sin (x 1), Real.sin_le_one (x 1)⟩
  have hcabs : |Real.cos (x 3)| ≤ (1 : ℝ) :=
    abs_le.mpr ⟨Real.neg_one_le_cos (x 3), Real.cos_le_one (x 3)⟩
  have hscabs : |Real.sin (x 1) * Real.cos (x 3)| ≤ (1 : ℝ) := by
    rw [abs_mul]
    calc
      |Real.sin (x 1)| * |Real.cos (x 3)| ≤ (1 : ℝ) * 1 :=
        mul_le_mul hsabs hcabs (abs_nonneg _) (by norm_num)
      _ = 1 := by norm_num
  have hscl : (-1 : ℝ) ≤ Real.sin (x 1) * Real.cos (x 3) :=
    (abs_le.mp hscabs).1
  have hscu : Real.sin (x 1) * Real.cos (x 3) ≤ (1 : ℝ) :=
    (abs_le.mp hscabs).2
  let a : ℝ :=
    ((3 : ℝ) / 2) * x 5 + ((1 : ℝ) / 2) * Real.sin (x 1) * Real.cos (x 3)
  have hal : (-5 : ℝ) ≤ a := by
    dsimp [a]
    nlinarith
  have hau : a ≤ (5 : ℝ) := by
    dsimp [a]
    nlinarith
  have bounded_cross :
      ∀ (b u v : ℝ), (-5 : ℝ) ≤ b → b ≤ 5 →
        b * (u * v) ≤ ((1 : ℝ) / 2) * u ^ 2 + ((25 : ℝ) / 2) * v ^ 2 := by
    intro b u v hbl hbu
    by_cases hz : 0 ≤ u * v
    · have hm : b * (u * v) ≤ 5 * (u * v) := by
        have hn : 0 ≤ (5 - b) * (u * v) := mul_nonneg (by linarith) hz
        nlinarith
      have hy : 5 * (u * v) ≤ ((1 : ℝ) / 2) * u ^ 2 + ((25 : ℝ) / 2) * v ^ 2 := by
        nlinarith [sq_nonneg (u - 5 * v)]
      linarith
    · have hz' : u * v ≤ 0 := le_of_not_ge hz
      have hn : 0 ≤ (b + 5) * (-(u * v)) :=
        mul_nonneg (by linarith) (by linarith)
      have hm : b * (u * v) ≤ -5 * (u * v) := by
        nlinarith
      have hy : -5 * (u * v) ≤ ((1 : ℝ) / 2) * u ^ 2 + ((25 : ℝ) / 2) * v ^ 2 := by
        nlinarith [sq_nonneg (u + 5 * v)]
      linarith
  have hna_l : (-5 : ℝ) ≤ -a := by linarith
  have hna_u : -a ≤ (5 : ℝ) := by linarith
  have hg1 := bounded_cross a (x 2) (x 1) hal hau
  have hg2 := bounded_cross (-a) (x 0) (x 3) hna_l hna_u
  have hgyro :
      a * (x 2 * x 1 - x 0 * x 3) ≤
        ((1 : ℝ) / 2) * (x 2) ^ 2 + ((25 : ℝ) / 2) * (x 1) ^ 2 +
        ((1 : ℝ) / 2) * (x 0) ^ 2 + ((25 : ℝ) / 2) * (x 3) ^ 2 := by
    nlinarith [hg1, hg2]
  have hy01 :
      -(((5 : ℝ) / 2) * x 0 * x 1) ≤
        ((1 : ℝ) / 2) * (x 0) ^ 2 + ((25 : ℝ) / 8) * (x 1) ^ 2 := by
    nlinarith [sq_nonneg (x 0 + ((5 : ℝ) / 2) * x 1)]
  have hy23 :
      -((10 : ℝ) * x 2 * x 3) ≤
        ((1 : ℝ) / 2) * (x 2) ^ 2 + (50 : ℝ) * (x 3) ^ 2 := by
    nlinarith [sq_nonneg (x 2 + 10 * x 3)]
  have hy45 :
      -(((4 : ℝ) / 5) * x 4 * x 5) ≤
        ((1 : ℝ) / 2) * (x 4) ^ 2 + ((8 : ℝ) / 25) * (x 5) ^ 2 := by
    nlinarith [sq_nonneg (x 4 + ((4 : ℝ) / 5) * x 5)]
  dsimp [a] at hgyro
  have hnonpos :
      ((1 : ℝ) / 100) * (x 0) ^ 2 +
        ((3867 : ℝ) / 800) * (x 1) ^ 2 +
        ((1 : ℝ) / 100) * (x 2) ^ 2 +
        ((3873 : ℝ) / 200) * (x 3) ^ 2 +
        ((9 : ℝ) / 200) * (x 4) ^ 2 +
        ((3967 : ℝ) / 2500) * (x 5) ^ 2 ≤ 0 := by
    nlinarith only [hder, hy01, hy23, hy45, hgyro]
  nlinarith only [hpos, hnonpos, sq_nonneg (x 0), sq_nonneg (x 1),
    sq_nonneg (x 2), sq_nonneg (x 3), sq_nonneg (x 4), sq_nonneg (x 5)]

#print axioms verify_lie_negative_c6ceabff07cb

end LeanBarrier.Generated
