import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: c6ceabff07cb68829a659fcaebaad331b79225adcc64a997288648b27bb37f6a
noncomputable def barrier_c6ceabff07cb (x : LeanBarrier.State 6) : ℝ := (((2 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2) + ((2 : ℝ) * (x 2 ^ 2)) + (x 3 ^ 2) + ((5 : ℝ) * (x 4 ^ 2)) + (x 5 ^ 2) + (((1 : ℝ) / (100 : ℝ)) * ((x 0 * x 1) + (x 2 * x 3) + (x 4 * x 5))))
@[simp] theorem barrier_unfold_c6ceabff07cb (x : LeanBarrier.State 6) : barrier_c6ceabff07cb x = (((2 : ℝ) * (x 0 ^ 2)) + (x 1 ^ 2) + ((2 : ℝ) * (x 2 ^ 2)) + (x 3 ^ 2) + ((5 : ℝ) * (x 4 ^ 2)) + (x 5 ^ 2) + (((1 : ℝ) / (100 : ℝ)) * ((x 0 * x 1) + (x 2 * x 3) + (x 4 * x 5)))) := by
  rfl
def violationSet_equilibrium_fixed_c6ceabff07cb : Set (LeanBarrier.State 6) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (x 2 = (0 : ℝ)) ∧ (x 3 = (0 : ℝ)) ∧ (x 4 = (0 : ℝ)) ∧ (x 5 = (0 : ℝ)) ∧ (((x 1 > (0 : ℝ))) ∨ ((x 1 < (0 : ℝ))) ∨ ((((((((-3 : ℝ) / (2 : ℝ)) * x 5 * x 3) - ((2 : ℝ) * x 0)) - (((5 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (2 : ℝ)) * x 3 * Real.sin (x 1) * Real.cos (x 3))) > (0 : ℝ))) ∨ ((((((((-3 : ℝ) / (2 : ℝ)) * x 5 * x 3) - ((2 : ℝ) * x 0)) - (((5 : ℝ) / (2 : ℝ)) * x 1)) - (((1 : ℝ) / (2 : ℝ)) * x 3 * Real.sin (x 1) * Real.cos (x 3))) < (0 : ℝ))) ∨ ((x 3 > (0 : ℝ))) ∨ ((x 3 < (0 : ℝ))) ∨ ((((((((3 : ℝ) / (2 : ℝ)) * x 5 * x 1) - ((2 : ℝ) * x 2)) - ((10 : ℝ) * x 3)) + (((1 : ℝ) / (2 : ℝ)) * x 1 * Real.sin (x 1) * Real.cos (x 3))) > (0 : ℝ))) ∨ ((((((((3 : ℝ) / (2 : ℝ)) * x 5 * x 1) - ((2 : ℝ) * x 2)) - ((10 : ℝ) * x 3)) + (((1 : ℝ) / (2 : ℝ)) * x 1 * Real.sin (x 1) * Real.cos (x 3))) < (0 : ℝ))) ∨ ((x 5 > (0 : ℝ))) ∨ ((x 5 < (0 : ℝ))) ∨ (((((-5 : ℝ) * x 4) - (((4 : ℝ) / (5 : ℝ)) * x 5)) > (0 : ℝ))) ∨ (((((-5 : ℝ) * x 4) - (((4 : ℝ) / (5 : ℝ)) * x 5)) < (0 : ℝ)))))}

#print axioms barrier_unfold_c6ceabff07cb

end LeanBarrier.Generated
