import LeanBarrier.GeneratedCache.Context_80db4c8d6f75b19561566b0297ed08d4256eb024564f2cbce4deb622445606f8

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_c6ceabff07cb (hV : ContDiff ℝ 1 barrier_c6ceabff07cb) : ¬ ∃ x : LeanBarrier.State 6, x ∈ violationSet_equilibrium_fixed_c6ceabff07cb := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx2, hx3, hx4, hx5, hbad⟩
  norm_num [hx0, hx1, hx2, hx3, hx4, hx5] at hbad

#print axioms verify_equilibrium_fixed_c6ceabff07cb

end LeanBarrier.Generated
