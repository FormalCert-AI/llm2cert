-- candidate-sha256: db77ef4618539491ce0ef785b71c9ffc480a46325215c39e50bf76b3b7ba94e1
noncomputable def barrier_db77ef461853 (x : LeanBarrier.State 2) : ℝ := (Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))
@[simp] theorem barrier_unfold_db77ef461853 (x : LeanBarrier.State 2) : barrier_db77ef461853 x = (Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) := by
  rfl
def violationSet_lie_strict_db77ef461853 : Set (LeanBarrier.State 2) := {x | (((Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) = (0 : ℝ)) ∧ ((((((((2 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) + (Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))) * ((-1 : ℝ) - (((2 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))))) * x 1) + ((((((2 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) + (Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))) * ((-1 : ℝ) - (((2 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))))) * x 0)) ≤ (0 : ℝ)))}
def unsafeSet_db77ef461853 : Set (LeanBarrier.State 2) := {x | ((x 0 > (0 : ℝ)))}
def initialSet_db77ef461853 : Set (LeanBarrier.State 2) := {x | ((x 0 ≤ (0 : ℝ)) ∧ (x 1 ≤ (0 : ℝ)))}

theorem verify_lie_strict_db77ef461853 (hV : ContDiff ℝ 1 barrier_db77ef461853) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_strict_db77ef461853
