import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 54b5417f720bdaaafb666b1f8d6eb405d45f4161c29410c9294911878136f67c
noncomputable def barrier_54b5417f720b (x : LeanBarrier.State 2) : ℝ := (((x 0 ^ 2) + (x 1 ^ 2)) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))
@[simp] theorem barrier_unfold_54b5417f720b (x : LeanBarrier.State 2) : barrier_54b5417f720b x = (((x 0 ^ 2) + (x 1 ^ 2)) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) := by
  rfl
def violationSet_lie_strict_54b5417f720b : Set (LeanBarrier.State 2) := {x | (((((x 0 ^ 2) + (x 1 ^ 2)) * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) = (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0 * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) + (((x 0 ^ 2) + (x 1 ^ 2)) * ((-1 : ℝ) - (((2 : ℝ) * x 0) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))))) * x 1) + ((((2 : ℝ) * x 1 * (((-x 0) - x 1) - Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2))))) + (((x 0 ^ 2) + (x 1 ^ 2)) * ((-1 : ℝ) - (((2 : ℝ) * x 1) / ((2 : ℝ) * Real.sqrt (((x 0 ^ 2) + (x 1 ^ 2)))))))) * x 0)) ≤ (0 : ℝ)))}
def unsafeSet_54b5417f720b : Set (LeanBarrier.State 2) := {x | ((x 0 > (0 : ℝ)))}
def initialSet_54b5417f720b : Set (LeanBarrier.State 2) := {x | ((x 0 ≤ (0 : ℝ)) ∧ (x 1 ≤ (0 : ℝ)))}

#print axioms barrier_unfold_54b5417f720b

end LeanBarrier.Generated
