import LeanBarrier

#check Real.tanh
#check Real.neg_one_lt_tanh
#check Real.tanh_lt_one
