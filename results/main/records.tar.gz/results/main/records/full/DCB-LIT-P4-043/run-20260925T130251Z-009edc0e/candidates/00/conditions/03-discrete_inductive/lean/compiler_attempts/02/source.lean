import LeanBarrier.GeneratedCache.Context_01d24a2c62bfd8375d6f4bf7d9b6cc3f0c445b99c12fad5e9a7948838531740d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_discrete_inductive_eb1de39af8d3 (hV : ContDiff ℝ 1 barrier_eb1de39af8d3) : ¬ ∃ x : LeanBarrier.State 3, x ∈ workingSet_eb1de39af8d3 ∧ barrier_eb1de39af8d3 x ≥ 0 ∧ barrier_eb1de39af8d3 (closedLoop_eb1de39af8d3 x) < 0 := by
  rintro ⟨x, _hx, hB, hF⟩
  have ha_lower : (-1 : ℝ) < Real.tanh (x 1) :=
    Real.neg_one_lt_tanh (x 1)
  have ha_upper : Real.tanh (x 1) < (1 : ℝ) :=
    Real.tanh_lt_one (x 1)
  have hb_lower : (-1 : ℝ) < Real.tanh (x 2) :=
    Real.neg_one_lt_tanh (x 2)
  have hb_upper : Real.tanh (x 2) < (1 : ℝ) :=
    Real.tanh_lt_one (x 2)
  have hpos₁ :
      0 ≤ (1 + Real.tanh (x 1)) * (1 + Real.tanh (x 2)) :=
    mul_nonneg (by linarith) (by linarith)
  have hpos₂ :
      0 ≤ (1 - Real.tanh (x 1)) * (1 - Real.tanh (x 2)) :=
    mul_nonneg (by linarith) (by linarith)
  have hprod :
      (-1 : ℝ) ≤ Real.tanh (x 1) * Real.tanh (x 2) := by
    nlinarith [hpos₁, hpos₂]
  simp only [barrier_unfold_eb1de39af8d3,
    closedLoop_apply_0_eb1de39af8d3] at hB hF
  nlinarith [hprod]

#print axioms verify_discrete_inductive_eb1de39af8d3

end LeanBarrier.Generated
