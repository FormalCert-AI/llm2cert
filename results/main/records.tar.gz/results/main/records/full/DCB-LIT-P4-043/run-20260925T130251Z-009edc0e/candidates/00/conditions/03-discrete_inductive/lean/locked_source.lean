-- candidate-sha256: eb1de39af8d3683076594b5bcc0749fd627668b04d33dfcfd4815c67646675ce
noncomputable def barrier_eb1de39af8d3 (x : LeanBarrier.State 3) : ℝ := (x 0 + ((9 : ℝ) / (5 : ℝ)))
@[simp] theorem barrier_unfold_eb1de39af8d3 (x : LeanBarrier.State 3) : barrier_eb1de39af8d3 x = (x 0 + ((9 : ℝ) / (5 : ℝ))) := by
  rfl
noncomputable def closedLoop_eb1de39af8d3 (x : LeanBarrier.State 3) : LeanBarrier.State 3 := ![((((3 : ℝ) / (4 : ℝ)) * x 0) + (((1 : ℝ) / (10 : ℝ)) * Real.tanh (x 1) * Real.tanh (x 2))), ((((41 : ℝ) / (50 : ℝ)) * x 1) + (((9 : ℝ) / (100 : ℝ)) * Real.sin (x 0) * Real.exp ((-(x 2 ^ 2))))), ((((79 : ℝ) / (100 : ℝ)) * x 2) + (((2 : ℝ) / (25 : ℝ)) * Real.cos (x 0) * Real.cos (x 1)))]
@[simp] theorem closedLoop_apply_0_eb1de39af8d3 (x : LeanBarrier.State 3) : closedLoop_eb1de39af8d3 x 0 = ((((3 : ℝ) / (4 : ℝ)) * x 0) + (((1 : ℝ) / (10 : ℝ)) * Real.tanh (x 1) * Real.tanh (x 2))) := by
  simp [closedLoop_eb1de39af8d3]
@[simp] theorem closedLoop_apply_1_eb1de39af8d3 (x : LeanBarrier.State 3) : closedLoop_eb1de39af8d3 x 1 = ((((41 : ℝ) / (50 : ℝ)) * x 1) + (((9 : ℝ) / (100 : ℝ)) * Real.sin (x 0) * Real.exp ((-(x 2 ^ 2))))) := by
  simp [closedLoop_eb1de39af8d3]
@[simp] theorem closedLoop_apply_2_eb1de39af8d3 (x : LeanBarrier.State 3) : closedLoop_eb1de39af8d3 x 2 = ((((79 : ℝ) / (100 : ℝ)) * x 2) + (((2 : ℝ) / (25 : ℝ)) * Real.cos (x 0) * Real.cos (x 1))) := by
  simp [closedLoop_eb1de39af8d3]
def workingSet_eb1de39af8d3 : Set (LeanBarrier.State 3) := {x | True}
def unsafeSet_eb1de39af8d3 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-31 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((-19 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((7 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((13 : ℝ) / (5 : ℝ))) ∧ (x 2 ≥ ((-14 : ℝ) / (5 : ℝ))) ∧ (x 2 ≤ ((-8 : ℝ) / (5 : ℝ))) ∧ ((((x 0 - ((-5 : ℝ) / (2 : ℝ))) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2) + ((x 2 - ((-11 : ℝ) / (5 : ℝ))) ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}
def initialSet_eb1de39af8d3 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((1 : ℝ) / (2 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (0 : ℝ)) ∧ (x 2 ≥ ((3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((13 : ℝ) / (10 : ℝ))) ∧ ((((x 0 - (1 : ℝ)) ^ 2) + ((x 1 - ((-1 : ℝ) / (2 : ℝ))) ^ 2) + ((x 2 - ((4 : ℝ) / (5 : ℝ))) ^ 2)) ≤ ((1 : ℝ) / (4 : ℝ))))}

theorem verify_discrete_inductive_eb1de39af8d3 (hV : ContDiff ℝ 1 barrier_eb1de39af8d3) : ¬ ∃ x : LeanBarrier.State 3, x ∈ workingSet_eb1de39af8d3 ∧ barrier_eb1de39af8d3 x ≥ 0 ∧ barrier_eb1de39af8d3 (closedLoop_eb1de39af8d3 x) < 0
