import LeanBarrier.GeneratedCache.Context_99afa2bca53978a7f5a358d057f22895cdd85088a2a6250029177a2b0ba1bfe1

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_c202717d25f7 (hV : ContDiff ℝ 1 barrier_c202717d25f7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_c202717d25f7 := by
  rintro ⟨x, hx⟩
  change
    ((6 : ℝ) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) = 0 ∧ _) at hx
  rcases hx with ⟨hB, hL⟩

  have hcos0 : |Real.cos (x 0)| ≤ (1 : ℝ) := by
    exact abs_le.mpr ⟨Real.neg_one_le_cos (x 0), Real.cos_le_one (x 0)⟩
  have hsin2 : |Real.sin (x 2)| ≤ |x 2| := by
    exact Real.abs_sin_le_abs
  have ha : |Real.cos (x 0) * Real.sin (x 2)| ≤ |x 2| := by
    rw [abs_mul]
    calc
      |Real.cos (x 0)| * |Real.sin (x 2)| ≤ (1 : ℝ) * |x 2| :=
        mul_le_mul hcos0 hsin2 (abs_nonneg _) (by norm_num)
      _ = |x 2| := one_mul _

  have hsin1 : |Real.sin (x 1)| ≤ |x 1| := by
    exact Real.abs_sin_le_abs
  have hcos3 : |Real.cos (x 3)| ≤ (1 : ℝ) := by
    exact abs_le.mpr ⟨Real.neg_one_le_cos (x 3), Real.cos_le_one (x 3)⟩
  have hb : |Real.sin (x 1) * Real.cos (x 3)| ≤ |x 1| := by
    rw [abs_mul]
    calc
      |Real.sin (x 1)| * |Real.cos (x 3)| ≤ |x 1| * (1 : ℝ) :=
        mul_le_mul hsin1 hcos3 (abs_nonneg _) (abs_nonneg _)
      _ = |x 1| := mul_one _

  have hprodA :
      x 1 * (Real.cos (x 0) * Real.sin (x 2)) ≤ |x 1 * x 2| := by
    calc
      x 1 * (Real.cos (x 0) * Real.sin (x 2))
          ≤ |x 1 * (Real.cos (x 0) * Real.sin (x 2))| := le_abs_self _
      _ = |x 1| * |Real.cos (x 0) * Real.sin (x 2)| := abs_mul _ _
      _ ≤ |x 1| * |x 2| := mul_le_mul_of_nonneg_left ha (abs_nonneg _)
      _ = |x 1 * x 2| := (abs_mul _ _).symm

  have hprodB :
      x 2 * (Real.sin (x 1) * Real.cos (x 3)) ≤ |x 1 * x 2| := by
    calc
      x 2 * (Real.sin (x 1) * Real.cos (x 3))
          ≤ |x 2 * (Real.sin (x 1) * Real.cos (x 3))| := le_abs_self _
      _ = |x 2| * |Real.sin (x 1) * Real.cos (x 3)| := abs_mul _ _
      _ ≤ |x 2| * |x 1| := mul_le_mul_of_nonneg_left hb (abs_nonneg _)
      _ = |x 1 * x 2| := by
        rw [abs_mul]
        ring

  have habs :
      |x 1 * x 2| ≤ ((1 : ℝ) / 2) * (x 1 ^ 2) + ((1 : ℝ) / 2) * (x 2 ^ 2) := by
    apply abs_le.mpr
    constructor
    · nlinarith [sq_nonneg (x 1 + x 2)]
    · nlinarith [sq_nonneg (x 1 - x 2)]

  have hcross :
      ((3 : ℝ) / 10) * (x 1 * (Real.cos (x 0) * Real.sin (x 2))) +
          ((1 : ℝ) / 5) * (x 2 * (Real.sin (x 1) * Real.cos (x 3)))
        ≤ ((1 : ℝ) / 4) * (x 1 ^ 2) + ((1 : ℝ) / 4) * (x 2 ^ 2) := by
    nlinarith [hprodA, hprodB, habs]

  have h01 :
      ((3 : ℝ) / 5) * (x 0 * x 1)
        ≤ ((3 : ℝ) / 10) * (x 0 ^ 2) + ((3 : ℝ) / 10) * (x 1 ^ 2) := by
    nlinarith [sq_nonneg (x 0 - x 1)]

  have hlow :
      ((7 : ℝ) / 10) * (x 0 ^ 2) +
          ((1 : ℝ) / 4) * (x 1 ^ 2) +
          ((19 : ℝ) / 20) * (x 2 ^ 2) +
          x 3 ^ 2 ≤ 0 := by
    nlinarith [hL, h01, hcross]

  nlinarith [sq_nonneg (x 0), sq_nonneg (x 1), sq_nonneg (x 2), sq_nonneg (x 3)]

#print axioms verify_lie_strict_c202717d25f7

end LeanBarrier.Generated
