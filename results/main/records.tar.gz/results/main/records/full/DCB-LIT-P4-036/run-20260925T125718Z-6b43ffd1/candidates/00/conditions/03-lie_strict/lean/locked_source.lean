-- candidate-sha256: c202717d25f76917943a37a08f779f44b95eb134f663e4cf5d5e46665b629fa4
noncomputable def barrier_c202717d25f7 (x : LeanBarrier.State 4) : ℝ := ((6 : ℝ) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)))
@[simp] theorem barrier_unfold_c202717d25f7 (x : LeanBarrier.State 4) : barrier_c202717d25f7 x = ((6 : ℝ) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2))) := by
  rfl
def violationSet_lie_strict_c202717d25f7 : Set (LeanBarrier.State 4) := {x | ((((6 : ℝ) - ((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2))) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * ((((-1 : ℝ) / (2 : ℝ)) * x 0) + (((3 : ℝ) / (10 : ℝ)) * x 1))) + ((-((2 : ℝ) * x 1)) * ((((-2 : ℝ) / (5 : ℝ)) * x 1) + (((3 : ℝ) / (20 : ℝ)) * Real.cos (x 0) * Real.sin (x 2)))) + ((-((2 : ℝ) * x 2)) * ((((-3 : ℝ) / (5 : ℝ)) * x 2) + (((1 : ℝ) / (10 : ℝ)) * Real.sin (x 1) * Real.cos (x 3)))) + (((-1 : ℝ) / (2 : ℝ)) * (-((2 : ℝ) * x 3)) * x 3)) ≤ (0 : ℝ)))}
def unsafeSet_c202717d25f7 : Set (LeanBarrier.State 4) := {x | ((((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≥ ((25 : ℝ) / (4 : ℝ))))}
def initialSet_c202717d25f7 : Set (LeanBarrier.State 4) := {x | ((x 0 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 2 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≥ ((-3 : ℝ) / (10 : ℝ))) ∧ (x 3 ≤ ((3 : ℝ) / (10 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2) + (x 2 ^ 2) + (x 3 ^ 2)) ≤ ((9 : ℝ) / (100 : ℝ))))}

theorem verify_lie_strict_c202717d25f7 (hV : ContDiff ℝ 1 barrier_c202717d25f7) : ¬ ∃ x : LeanBarrier.State 4, x ∈ violationSet_lie_strict_c202717d25f7
