import LeanBarrier

#check Real.cos
#check Real.neg_one_le_cos
#check Real.cos_le_one
#check Real.sin
#check Real.abs_sin_le_abs
