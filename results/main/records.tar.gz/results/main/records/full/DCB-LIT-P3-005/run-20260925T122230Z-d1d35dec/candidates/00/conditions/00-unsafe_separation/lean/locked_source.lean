-- candidate-sha256: aaef7f12f799205974434baa54525f8d718b00f744f792b11624c2d2f0452f3f
noncomputable def barrier_aaef7f12f799 (x : LeanBarrier.State 2) : ℝ := ((((((39999 : ℝ) / (640000 : ℝ)) * (Real.pi ^ 2)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (((1 : ℝ) / (100 : ℝ)) * x 0 * x 1))
@[simp] theorem barrier_unfold_aaef7f12f799 (x : LeanBarrier.State 2) : barrier_aaef7f12f799 x = ((((((39999 : ℝ) / (640000 : ℝ)) * (Real.pi ^ 2)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (((1 : ℝ) / (100 : ℝ)) * x 0 * x 1)) := by
  rfl
def violationSet_unsafe_separation_aaef7f12f799 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-1 : ℝ)) ∧ (x 0 ≤ (1 : ℝ)) ∧ (x 1 ≥ (-1 : ℝ)) ∧ (x 1 ≤ (1 : ℝ)) ∧ (((((((39999 : ℝ) / (640000 : ℝ)) * (Real.pi ^ 2)) - (x 0 ^ 2)) - (x 1 ^ 2)) - (((1 : ℝ) / (100 : ℝ)) * x 0 * x 1)) ≥ (0 : ℝ)) ∧ (((x 0 < (-(((1 : ℝ) / (4 : ℝ)) * Real.pi)))) ∨ ((x 0 > (((1 : ℝ) / (4 : ℝ)) * Real.pi))) ∨ ((x 1 < (-(((1 : ℝ) / (4 : ℝ)) * Real.pi)))) ∨ ((x 1 > (((1 : ℝ) / (4 : ℝ)) * Real.pi)))))}
def unsafeSet_aaef7f12f799 : Set (LeanBarrier.State 2) := {x | ((((x 0 < (-(((1 : ℝ) / (4 : ℝ)) * Real.pi)))) ∨ ((x 0 > (((1 : ℝ) / (4 : ℝ)) * Real.pi))) ∨ ((x 1 < (-(((1 : ℝ) / (4 : ℝ)) * Real.pi)))) ∨ ((x 1 > (((1 : ℝ) / (4 : ℝ)) * Real.pi)))))}

theorem verify_unsafe_separation_aaef7f12f799 (hV : ContDiff ℝ 1 barrier_aaef7f12f799) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_unsafe_separation_aaef7f12f799
