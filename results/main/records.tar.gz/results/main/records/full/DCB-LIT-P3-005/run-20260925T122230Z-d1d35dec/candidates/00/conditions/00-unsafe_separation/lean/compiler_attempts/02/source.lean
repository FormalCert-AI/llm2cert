import LeanBarrier.GeneratedCache.Context_792cb0bfdaab5d7b7b44a461a5f5ecf930220445d40027a8e27bc32434f7f115

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_unsafe_separation_aaef7f12f799 (hV : ContDiff ℝ 1 barrier_aaef7f12f799) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_unsafe_separation_aaef7f12f799 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_unsafe_separation_aaef7f12f799, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0lo, hx0hi, hx1lo, hx1hi, hB, hunsafe⟩
  have hpi : 0 < Real.pi := Real.pi_pos
  rcases hunsafe with h | h | h | h
  · have hm : 0 < -(x 0) - Real.pi / 4 := by
      linarith
    have hp : 0 < -(x 0) + Real.pi / 4 := by
      linarith
    have hs : 0 < (-(x 0) - Real.pi / 4) * (-(x 0) + Real.pi / 4) :=
      mul_pos hm hp
    nlinarith [hs, sq_nonneg (x 1 + x 0 / 200)]
  · have hm : 0 < x 0 - Real.pi / 4 := by
      linarith
    have hp : 0 < x 0 + Real.pi / 4 := by
      linarith
    have hs : 0 < (x 0 - Real.pi / 4) * (x 0 + Real.pi / 4) :=
      mul_pos hm hp
    nlinarith [hs, sq_nonneg (x 1 + x 0 / 200)]
  · have hm : 0 < -(x 1) - Real.pi / 4 := by
      linarith
    have hp : 0 < -(x 1) + Real.pi / 4 := by
      linarith
    have hs : 0 < (-(x 1) - Real.pi / 4) * (-(x 1) + Real.pi / 4) :=
      mul_pos hm hp
    nlinarith [hs, sq_nonneg (x 0 + x 1 / 200)]
  · have hm : 0 < x 1 - Real.pi / 4 := by
      linarith
    have hp : 0 < x 1 + Real.pi / 4 := by
      linarith
    have hs : 0 < (x 1 - Real.pi / 4) * (x 1 + Real.pi / 4) :=
      mul_pos hm hp
    nlinarith [hs, sq_nonneg (x 0 + x 1 / 200)]

#print axioms verify_unsafe_separation_aaef7f12f799

end LeanBarrier.Generated
