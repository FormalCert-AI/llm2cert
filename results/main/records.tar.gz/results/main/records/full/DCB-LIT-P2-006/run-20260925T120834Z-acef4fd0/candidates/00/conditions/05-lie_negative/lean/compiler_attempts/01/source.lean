import LeanBarrier

#check Real.pi
#check Real.sin
#check Real.cos
#check Real.sin_add
#check Real.cos_pi_div_three
#check Real.pi_pos
#check Real.sin_pos_of_pos_of_lt_pi
#check Real.sin_le_one
#check Real.cos_bound
#check Real.cos_le_one
#check Real.mul_cos_le_sin
#check Real.sin_le
#check Real.sin_neg
#check Real.cos_neg
