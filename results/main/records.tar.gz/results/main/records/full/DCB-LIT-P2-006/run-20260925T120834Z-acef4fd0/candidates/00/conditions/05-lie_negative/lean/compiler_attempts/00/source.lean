import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 6314d345db0cc4daba9c2462d9067fb5cf09b95d3a0471d1a6f79affff2fdb6e
noncomputable def barrier_6314d345db0c (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + ((x 0 + x 1) ^ 2) + ((2 : ℝ) * (x 1 ^ 2)))
@[simp] theorem barrier_unfold_6314d345db0c (x : LeanBarrier.State 2) : barrier_6314d345db0c x = ((x 0 ^ 2) + ((x 0 + x 1) ^ 2) + ((2 : ℝ) * (x 1 ^ 2))) := by
  rfl
def violationSet_lie_negative_6314d345db0c : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-2 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (-3 : ℝ)) ∧ (x 1 ≤ ((3 : ℝ) / (2 : ℝ))) ∧ (((x 0 ^ 2) + ((x 0 + x 1) ^ 2) + ((2 : ℝ) * (x 1 ^ 2))) ≤ ((1 : ℝ) / (16 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0) + ((2 : ℝ) * (x 0 + x 1))) * x 1) + ((((2 : ℝ) * (x 0 + x 1)) + ((4 : ℝ) * x 1)) * (((((-1 : ℝ) / (2 : ℝ)) * x 1) - Real.sin ((x 0 + (((1 : ℝ) / (3 : ℝ)) * Real.pi)))) + Real.sin ((((1 : ℝ) / (3 : ℝ)) * Real.pi))))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_6314d345db0c

end LeanBarrier.Generated
