import LeanBarrier

#check Real.sin_sq_add_cos_sq
