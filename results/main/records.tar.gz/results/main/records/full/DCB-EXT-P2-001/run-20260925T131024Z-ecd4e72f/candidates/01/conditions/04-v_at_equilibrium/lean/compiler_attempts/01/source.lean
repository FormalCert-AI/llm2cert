import LeanBarrier.GeneratedCache.Context_d367891298a1860ba649e3903f3aa18e828790452ef94840017385835e93a2b3

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_53ede657fdfb (hV : ContDiff ℝ 1 barrier_53ede657fdfb) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_53ede657fdfb := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  rw [hx0, hx1] at hbad
  simp at hbad

#print axioms verify_v_at_equilibrium_53ede657fdfb

end LeanBarrier.Generated
