import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 8205c88a09da498767bf13b177cc0076bfefb3b17bfe9a996972379034b09137
noncomputable def barrier_8205c88a09da (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 0 * x 1) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_8205c88a09da (x : LeanBarrier.State 2) : barrier_8205c88a09da x = ((x 0 ^ 2) + (x 0 * x 1) + (x 1 ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_8205c88a09da : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((Real.sin (x 1) > (0 : ℝ))) ∨ ((Real.sin (x 1) < (0 : ℝ))) ∨ ((((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - x 0) - x 1) - (Real.cos (x 1) / ((1 : ℝ) - x 0))) > (0 : ℝ))) ∨ ((((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - x 0) - x 1) - (Real.cos (x 1) / ((1 : ℝ) - x 0))) < (0 : ℝ)))))}

#print axioms barrier_unfold_8205c88a09da

end LeanBarrier.Generated
