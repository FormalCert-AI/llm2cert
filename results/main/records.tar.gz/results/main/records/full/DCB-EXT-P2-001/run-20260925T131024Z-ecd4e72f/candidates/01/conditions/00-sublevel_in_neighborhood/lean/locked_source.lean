-- candidate-sha256: 53ede657fdfbf33f7bfca359bd7b82c7e4c022d0f41d89e0944b5c9a01e64549
noncomputable def barrier_53ede657fdfb (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + ((x 0 + Real.sin (x 1)) ^ 2))
@[simp] theorem barrier_unfold_53ede657fdfb (x : LeanBarrier.State 2) : barrier_53ede657fdfb x = ((x 0 ^ 2) + ((x 0 + Real.sin (x 1)) ^ 2)) := by
  rfl
def violationSet_sublevel_in_neighborhood_53ede657fdfb : Set (LeanBarrier.State 2) := {x | ((((x 0 ^ 2) + ((x 0 + Real.sin (x 1)) ^ 2)) ≤ ((1 : ℝ) / (16 : ℝ))) ∧ (((x 0 < ((-4 : ℝ) / (5 : ℝ)))) ∨ ((x 0 > ((4 : ℝ) / (5 : ℝ)))) ∨ ((x 1 < ((-4 : ℝ) / (5 : ℝ)))) ∨ ((x 1 > ((4 : ℝ) / (5 : ℝ)))) ∨ ((((x 0 ^ 2) + (x 1 ^ 2)) > ((16 : ℝ) / (25 : ℝ))))))}

theorem verify_sublevel_in_neighborhood_53ede657fdfb (hV : ContDiff ℝ 1 barrier_53ede657fdfb) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_sublevel_in_neighborhood_53ede657fdfb
