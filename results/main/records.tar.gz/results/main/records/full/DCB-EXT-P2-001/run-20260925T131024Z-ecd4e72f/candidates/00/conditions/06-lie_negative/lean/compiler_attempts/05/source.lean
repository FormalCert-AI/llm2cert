import LeanBarrier.GeneratedCache.Context_b7c65c15fac331f8beb7df79b15a62d9e5a14dfebccf218634139c0179ae5662

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_8205c88a09da (hV : ContDiff ℝ 1 barrier_8205c88a09da) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_8205c88a09da := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_8205c88a09da, Set.mem_setOf_eq] at hx
  rcases hx with ⟨ha_lower, ha_upper, hb_lower, hb_upper, hbox, hVbound, hnonzero, hLie⟩
  have hcoord : (x 0) ^ 2 + (x 1) ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [sq_nonneg (x 0 + x 1)]
  have hb_sq : (x 1) ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [sq_nonneg (x 0)]
  have habs_sq : |x 1| ^ 2 = (x 1) ^ 2 := by
    rw [sq_abs]
  have habs_sq_le : |x 1| ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [hb_sq, habs_sq]
  have habs_mul :
      0 ≤ |x 1| * ((1 : ℝ) / 4 - |x 1| ^ 2) := by
    apply mul_nonneg (abs_nonneg _)
    nlinarith
  have habs_le_one : |x 1| ≤ (1 : ℝ) := by
    nlinarith [abs_nonneg (x 1), habs_sq_le]
  have hsin := Real.sin_bound habs_le_one
  have habs_cube_nonneg : 0 ≤ |x 1| ^ 3 :=
    pow_nonneg (abs_nonneg _) _
  have habs_cube_mul :
      0 ≤ |x 1| ^ 3 * ((1 : ℝ) / 4 - |x 1| ^ 2) := by
    apply mul_nonneg habs_cube_nonneg
    nlinarith
  have hpow3 : |x 1| ^ 3 ≤ |x 1| / 4 := by
    nlinarith [habs_mul]
  have hpow5 : |x 1| ^ 5 ≤ |x 1| ^ 3 / 4 := by
    nlinarith [habs_cube_mul]
  have hcenter_abs :
      |((x 1 - (x 1) ^ 3 / 6) - x 1)| = |(x 1) ^ 3 / 6| := by
    rw [show (x 1 - (x 1) ^ 3 / 6) - x 1 = -((x 1) ^ 3 / 6) by ring,
      abs_neg]
  have hcube_abs : |(x 1) ^ 3 / 6| = |x 1| ^ 3 / 6 := by
    rw [abs_div, abs_pow]
    norm_num
  have htri :
      |Real.sin (x 1) - x 1| ≤
        |Real.sin (x 1) - (x 1 - (x 1) ^ 3 / 6)| +
          |(x 1 - (x 1) ^ 3 / 6) - x 1| := by
    let a : ℝ := Real.sin (x 1) - (x 1 - (x 1) ^ 3 / 6)
    let b : ℝ := (x 1 - (x 1) ^ 3 / 6) - x 1
    have hab : |a + b| ≤ |a| + |b| := by
      apply (abs_le).2
      constructor
      · have ha : -|a| ≤ a := neg_abs_le a
        have hb : -|b| ≤ b := neg_abs_le b
        linarith
      · have ha : a ≤ |a| := le_abs_self a
        have hb : b ≤ |b| := le_abs_self b
        linarith
    dsimp [a, b] at hab
    convert hab using 1 <;> ring
  have he_abs :
      |Real.sin (x 1) - x 1| ≤ |x 1| / 4 := by
    calc
      |Real.sin (x 1) - x 1| ≤
          |Real.sin (x 1) - (x 1 - (x 1) ^ 3 / 6)| +
            |(x 1 - (x 1) ^ 3 / 6) - x 1| := htri
      _ = |Real.sin (x 1) - (x 1 - (x 1) ^ 3 / 6)| +
            |(x 1) ^ 3 / 6| := by rw [hcenter_abs]
      _ = |Real.sin (x 1) - (x 1 - (x 1) ^ 3 / 6)| +
            |x 1| ^ 3 / 6 := by rw [hcube_abs]
      _ ≤ |x 1| ^ 5 / 100 + |x 1| ^ 3 / 6 := by
            exact add_le_add hsin (le_refl _)
      _ ≤ |x 1| / 4 := by
            nlinarith [hpow3, hpow5, habs_cube_nonneg]
  have he_lower :
      -(|x 1| / 4) ≤ Real.sin (x 1) - x 1 :=
    (abs_le.mp he_abs).1
  have he_upper :
      Real.sin (x 1) - x 1 ≤ |x 1| / 4 :=
    (abs_le.mp he_abs).2
  have he_factor :
      0 ≤
        (|x 1| / 4 - (Real.sin (x 1) - x 1)) *
          (|x 1| / 4 + (Real.sin (x 1) - x 1)) := by
    apply mul_nonneg <;> linarith
  have he_sq :
      (Real.sin (x 1) - x 1) ^ 2 ≤ (x 1) ^ 2 / 16 := by
    nlinarith [he_factor, habs_sq]
  have hq_pos :
      0 < (x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2 := by
    nlinarith [sq_nonneg (x 0 + x 1)]
  have hu_sq :
      (2 * x 0 + x 1) ^ 2 ≤
        4 * ((x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2) := by
    nlinarith [sq_nonneg (x 1)]
  have hb_q :
      3 * (x 1) ^ 2 ≤
        4 * ((x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2) := by
    nlinarith [sq_nonneg (2 * x 0 + x 1)]
  have hyoung :
      (2 * x 0 + x 1) * (Real.sin (x 1) - x 1) ≤
        (2 * x 0 + x 1) ^ 2 / 8 +
          2 * (Real.sin (x 1) - x 1) ^ 2 := by
    nlinarith [sq_nonneg ((2 * x 0 + x 1) - 4 * (Real.sin (x 1) - x 1))]
  have hproduct :
      (2 * x 0 + x 1) * (Real.sin (x 1) - x 1) <
        (x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2 := by
    nlinarith [hyoung, hu_sq, he_sq, hb_q, hq_pos]
  have hcancel :
      (((Real.cos (x 1) / (1 - x 0) - x 0) - x 1) -
          Real.cos (x 1) / (1 - x 0)) =
        -x 0 - x 1 := by
    ring
  rw [hcancel] at hLie
  have hder :
      0 ≤
        -(x 0) ^ 2 - 3 * x 0 * x 1 - 2 * (x 1) ^ 2 +
          (2 * x 0 + x 1) * Real.sin (x 1) := by
    nlinarith [hLie]
  nlinarith [hder, hproduct]

#print axioms verify_lie_negative_8205c88a09da

end LeanBarrier.Generated
