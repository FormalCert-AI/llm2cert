import LeanBarrier.GeneratedCache.Context_b35798a69ecfdf9d5de97e507992862f152c01d8d9cdbf5a479682ac84b3746a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_ff14383fd12a (hV : ContDiff ℝ 1 barrier_ff14383fd12a) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_ff14383fd12a := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hx⟩
  norm_num [hx0, hx1] at hx

#print axioms verify_v_at_equilibrium_ff14383fd12a

end LeanBarrier.Generated
