-- candidate-sha256: 8205c88a09da498767bf13b177cc0076bfefb3b17bfe9a996972379034b09137
noncomputable def barrier_8205c88a09da (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (x 0 * x 1) + (x 1 ^ 2))
@[simp] theorem barrier_unfold_8205c88a09da (x : LeanBarrier.State 2) : barrier_8205c88a09da x = ((x 0 ^ 2) + (x 0 * x 1) + (x 1 ^ 2)) := by
  rfl
def violationSet_lie_negative_8205c88a09da : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-4 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((16 : ℝ) / (25 : ℝ))) ∧ (((x 0 ^ 2) + (x 0 * x 1) + (x 1 ^ 2)) ≤ ((1 : ℝ) / (8 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0) + x 1) * Real.sin (x 1)) + ((x 0 + ((2 : ℝ) * x 1)) * ((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - x 0) - x 1) - (Real.cos (x 1) / ((1 : ℝ) - x 0))))) ≥ (0 : ℝ)))}

theorem verify_lie_negative_8205c88a09da (hV : ContDiff ℝ 1 barrier_8205c88a09da) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_8205c88a09da
