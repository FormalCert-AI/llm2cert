import LeanBarrier

#check Real.sin_bound
#check Real.sin
#check Real.cos
