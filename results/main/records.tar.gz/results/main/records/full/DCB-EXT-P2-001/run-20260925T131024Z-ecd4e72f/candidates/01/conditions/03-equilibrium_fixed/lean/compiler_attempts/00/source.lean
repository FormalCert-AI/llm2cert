import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 53ede657fdfbf33f7bfca359bd7b82c7e4c022d0f41d89e0944b5c9a01e64549
noncomputable def barrier_53ede657fdfb (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + ((x 0 + Real.sin (x 1)) ^ 2))
@[simp] theorem barrier_unfold_53ede657fdfb (x : LeanBarrier.State 2) : barrier_53ede657fdfb x = ((x 0 ^ 2) + ((x 0 + Real.sin (x 1)) ^ 2)) := by
  rfl
def violationSet_equilibrium_fixed_53ede657fdfb : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((Real.sin (x 1) > (0 : ℝ))) ∨ ((Real.sin (x 1) < (0 : ℝ))) ∨ (((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - (((2 : ℝ) * (x 0 + Real.sin (x 1))) / Real.cos (x 1))) - (Real.cos (x 1) / ((1 : ℝ) - x 0))) > (0 : ℝ))) ∨ (((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - (((2 : ℝ) * (x 0 + Real.sin (x 1))) / Real.cos (x 1))) - (Real.cos (x 1) / ((1 : ℝ) - x 0))) < (0 : ℝ)))))}

#print axioms barrier_unfold_53ede657fdfb

end LeanBarrier.Generated
