import LeanBarrier.GeneratedCache.Context_8569a3ccfc30592448f8c20767ea31d2fa83bc997a86493b0b88e28dc8b1057a

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_ff14383fd12a (hV : ContDiff ℝ 1 barrier_ff14383fd12a) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_ff14383fd12a := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_equilibrium_fixed_ff14383fd12a] at hx
  rcases hx with ⟨hx0, hx1, hbad⟩
  norm_num [hx0, hx1] at hbad

#print axioms verify_equilibrium_fixed_ff14383fd12a

end LeanBarrier.Generated
