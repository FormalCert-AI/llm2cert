import LeanBarrier.GeneratedCache.Context_4773950a73d6a42bc9af278cb23a2f5444cd18d40c4f68f2a2064a963099b1ef

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_8205c88a09da (hV : ContDiff ℝ 1 barrier_8205c88a09da) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_8205c88a09da := by
  rintro ⟨x, hx⟩
  dsimp [violationSet_equilibrium_fixed_8205c88a09da] at hx
  rcases hx with ⟨hx0, hx1, hbad⟩
  norm_num [hx0, hx1] at hbad

#print axioms verify_equilibrium_fixed_8205c88a09da

end LeanBarrier.Generated
