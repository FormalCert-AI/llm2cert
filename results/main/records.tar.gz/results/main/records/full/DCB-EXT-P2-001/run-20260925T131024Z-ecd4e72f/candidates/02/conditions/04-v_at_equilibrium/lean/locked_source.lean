-- candidate-sha256: ff14383fd12aacfd054500ac4a0374c60d8726ef4da92f0057238ce718e82f30
noncomputable def barrier_ff14383fd12a (x : LeanBarrier.State 2) : ℝ := ((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1)))
@[simp] theorem barrier_unfold_ff14383fd12a (x : LeanBarrier.State 2) : barrier_ff14383fd12a x = ((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1))) := by
  rfl
def violationSet_v_at_equilibrium_ff14383fd12a : Set (LeanBarrier.State 2) := {x | ((x 0 = (0 : ℝ)) ∧ (x 1 = (0 : ℝ)) ∧ (((((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1))) > (0 : ℝ))) ∨ ((((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1))) < (0 : ℝ)))))}

theorem verify_v_at_equilibrium_ff14383fd12a (hV : ContDiff ℝ 1 barrier_ff14383fd12a) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_v_at_equilibrium_ff14383fd12a
