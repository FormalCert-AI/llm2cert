import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: ff14383fd12aacfd054500ac4a0374c60d8726ef4da92f0057238ce718e82f30
noncomputable def barrier_ff14383fd12a (x : LeanBarrier.State 2) : ℝ := ((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1)))
@[simp] theorem barrier_unfold_ff14383fd12a (x : LeanBarrier.State 2) : barrier_ff14383fd12a x = ((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1))) := by
  rfl
def violationSet_lie_negative_ff14383fd12a : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-4 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-4 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((4 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((16 : ℝ) / (25 : ℝ))) ∧ (((((((1 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + (1 : ℝ)) - Real.cos (x 1)) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.sin (x 1))) ≤ ((1 : ℝ) / (32 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((x 0 + (((1 : ℝ) / (4 : ℝ)) * Real.sin (x 1))) * Real.sin (x 1)) + ((Real.sin (x 1) + (((1 : ℝ) / (4 : ℝ)) * x 0 * Real.cos (x 1))) * ((((Real.cos (x 1) / ((1 : ℝ) - x 0)) - x 0) - ((2 : ℝ) * Real.sin (x 1))) - (Real.cos (x 1) / ((1 : ℝ) - x 0))))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_ff14383fd12a

end LeanBarrier.Generated
