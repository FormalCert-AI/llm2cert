import LeanBarrier.GeneratedCache.Context_b7c65c15fac331f8beb7df79b15a62d9e5a14dfebccf218634139c0179ae5662

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_8205c88a09da (hV : ContDiff ℝ 1 barrier_8205c88a09da) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_negative_8205c88a09da := by
  rintro ⟨x, hx⟩
  simp only [violationSet_lie_negative_8205c88a09da, Set.mem_setOf_eq] at hx
  rcases hx with ⟨ha_lower, ha_upper, hb_lower, hb_upper, hbox, hVbound, hnonzero, hLie⟩
  have hcoord : (x 0) ^ 2 + (x 1) ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [sq_nonneg (x 0 + x 1)]
  have hb_sq : (x 1) ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [sq_nonneg (x 0)]
  have habs_sq : |x 1| ^ 2 = (x 1) ^ 2 := by
    rw [sq_abs]
  have habs_sq_le : |x 1| ^ 2 ≤ (1 : ℝ) / 4 := by
    nlinarith [hb_sq, habs_sq]
  have habs_mul :
      0 ≤ |x 1| * ((1 : ℝ) / 4 - |x 1| ^ 2) := by
    apply mul_nonneg (abs_nonneg _)
    nlinarith
  have habs_le_one : |x 1| ≤ (1 : ℝ) := by
    nlinarith [abs_nonneg (x 1), habs_sq_le]
  have hsin := Real.sin_bound habs_le_one
  have he_abs :
      |Real.sin (x 1) - x 1| ≤ |x 1| / 4 := by
    nlinarith [hsin, habs_mul]
  have he_lower :
      -(|x 1| / 4) ≤ Real.sin (x 1) - x 1 :=
    (abs_le.mp he_abs).1
  have he_upper :
      Real.sin (x 1) - x 1 ≤ |x 1| / 4 :=
    (abs_le.mp he_abs).2
  have he_factor :
      0 ≤
        (|x 1| / 4 - (Real.sin (x 1) - x 1)) *
          (|x 1| / 4 + (Real.sin (x 1) - x 1)) := by
    apply mul_nonneg <;> linarith
  have he_sq :
      (Real.sin (x 1) - x 1) ^ 2 ≤ (x 1) ^ 2 / 16 := by
    nlinarith [he_factor, habs_sq]
  have hq_pos :
      0 < (x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2 := by
    nlinarith [sq_nonneg (x 0 + x 1)]
  have hu_sq :
      (2 * x 0 + x 1) ^ 2 ≤
        4 * ((x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2) := by
    nlinarith [sq_nonneg (x 1)]
  have hb_q :
      3 * (x 1) ^ 2 ≤
        4 * ((x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2) := by
    nlinarith [sq_nonneg (2 * x 0 + x 1)]
  have hyoung :
      (2 * x 0 + x 1) * (Real.sin (x 1) - x 1) ≤
        (2 * x 0 + x 1) ^ 2 / 8 +
          2 * (Real.sin (x 1) - x 1) ^ 2 := by
    nlinarith [sq_nonneg ((2 * x 0 + x 1) - 4 * (Real.sin (x 1) - x 1))]
  have hproduct :
      (2 * x 0 + x 1) * (Real.sin (x 1) - x 1) <
        (x 0) ^ 2 + x 0 * x 1 + (x 1) ^ 2 := by
    nlinarith [hyoung, hu_sq, he_sq, hb_q, hq_pos]
  have hcancel :
      (((Real.cos (x 1) / (1 - x 0) - x 0) - x 1) -
          Real.cos (x 1) / (1 - x 0)) =
        -x 0 - x 1 := by
    ring
  rw [hcancel] at hLie
  have hder :
      0 ≤
        -(x 0) ^ 2 - 3 * x 0 * x 1 - 2 * (x 1) ^ 2 +
          (2 * x 0 + x 1) * Real.sin (x 1) := by
    nlinarith [hLie]
  nlinarith [hder, hproduct]

#print axioms verify_lie_negative_8205c88a09da

end LeanBarrier.Generated
