import LeanBarrier.GeneratedCache.Context_e756ac673852daf8fed9ae966a2996c0281d39e70d915942983dfcd149cb44e5

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_positive_definite_ff14383fd12a (hV : ContDiff ℝ 1 barrier_ff14383fd12a) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_positive_definite_ff14383fd12a := by
  rintro ⟨x, hx⟩
  simp only [violationSet_positive_definite_ff14383fd12a, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hx0lo, hx0hi, hx1lo, hx1hi, hradle, hbarle, hradpos, hbarnonpos⟩
  have htrig :
      Real.sin (x 1) ^ 2 + Real.cos (x 1) ^ 2 = 1 :=
    Real.sin_sq_add_cos_sq (x 1)
  have hsin_bound :
      Real.sin (x 1) ^ 2 ≤ 2 * (1 - Real.cos (x 1)) := by
    nlinarith [htrig, sq_nonneg (1 - Real.cos (x 1))]
  have hlower :
      ((3 : ℝ) / 8) * (x 0 ^ 2 + Real.sin (x 1) ^ 2) ≤
        (((((1 : ℝ) / 2) * x 0 ^ 2) + 1) - Real.cos (x 1)) +
          ((1 : ℝ) / 4) * x 0 * Real.sin (x 1) := by
    nlinarith [hsin_bound, sq_nonneg (x 0 + Real.sin (x 1))]
  have hsum_nonpos : x 0 ^ 2 + Real.sin (x 1) ^ 2 ≤ 0 := by
    nlinarith [hlower, hbarnonpos]
  have ha_sq : x 0 ^ 2 = 0 := by
    nlinarith [hsum_nonpos, sq_nonneg (x 0), sq_nonneg (Real.sin (x 1))]
  have ha : x 0 = 0 := by
    have ha_mul : x 0 * x 0 = 0 := by
      simpa only [pow_two] using ha_sq
    rcases mul_eq_zero.mp ha_mul with ha | ha
    · exact ha
    · exact ha
  have hy_sq : Real.sin (x 1) ^ 2 = 0 := by
    nlinarith [hsum_nonpos, sq_nonneg (x 0), sq_nonneg (Real.sin (x 1))]
  have hy : Real.sin (x 1) = 0 := by
    have hy_mul : Real.sin (x 1) * Real.sin (x 1) = 0 := by
      simpa only [pow_two] using hy_sq
    rcases mul_eq_zero.mp hy_mul with hy | hy
    · exact hy
    · exact hy
  have hb : x 1 = 0 := by
    rcases lt_trichotomy (x 1) 0 with hneg | hzero | hpos
    · have hnegpos : 0 < -(x 1) := by
        linarith
      have hnegpi : -(x 1) < Real.pi := by
        nlinarith [Real.pi_gt_three]
      have hspos : 0 < Real.sin (-(x 1)) :=
        Real.sin_pos_of_pos_of_lt_pi hnegpos hnegpi
      have hszero : Real.sin (-(x 1)) = 0 := by
        calc
          Real.sin (-(x 1)) = -Real.sin (x 1) := Real.sin_neg (x 1)
          _ = 0 := by simp [hy]
      nlinarith
    · exact hzero
    · have hpospi : x 1 < Real.pi := by
        nlinarith [Real.pi_gt_three]
      have hspos : 0 < Real.sin (x 1) :=
        Real.sin_pos_of_pos_of_lt_pi hpos hpospi
      nlinarith [hy]
  rw [ha, hb] at hradpos
  norm_num at hradpos

#print axioms verify_positive_definite_ff14383fd12a

end LeanBarrier.Generated
