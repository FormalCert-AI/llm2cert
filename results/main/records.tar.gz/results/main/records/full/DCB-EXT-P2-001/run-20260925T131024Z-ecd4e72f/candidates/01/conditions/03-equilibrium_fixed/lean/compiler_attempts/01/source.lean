import LeanBarrier.GeneratedCache.Context_dcb4874ce5c2c1e81722be8666d10a5c4962422e815bf4cadec281507e168f57

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_53ede657fdfb (hV : ContDiff ℝ 1 barrier_53ede657fdfb) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_53ede657fdfb := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hne⟩
  norm_num [hx0, hx1] at hne

#print axioms verify_equilibrium_fixed_53ede657fdfb

end LeanBarrier.Generated
