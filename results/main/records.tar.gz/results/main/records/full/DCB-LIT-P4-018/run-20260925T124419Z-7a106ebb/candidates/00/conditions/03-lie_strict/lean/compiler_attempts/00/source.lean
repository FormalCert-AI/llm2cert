import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 0d60f123c165434cc2e512b2fa6e89f57ce57f18b4f054d913817fddd244a67c
noncomputable def barrier_0d60f123c165 (x : LeanBarrier.State 2) : ℝ := (((1 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2))
@[simp] theorem barrier_unfold_0d60f123c165 (x : LeanBarrier.State 2) : barrier_0d60f123c165 x = (((1 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) := by
  rfl
def violationSet_lie_strict_0d60f123c165 : Set (LeanBarrier.State 2) := {x | (((((1 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) = (0 : ℝ)) ∧ ((((-((2 : ℝ) * x 0)) * (x 1 + ((((-7 : ℝ) / (20 : ℝ)) * x 1) - (((3 : ℝ) / (50 : ℝ)) * x 0)))) + ((-((2 : ℝ) * x 1)) * ((((((-3 : ℝ) / (10 : ℝ)) * x 0) - (((1 : ℝ) / (5 : ℝ)) * (Real.cos (x 0) + (1 : ℝ)) * x 1)) - (((1 : ℝ) / (10 : ℝ)) * (x 0 ^ 3))) + ((((-7 : ℝ) / (20 : ℝ)) * x 0) - (((3 : ℝ) / (50 : ℝ)) * x 1))))) ≤ (0 : ℝ)))}
def unsafeSet_0d60f123c165 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (1 : ℝ)) ∧ (x 0 ≤ (3 : ℝ)) ∧ (x 1 ≥ (1 : ℝ)) ∧ (x 1 ≤ (3 : ℝ)) ∧ ((((x 0 - (2 : ℝ)) ^ 2) + ((x 1 - (2 : ℝ)) ^ 2)) ≤ (1 : ℝ)))}
def initialSet_0d60f123c165 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 0 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≥ ((-3 : ℝ) / (5 : ℝ))) ∧ (x 1 ≤ ((3 : ℝ) / (5 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ ((9 : ℝ) / (25 : ℝ))))}

#print axioms barrier_unfold_0d60f123c165

end LeanBarrier.Generated
