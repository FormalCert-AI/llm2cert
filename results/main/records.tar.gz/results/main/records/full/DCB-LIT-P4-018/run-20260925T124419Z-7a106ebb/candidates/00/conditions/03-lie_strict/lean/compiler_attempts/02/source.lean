import LeanBarrier.GeneratedCache.Context_72439cf38c014758e8ac7ec11a1596250d536a09c2c4ad76b9105b53fcfa86af

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_strict_0d60f123c165 (hV : ContDiff ℝ 1 barrier_0d60f123c165) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_lie_strict_0d60f123c165 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hB, hL⟩
  have ha2 : 0 ≤ (x 0) ^ 2 := sq_nonneg (x 0)
  have hb2 : 0 ≤ (x 1) ^ 2 := sq_nonneg (x 1)
  have ha2le : (x 0) ^ 2 ≤ 1 := by
    nlinarith [hB, hb2]
  have hablow : (-1 : ℝ) / 2 ≤ (x 0) * (x 1) := by
    nlinarith [hB, sq_nonneg (x 0 + x 1)]
  have hcross : (-1 : ℝ) / 2 ≤ (x 0) ^ 3 * (x 1) := by
    by_cases hab : 0 ≤ (x 0) * (x 1)
    · have hm := mul_nonneg ha2 hab
      nlinarith [hm]
    · have hab' : (x 0) * (x 1) ≤ 0 := le_of_lt (lt_of_not_ge hab)
      have hdiff : 0 ≤ 1 - (x 0) ^ 2 := sub_nonneg.mpr ha2le
      have hneg : 0 ≤ -((x 0) * (x 1)) := neg_nonneg.mpr hab'
      have hm := mul_nonneg hdiff hneg
      nlinarith [hm, hablow]
  have hcos : 0 ≤ Real.cos (x 0) + 1 := by
    have hc := Real.neg_one_le_cos (x 0)
    linarith
  have hq : 0 ≤ (Real.cos (x 0) + 1) * (x 1) ^ 2 :=
    mul_nonneg hcos hb2
  ring_nf at hL
  nlinarith [hB, hcross, hq]

#print axioms verify_lie_strict_0d60f123c165

end LeanBarrier.Generated
