import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: fbcdeee39b279ab21be4056907e6f93e9eee365d46c6592be897f11292132bf5
noncomputable def barrier_fbcdeee39b27 (x : LeanBarrier.State 2) : ℝ := ((x 0 ^ 2) + (((1 : ℝ) / (1000 : ℝ)) * (((((23286329 : ℝ) / (1000000 : ℝ)) * x 0) + (((105411 : ℝ) / (20000 : ℝ)) * x 1)) ^ 2)))
@[simp] theorem barrier_unfold_fbcdeee39b27 (x : LeanBarrier.State 2) : barrier_fbcdeee39b27 x = ((x 0 ^ 2) + (((1 : ℝ) / (1000 : ℝ)) * (((((23286329 : ℝ) / (1000000 : ℝ)) * x 0) + (((105411 : ℝ) / (20000 : ℝ)) * x 1)) ^ 2))) := by
  rfl
def violationSet_lie_negative_fbcdeee39b27 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-4 : ℝ)) ∧ (x 0 ≤ (4 : ℝ)) ∧ (x 1 ≥ (-4 : ℝ)) ∧ (x 1 ≤ (4 : ℝ)) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) ≤ (16 : ℝ)) ∧ (((x 0 ^ 2) + (((1 : ℝ) / (1000 : ℝ)) * (((((23286329 : ℝ) / (1000000 : ℝ)) * x 0) + (((105411 : ℝ) / (20000 : ℝ)) * x 1)) ^ 2))) ≤ ((1 : ℝ) / (1000 : ℝ))) ∧ (((x 0 ^ 2) + (x 1 ^ 2)) > (0 : ℝ)) ∧ ((((((2 : ℝ) * x 0) + (((23286329 : ℝ) / (500000000 : ℝ)) * ((((23286329 : ℝ) / (1000000 : ℝ)) * x 0) + (((105411 : ℝ) / (20000 : ℝ)) * x 1)))) * x 1) + (((35137 : ℝ) / (125000 : ℝ)) * ((((23286329 : ℝ) / (1000000 : ℝ)) * x 0) + (((105411 : ℝ) / (20000 : ℝ)) * x 1)) * (((((2943 : ℝ) / (4000 : ℝ)) * Real.sin (x 0)) + ((20 : ℝ) * Real.tanh (((((-23286329 : ℝ) / (1000000 : ℝ)) * x 0) - (((105411 : ℝ) / (20000 : ℝ)) * x 1))))) - (((1 : ℝ) / (10 : ℝ)) * x 1)))) ≥ (0 : ℝ)))}

#print axioms barrier_unfold_fbcdeee39b27

end LeanBarrier.Generated
