import LeanBarrier

#check Real.exp_neg
