import LeanBarrier.GeneratedCache.Context_dd53b0ec1d248b3b58fd4e803c5bd933710ea9ee6ef9d429f04f04a2e731dadd

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem tanh_mul_self_ge_half_sq_46596114e3c1 (x : ℝ)
    (hx : |x| ≤ (1 : ℝ) / 10) :
    x * Real.tanh x ≥ x ^ 2 / 2 := by
  have hpos : ∀ y : ℝ, 0 ≤ y → y ≤ (1 : ℝ) / 10 →
      y * Real.tanh y ≥ y ^ 2 / 2 := by
    intro y hy hyb
    let z : ℝ := Real.exp y
    have hz : 0 < z := by
      dsimp [z]
      exact Real.exp_pos y
    have hzlb : 1 + y ≤ z := by
      dsimp [z]
      linarith [Real.add_one_le_exp y]
    have hsq : (1 + y) ^ 2 ≤ z ^ 2 := by
      have hsum : 0 ≤ z + (1 + y) := by linarith
      have hm := mul_nonneg (sub_nonneg.mpr hzlb) hsum
      nlinarith
    have hcoef : 0 ≤ 1 - y / 2 := by linarith
    have hm := mul_nonneg hcoef (sub_nonneg.mpr hsq)
    have hy1 : y ≤ 1 := by linarith
    have hyquad := mul_nonneg hy (sub_nonneg.mpr hy1)
    have hfac : 0 ≤ 1 - y ^ 2 / 2 := by nlinarith
    have hbase := mul_nonneg hy hfac
    have htarget : (y / 2) * (z ^ 2 + 1) ≤ z ^ 2 - 1 := by
      nlinarith [hm, hbase]
    have hden : 0 < z ^ 2 + 1 := by positivity
    have hratio : y / 2 ≤ (z ^ 2 - 1) / (z ^ 2 + 1) := by
      exact (le_div_iff₀ hden).2 htarget
    have he0 : Real.exp y ≠ 0 := ne_of_gt (Real.exp_pos y)
    have htanh : Real.tanh y = (z ^ 2 - 1) / (z ^ 2 + 1) := by
      rw [Real.tanh_eq_sinh_div_cosh, Real.sinh_eq, Real.cosh_eq,
        Real.exp_neg]
      dsimp [z]
      field_simp [he0]
      <;> ring
    rw [htanh]
    have hmul := mul_le_mul_of_nonneg_left hratio hy
    nlinarith
  by_cases hsign : 0 ≤ x
  · have hxb : x ≤ (1 : ℝ) / 10 := le_trans (le_abs_self x) hx
    exact hpos x hsign hxb
  · have hneg : x < 0 := lt_of_not_ge hsign
    have hxb : -x ≤ (1 : ℝ) / 10 := by
      simpa [abs_of_neg hneg] using hx
    have hp := hpos (-x) (by linarith) hxb
    rw [Real.tanh_neg] at hp
    nlinarith

#print axioms tanh_mul_self_ge_half_sq_46596114e3c1

end LeanBarrier.Generated
