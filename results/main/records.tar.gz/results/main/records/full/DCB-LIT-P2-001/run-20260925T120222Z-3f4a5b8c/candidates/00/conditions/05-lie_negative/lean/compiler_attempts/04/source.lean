import LeanBarrier.GeneratedCache.Context_14147697d3972904df5b8fc0a78366a2088c43e76aa3c43b087b08c1b6e25bce

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem tanh_mul_self_lower_half_fbcdeee39b27 (z : ℝ) (hz : |z| ≤ 1) :
    z ^ 2 / 2 ≤ z * Real.tanh z := by
  have hpos : ∀ t : ℝ, 0 ≤ t → t ≤ 1 → t / 2 ≤ Real.tanh t := by
    intro t ht0 ht1
    have hexplower : 1 + 2 * t ≤ Real.exp (2 * t) := by
      simpa [add_comm] using Real.add_one_le_exp (2 * t)
    have hfac : 0 ≤ 2 - t := by linarith
    have hmul := mul_le_mul_of_nonneg_left hexplower hfac
    have hmain : 2 + t ≤ (2 - t) * Real.exp (2 * t) := by
      nlinarith
    have hexp : Real.exp (2 * t) * Real.exp (-t) = Real.exp t := by
      rw [← Real.exp_add]
      congr 1
      ring
    have hlin : (2 + t) * Real.exp (-t) ≤ (2 - t) * Real.exp t := by
      calc
        (2 + t) * Real.exp (-t) ≤ ((2 - t) * Real.exp (2 * t)) * Real.exp (-t) :=
          mul_le_mul_of_nonneg_right hmain (le_of_lt (Real.exp_pos (-t)))
        _ = (2 - t) * Real.exp t := by rw [mul_assoc, hexp]
    have hcross : t * (Real.exp t + Real.exp (-t)) ≤
        2 * (Real.exp t - Real.exp (-t)) := by
      nlinarith
    have hsum : 0 < Real.exp t + Real.exp (-t) :=
      add_pos (Real.exp_pos t) (Real.exp_pos (-t))
    have htanh : Real.tanh t =
        (Real.exp t - Real.exp (-t)) / (Real.exp t + Real.exp (-t)) := by
      rw [Real.tanh_eq_sinh_div_cosh]
      simp only [Real.sinh, Real.cosh]
      field_simp [ne_of_gt hsum]
    rw [htanh]
    apply (le_div_iff₀ hsum).2
    nlinarith
  by_cases hz0 : 0 ≤ z
  · have hz1 : z ≤ 1 := (abs_le.mp hz).2
    have ht := hpos z hz0 hz1
    have hm := mul_nonneg hz0 (sub_nonneg.mpr ht)
    nlinarith
  · have hzle : z ≤ 0 := le_of_not_ge hz0
    have hn0 : 0 ≤ -z := by linarith
    have hn1 : -z ≤ 1 := by
      have := (abs_le.mp hz).1
      linarith
    have ht := hpos (-z) hn0 hn1
    rw [Real.tanh_neg] at ht
    have hdiff : Real.tanh z - z / 2 ≤ 0 := by linarith
    have hm := mul_nonneg_of_nonpos_of_nonpos hzle hdiff
    nlinarith

#print axioms tanh_mul_self_lower_half_fbcdeee39b27

end LeanBarrier.Generated
