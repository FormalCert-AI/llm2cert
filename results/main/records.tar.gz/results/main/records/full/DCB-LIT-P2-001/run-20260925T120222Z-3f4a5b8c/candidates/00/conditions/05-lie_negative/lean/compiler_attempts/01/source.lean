import LeanBarrier

#check Real.tanh
#check Real.exp
#check Real.add_one_le_exp
#check Real.exp_add
#check Real.exp_pos
#check Real.tanh_neg
#check Real.sin
#check Real.abs_sin_le_abs
