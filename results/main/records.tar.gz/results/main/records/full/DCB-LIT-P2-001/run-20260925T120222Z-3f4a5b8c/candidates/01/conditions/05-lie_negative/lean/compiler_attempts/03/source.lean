import LeanBarrier

#check Real.sinh_eq
#check Real.cosh_eq
