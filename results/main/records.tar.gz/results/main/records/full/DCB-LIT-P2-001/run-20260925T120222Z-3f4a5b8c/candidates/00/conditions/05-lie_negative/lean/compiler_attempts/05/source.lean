import LeanBarrier

#check Real.sinh_eq_exp_sub
#check Real.cosh_eq_exp_add
