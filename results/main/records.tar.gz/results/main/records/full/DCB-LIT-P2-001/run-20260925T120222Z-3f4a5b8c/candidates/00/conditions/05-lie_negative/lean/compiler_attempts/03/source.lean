import LeanBarrier

#check Real.tanh_eq_sinh_div_cosh
#check Real.sinh
#check Real.cosh
