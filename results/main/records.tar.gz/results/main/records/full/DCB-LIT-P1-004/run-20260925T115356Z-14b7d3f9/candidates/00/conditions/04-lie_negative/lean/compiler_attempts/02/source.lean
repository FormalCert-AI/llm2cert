import LeanBarrier.GeneratedCache.Context_cc4b9c5ba1e483b9753ecba4f668c57eb86afe24f25c0ca0ea9b504532968779

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_e0ef31861d71 (hV : ContDiff ℝ 1 barrier_e0ef31861d71) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_e0ef31861d71 := by
  rintro ⟨x, hx⟩
  rcases hx with
    ⟨ha, ha10, hb, hb10, hc, hc10, hball, ha', hb', hc', hpos, hderiv⟩
  have hE : 0 < Real.exp ((2 : ℝ) * x 0) := Real.exp_pos _
  have hEnonneg : 0 ≤ Real.exp ((2 : ℝ) * x 0) := le_of_lt hE
  have hbminus : x 1 - 10 ≤ 0 := by
    linarith
  have hab2 : 0 ≤ x 0 * (x 1) ^ 2 :=
    mul_nonneg ha (sq_nonneg (x 1))
  have hterm : x 0 * (x 1) ^ 2 * (x 1 - 10) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos hab2 hbminus
  have hweighted :
      Real.exp ((2 : ℝ) * x 0) * (x 0 * (x 1) ^ 2 * (x 1 - 10)) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos hEnonneg hterm
  have hbc : 0 ≤ x 1 * x 2 := mul_nonneg hb hc
  have hEbc :
      0 ≤ Real.exp ((2 : ℝ) * x 0) * (x 1 * x 2) :=
    mul_nonneg hEnonneg hbc
  have hac2 : 0 ≤ x 0 * (x 2) ^ 2 :=
    mul_nonneg ha (sq_nonneg (x 2))
  have hEac2 :
      0 ≤ Real.exp ((2 : ℝ) * x 0) * (x 0 * (x 2) ^ 2) :=
    mul_nonneg hEnonneg hac2
  have hmain :
      2 * (x 0) ^ 2 +
          4 * Real.exp ((2 : ℝ) * x 0) * (x 1) ^ 2 +
          2 * Real.exp ((2 : ℝ) * x 0) * (x 2) ^ 2 ≤ 0 := by
    nlinarith [hderiv, hweighted, hEbc, hEac2]
  have hEb : 0 ≤ Real.exp ((2 : ℝ) * x 0) * (x 1) ^ 2 :=
    mul_nonneg hEnonneg (sq_nonneg (x 1))
  have hEc : 0 ≤ Real.exp ((2 : ℝ) * x 0) * (x 2) ^ 2 :=
    mul_nonneg hEnonneg (sq_nonneg (x 2))
  have ha2zero : (x 0) ^ 2 = 0 := by
    nlinarith [hmain, hEb, hEc, sq_nonneg (x 0)]
  have hEbzero : Real.exp ((2 : ℝ) * x 0) * (x 1) ^ 2 = 0 := by
    nlinarith [hmain, hEb, hEc, sq_nonneg (x 0)]
  have hEczero : Real.exp ((2 : ℝ) * x 0) * (x 2) ^ 2 = 0 := by
    nlinarith [hmain, hEb, hEc, sq_nonneg (x 0)]
  have hb2zero : (x 1) ^ 2 = 0 :=
    (mul_eq_zero.mp hEbzero).resolve_left (ne_of_gt hE)
  have hc2zero : (x 2) ^ 2 = 0 :=
    (mul_eq_zero.mp hEczero).resolve_left (ne_of_gt hE)
  nlinarith [hpos, ha2zero, hb2zero, hc2zero]

#print axioms verify_lie_negative_e0ef31861d71

end LeanBarrier.Generated
