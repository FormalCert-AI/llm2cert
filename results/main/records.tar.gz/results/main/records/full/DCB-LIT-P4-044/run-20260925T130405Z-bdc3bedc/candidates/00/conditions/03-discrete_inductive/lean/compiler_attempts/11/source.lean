import LeanBarrier.GeneratedCache.Helper_aa60504f817a74023cea9bdfbac3a6b39cd62d095973b64d9b8e8613e9489fcb

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_discrete_inductive_314fb4c8cb25 (hV : ContDiff ℝ 1 barrier_314fb4c8cb25) : ¬ ∃ x : LeanBarrier.State 3, x ∈ workingSet_314fb4c8cb25 ∧ barrier_314fb4c8cb25 x ≥ 0 ∧ barrier_314fb4c8cb25 (closedLoop_314fb4c8cb25 x) < 0 := by
  rintro ⟨x, hxw, hB, hneg⟩
  have hpos := barrier_closedLoop_pos_314fb4c8cb25 x hB
  linarith

#print axioms verify_discrete_inductive_314fb4c8cb25

end LeanBarrier.Generated
