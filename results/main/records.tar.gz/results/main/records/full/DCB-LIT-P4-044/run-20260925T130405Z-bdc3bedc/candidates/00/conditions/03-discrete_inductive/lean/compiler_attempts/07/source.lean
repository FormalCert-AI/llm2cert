import LeanBarrier.GeneratedCache.Helper_c205afbfe31970cfc088fb1aa20d4d928c9815ba330b8efaf34f87a6a9a00a2d

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem linear_energy_bound_314fb4c8cb25 (x : LeanBarrier.State 3) :
    ((73 : ℝ) / 100 * x 0) ^ 2 +
      ((89 : ℝ) / 100 * x 1) ^ 2 +
      ((16 : ℝ) / 25 * x 2) ^ 2 ≤
        ((89 : ℝ) / 100) ^ 2 * (x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2) := by
  have h0 : ((73 : ℝ) / 100 * x 0) ^ 2 ≤
      ((89 : ℝ) / 100) ^ 2 * x 0 ^ 2 := by
    nlinarith [sq_nonneg (x 0)]
  have h1 : ((89 : ℝ) / 100 * x 1) ^ 2 ≤
      ((89 : ℝ) / 100) ^ 2 * x 1 ^ 2 := by
    nlinarith
  have h2 : ((16 : ℝ) / 25 * x 2) ^ 2 ≤
      ((89 : ℝ) / 100) ^ 2 * x 2 ^ 2 := by
    nlinarith [sq_nonneg (x 2)]
  nlinarith [h0, h1, h2]

#print axioms linear_energy_bound_314fb4c8cb25

end LeanBarrier.Generated
