import LeanBarrier.GeneratedCache.Helper_e0b4652fcc59b3457743c08f24617a25c76c3d0317cef6ee09998b1f009c1479

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem tanh_sq_le_one_314fb4c8cb25 (a : ℝ) :
    (Real.tanh a) ^ 2 ≤ (1 : ℝ) := by
  have hlo : -(1 : ℝ) ≤ Real.tanh a := (Real.neg_one_lt_tanh _).le
  have hhi : Real.tanh a ≤ (1 : ℝ) := (Real.tanh_lt_one _).le
  nlinarith

#print axioms tanh_sq_le_one_314fb4c8cb25

end LeanBarrier.Generated
