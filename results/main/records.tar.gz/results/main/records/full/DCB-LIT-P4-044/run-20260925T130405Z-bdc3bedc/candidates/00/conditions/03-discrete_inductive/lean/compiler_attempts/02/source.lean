import LeanBarrier.GeneratedCache.Context_c5e66cfcb7963000496b95fb7bebe59208fe7598febe0700a8db46c997d72a74

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sin_tanh_sq_le_one_314fb4c8cb25 (a b : ℝ) :
    (Real.sin a * Real.tanh b) ^ 2 ≤ (1 : ℝ) := by
  have hslo : -(1 : ℝ) ≤ Real.sin a := Real.neg_one_le_sin _
  have hshi : Real.sin a ≤ (1 : ℝ) := Real.sin_le_one _
  have hssq : (Real.sin a) ^ 2 ≤ (1 : ℝ) := by
    nlinarith
  have htlo : -(1 : ℝ) ≤ Real.tanh b := (Real.neg_one_lt_tanh _).le
  have hthi : Real.tanh b ≤ (1 : ℝ) := (Real.tanh_lt_one _).le
  have htsq : (Real.tanh b) ^ 2 ≤ (1 : ℝ) := by
    nlinarith
  calc
    (Real.sin a * Real.tanh b) ^ 2 =
        (Real.sin a) ^ 2 * (Real.tanh b) ^ 2 := by ring
    _ ≤ (1 : ℝ) * 1 := by
      exact mul_le_mul hssq htsq (sq_nonneg _) (by norm_num)
    _ = 1 := by norm_num

#print axioms sin_tanh_sq_le_one_314fb4c8cb25

end LeanBarrier.Generated
