import LeanBarrier.GeneratedCache.Helper_c50fcd95910e3a769c8e3272d046d764efef8c3c8eb45113e1b25e18671a09d7

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem barrier_closedLoop_pos_314fb4c8cb25
    (x : LeanBarrier.State 3)
    (hB : barrier_314fb4c8cb25 x ≥ 0) :
    0 < barrier_314fb4c8cb25 (closedLoop_314fb4c8cb25 x) := by
  rw [barrier_unfold_314fb4c8cb25] at hB ⊢
  have hq : x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 ≤ (17 : ℝ) := by
    nlinarith [hB]
  have hout := closedLoop_energy_lt_314fb4c8cb25 x hq
  nlinarith [hout]

#print axioms barrier_closedLoop_pos_314fb4c8cb25

end LeanBarrier.Generated
