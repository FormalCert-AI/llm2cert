import LeanBarrier.GeneratedCache.Helper_4a9ddc956c4513ac76cbecd58e90fe08d21dde01dc4e486b1c54fc448f9b4dee

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem disturbance_energy_bound_314fb4c8cb25 (x : LeanBarrier.State 3) :
    ((13 : ℝ) / 100 * Real.sin (x 1) * Real.tanh (x 2)) ^ 2 +
      ((17 : ℝ) / 100 * Real.cos (x 0 ^ 2) * Real.exp (-(x 2 ^ 2))) ^ 2 +
      ((11 : ℝ) / 50 * Real.tanh (x 0 * x 1)) ^ 2 ≤
        (471 : ℝ) / 5000 := by
  have h0 := sin_tanh_sq_le_one_314fb4c8cb25 (x 1) (x 2)
  have h1 := cos_exp_neg_sq_le_one_314fb4c8cb25 (x 0 ^ 2) (x 2)
  have h2 := tanh_sq_le_one_314fb4c8cb25 (x 0 * x 1)
  have hd0 :
      ((13 : ℝ) / 100 * Real.sin (x 1) * Real.tanh (x 2)) ^ 2 ≤
        ((13 : ℝ) / 100) ^ 2 := by
    calc
      _ = ((13 : ℝ) / 100) ^ 2 *
          (Real.sin (x 1) * Real.tanh (x 2)) ^ 2 := by ring
      _ ≤ ((13 : ℝ) / 100) ^ 2 * 1 := by
        exact mul_le_mul_of_nonneg_left h0 (sq_nonneg _)
      _ = ((13 : ℝ) / 100) ^ 2 := by ring
  have hd1 :
      ((17 : ℝ) / 100 * Real.cos (x 0 ^ 2) * Real.exp (-(x 2 ^ 2))) ^ 2 ≤
        ((17 : ℝ) / 100) ^ 2 := by
    calc
      _ = ((17 : ℝ) / 100) ^ 2 *
          (Real.cos (x 0 ^ 2) * Real.exp (-(x 2 ^ 2))) ^ 2 := by ring
      _ ≤ ((17 : ℝ) / 100) ^ 2 * 1 := by
        exact mul_le_mul_of_nonneg_left h1 (sq_nonneg _)
      _ = ((17 : ℝ) / 100) ^ 2 := by ring
  have hd2 :
      ((11 : ℝ) / 50 * Real.tanh (x 0 * x 1)) ^ 2 ≤
        ((11 : ℝ) / 50) ^ 2 := by
    calc
      _ = ((11 : ℝ) / 50) ^ 2 * (Real.tanh (x 0 * x 1)) ^ 2 := by ring
      _ ≤ ((11 : ℝ) / 50) ^ 2 * 1 := by
        exact mul_le_mul_of_nonneg_left h2 (sq_nonneg _)
      _ = ((11 : ℝ) / 50) ^ 2 := by ring
  nlinarith [hd0, hd1, hd2]

#print axioms disturbance_energy_bound_314fb4c8cb25

end LeanBarrier.Generated
