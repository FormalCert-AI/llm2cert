import LeanBarrier.GeneratedCache.Helper_f61d7f40d67fc4a7b206281f65640508a89eb4ca457d19997f83420982e5e3d6

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem closedLoop_energy_lt_314fb4c8cb25
    (x : LeanBarrier.State 3)
    (hq : x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 ≤ (17 : ℝ)) :
    (closedLoop_314fb4c8cb25 x 0) ^ 2 +
      (closedLoop_314fb4c8cb25 x 1) ^ 2 +
      (closedLoop_314fb4c8cb25 x 2) ^ 2 < (17 : ℝ) := by
  let u0 : ℝ := (73 : ℝ) / 100 * x 0
  let u1 : ℝ := (89 : ℝ) / 100 * x 1
  let u2 : ℝ := (16 : ℝ) / 25 * x 2
  let d0 : ℝ := (13 : ℝ) / 100 * Real.sin (x 1) * Real.tanh (x 2)
  let d1 : ℝ := (17 : ℝ) / 100 * Real.cos (x 0 ^ 2) * Real.exp (-(x 2 ^ 2))
  let d2 : ℝ := (11 : ℝ) / 50 * Real.tanh (x 0 * x 1)
  have hu : u0 ^ 2 + u1 ^ 2 + u2 ^ 2 ≤
      ((89 : ℝ) / 100) ^ 2 * (x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2) := by
    simpa [u0, u1, u2] using linear_energy_bound_314fb4c8cb25 x
  have hd : d0 ^ 2 + d1 ^ 2 + d2 ^ 2 ≤ (471 : ℝ) / 5000 := by
    simpa [d0, d1, d2] using disturbance_energy_bound_314fb4c8cb25 x
  have hy := sum_sq_add_bound_314fb4c8cb25 u0 u1 u2 d0 d1 d2
  rw [closedLoop_apply_0_314fb4c8cb25,
    closedLoop_apply_1_314fb4c8cb25,
    closedLoop_apply_2_314fb4c8cb25]
  change (u0 + d0) ^ 2 + (u1 + d1) ^ 2 + (u2 + d2) ^ 2 < (17 : ℝ)
  nlinarith [hy, hu, hd, hq]

#print axioms closedLoop_energy_lt_314fb4c8cb25

end LeanBarrier.Generated
