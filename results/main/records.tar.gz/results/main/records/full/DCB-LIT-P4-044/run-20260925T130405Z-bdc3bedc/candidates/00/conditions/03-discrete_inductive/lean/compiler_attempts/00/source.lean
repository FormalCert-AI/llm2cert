import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 314fb4c8cb25a6ef41c989c1fc3d97c3661ccfedb84e4ee6a401a7d249ab071a
noncomputable def barrier_314fb4c8cb25 (x : LeanBarrier.State 3) : ℝ := ((((17 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2))
@[simp] theorem barrier_unfold_314fb4c8cb25 (x : LeanBarrier.State 3) : barrier_314fb4c8cb25 x = ((((17 : ℝ) - (x 0 ^ 2)) - (x 1 ^ 2)) - (x 2 ^ 2)) := by
  rfl
noncomputable def closedLoop_314fb4c8cb25 (x : LeanBarrier.State 3) : LeanBarrier.State 3 := ![((((73 : ℝ) / (100 : ℝ)) * x 0) + (((13 : ℝ) / (100 : ℝ)) * Real.sin (x 1) * Real.tanh (x 2))), ((((89 : ℝ) / (100 : ℝ)) * x 1) + (((17 : ℝ) / (100 : ℝ)) * Real.cos ((x 0 ^ 2)) * Real.exp ((-(x 2 ^ 2))))), ((((16 : ℝ) / (25 : ℝ)) * x 2) + (((11 : ℝ) / (50 : ℝ)) * Real.tanh ((x 0 * x 1))))]
@[simp] theorem closedLoop_apply_0_314fb4c8cb25 (x : LeanBarrier.State 3) : closedLoop_314fb4c8cb25 x 0 = ((((73 : ℝ) / (100 : ℝ)) * x 0) + (((13 : ℝ) / (100 : ℝ)) * Real.sin (x 1) * Real.tanh (x 2))) := by
  simp [closedLoop_314fb4c8cb25]
@[simp] theorem closedLoop_apply_1_314fb4c8cb25 (x : LeanBarrier.State 3) : closedLoop_314fb4c8cb25 x 1 = ((((89 : ℝ) / (100 : ℝ)) * x 1) + (((17 : ℝ) / (100 : ℝ)) * Real.cos ((x 0 ^ 2)) * Real.exp ((-(x 2 ^ 2))))) := by
  simp [closedLoop_314fb4c8cb25]
@[simp] theorem closedLoop_apply_2_314fb4c8cb25 (x : LeanBarrier.State 3) : closedLoop_314fb4c8cb25 x 2 = ((((16 : ℝ) / (25 : ℝ)) * x 2) + (((11 : ℝ) / (50 : ℝ)) * Real.tanh ((x 0 * x 1)))) := by
  simp [closedLoop_314fb4c8cb25]
def workingSet_314fb4c8cb25 : Set (LeanBarrier.State 3) := {x | True}
def unsafeSet_314fb4c8cb25 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((-77 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((-47 : ℝ) / (20 : ℝ))) ∧ (x 1 ≥ ((41 : ℝ) / (20 : ℝ))) ∧ (x 1 ≤ ((71 : ℝ) / (20 : ℝ))) ∧ (x 2 ≥ ((-67 : ℝ) / (20 : ℝ))) ∧ (x 2 ≤ ((-37 : ℝ) / (20 : ℝ))) ∧ ((((x 0 - ((-31 : ℝ) / (10 : ℝ))) ^ 2) + ((x 1 - ((14 : ℝ) / (5 : ℝ))) ^ 2) + ((x 2 - ((-13 : ℝ) / (5 : ℝ))) ^ 2)) ≤ ((9 : ℝ) / (16 : ℝ))))}
def initialSet_314fb4c8cb25 : Set (LeanBarrier.State 3) := {x | ((x 0 ≥ ((7 : ℝ) / (20 : ℝ))) ∧ (x 0 ≤ ((29 : ℝ) / (20 : ℝ))) ∧ (x 1 ≥ ((-5 : ℝ) / (4 : ℝ))) ∧ (x 1 ≤ ((-3 : ℝ) / (20 : ℝ))) ∧ (x 2 ≥ ((13 : ℝ) / (20 : ℝ))) ∧ (x 2 ≤ ((7 : ℝ) / (4 : ℝ))) ∧ ((((x 0 - ((9 : ℝ) / (10 : ℝ))) ^ 2) + ((x 1 - ((-7 : ℝ) / (10 : ℝ))) ^ 2) + ((x 2 - ((6 : ℝ) / (5 : ℝ))) ^ 2)) ≤ ((121 : ℝ) / (400 : ℝ))))}

#print axioms barrier_unfold_314fb4c8cb25

end LeanBarrier.Generated
