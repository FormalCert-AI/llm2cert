import LeanBarrier.GeneratedCache.Helper_8da96de9a1914a7851898677f12cbe5382934ca3fad2c116054415cc0c2cbec9

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem cos_exp_neg_sq_le_one_314fb4c8cb25 (a b : ℝ) :
    (Real.cos a * Real.exp (-(b ^ 2))) ^ 2 ≤ (1 : ℝ) := by
  have hclo : -(1 : ℝ) ≤ Real.cos a := Real.neg_one_le_cos _
  have hchi : Real.cos a ≤ (1 : ℝ) := Real.cos_le_one _
  have hcsq : (Real.cos a) ^ 2 ≤ (1 : ℝ) := by
    nlinarith
  have hehi : Real.exp (-(b ^ 2)) ≤ (1 : ℝ) := by
    rw [Real.exp_le_one_iff]
    nlinarith [sq_nonneg b]
  have helo : 0 ≤ Real.exp (-(b ^ 2)) := (Real.exp_pos _).le
  have hesq : (Real.exp (-(b ^ 2))) ^ 2 ≤ (1 : ℝ) := by
    nlinarith
  calc
    (Real.cos a * Real.exp (-(b ^ 2))) ^ 2 =
        (Real.cos a) ^ 2 * (Real.exp (-(b ^ 2))) ^ 2 := by ring
    _ ≤ (1 : ℝ) * 1 := by
      exact mul_le_mul hcsq hesq (sq_nonneg _) (by norm_num)
    _ = 1 := by norm_num

#print axioms cos_exp_neg_sq_le_one_314fb4c8cb25

end LeanBarrier.Generated
