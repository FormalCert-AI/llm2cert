import LeanBarrier.GeneratedCache.Helper_2ebeacb788c038f0d3b777ea7a989334844fd86eeb467754e603c4a2ec2fec0c

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem sum_sq_add_bound_314fb4c8cb25
    (u0 u1 u2 d0 d1 d2 : ℝ) :
    (u0 + d0) ^ 2 + (u1 + d1) ^ 2 + (u2 + d2) ^ 2 ≤
      (11 : ℝ) / 10 * (u0 ^ 2 + u1 ^ 2 + u2 ^ 2) +
        11 * (d0 ^ 2 + d1 ^ 2 + d2 ^ 2) := by
  have h0 : (u0 + d0) ^ 2 ≤
      (11 : ℝ) / 10 * u0 ^ 2 + 11 * d0 ^ 2 := by
    nlinarith [sq_nonneg (u0 - 10 * d0)]
  have h1 : (u1 + d1) ^ 2 ≤
      (11 : ℝ) / 10 * u1 ^ 2 + 11 * d1 ^ 2 := by
    nlinarith [sq_nonneg (u1 - 10 * d1)]
  have h2 : (u2 + d2) ^ 2 ≤
      (11 : ℝ) / 10 * u2 ^ 2 + 11 * d2 ^ 2 := by
    nlinarith [sq_nonneg (u2 - 10 * d2)]
  nlinarith [h0, h1, h2]

#print axioms sum_sq_add_bound_314fb4c8cb25

end LeanBarrier.Generated
