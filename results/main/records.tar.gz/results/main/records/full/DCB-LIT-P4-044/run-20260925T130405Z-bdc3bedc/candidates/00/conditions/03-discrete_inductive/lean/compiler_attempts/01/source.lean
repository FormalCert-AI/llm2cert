import LeanBarrier

#check Real.sin
#check Real.tanh
#check Real.neg_one_le_sin
#check Real.sin_le_one
#check Real.neg_one_lt_tanh
#check Real.tanh_lt_one
#check Real.cos
#check Real.exp
#check Real.neg_one_le_cos
#check Real.cos_le_one
#check Real.exp_le_one_iff
#check Real.exp_pos
