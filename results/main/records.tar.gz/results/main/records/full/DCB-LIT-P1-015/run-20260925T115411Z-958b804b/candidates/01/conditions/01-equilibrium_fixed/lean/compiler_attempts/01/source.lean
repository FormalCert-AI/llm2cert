import LeanBarrier.GeneratedCache.Context_e9d4aa51c1aadb7b23ad1585dfefb7f28eb8bf754620729aaff97212fa8e58f0

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_equilibrium_fixed_af420dcfc775 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_equilibrium_fixed_af420dcfc775, Set.mem_setOf_eq] at hx
  rcases hx with ⟨hq, hw1, hw2, hbad⟩
  norm_num [hq, hw1, hw2] at hbad

#print axioms verify_equilibrium_fixed_af420dcfc775

end LeanBarrier.Generated
