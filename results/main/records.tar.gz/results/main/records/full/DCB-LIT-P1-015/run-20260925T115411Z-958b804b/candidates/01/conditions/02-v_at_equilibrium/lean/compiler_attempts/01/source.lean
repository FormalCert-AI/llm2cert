import LeanBarrier.GeneratedCache.Context_c10c68b0da89e689e16be8de19d9934cee81a21a4cde9b9073014eeb179918e0

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_v_at_equilibrium_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_v_at_equilibrium_af420dcfc775 := by
  rintro ⟨x, hx⟩
  simp only [violationSet_v_at_equilibrium_af420dcfc775, Set.mem_setOf_eq] at hx
  rcases hx with ⟨h0, h1, h2, h⟩
  rcases h with h | h
  · norm_num [h0, h1, h2] at h
  · norm_num [h0, h1, h2] at h

#print axioms verify_v_at_equilibrium_af420dcfc775

end LeanBarrier.Generated
