import LeanBarrier

#check Real.cos
#check Real.pi
#check Real.pi_gt_three
#check Real.cos_pos_of_mem_Ioo
#check Real.cos_le_one
#check Real.sin
#check Real.sin_pos_of_pos_of_lt_pi
#check Real.sin_neg
#check Real.sin_le
#check Real.sin_sq_add_cos_sq
