import LeanBarrier.GeneratedCache.Context_d68b1b0a4ab129c046d839a84080358b69da3ca92587331f910bb06f24cfc157

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_lie_negative_af420dcfc775 (hV : ContDiff ℝ 1 barrier_af420dcfc775) : ¬ ∃ x : LeanBarrier.State 3, x ∈ violationSet_lie_negative_af420dcfc775 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hqlo, hqhi, _, _, _, _, hnorm, hD⟩
  let q : ℝ := x 0
  let a : ℝ := x 1 - x 2
  let s : ℝ := x 1 + x 2
  let h : ℝ := 1 - Real.cos q
  have hqlo' : -(3 : ℝ) / 2 ≤ q := by
    simpa [q] using hqlo
  have hqhi' : q ≤ (3 : ℝ) / 2 := by
    simpa [q] using hqhi
  have hpi3 : (3 : ℝ) < Real.pi := Real.pi_gt_three
  have hqmem : q ∈ Set.Ioo (-(Real.pi / 2)) (Real.pi / 2) := by
    constructor <;> nlinarith
  have hcpos : 0 < Real.cos q := Real.cos_pos_of_mem_Ioo hqmem
  have hcosle : Real.cos q ≤ 1 := Real.cos_le_one q
  have hqsin_pos : q ≠ 0 → 0 < q * Real.sin q := by
    intro hn
    rcases lt_or_gt_of_ne hn with hneg | hpos
    · have hrpos : 0 < -q := by linarith
      have hrpi : -q < Real.pi := by nlinarith
      have hspos : 0 < Real.sin (-q) :=
        Real.sin_pos_of_pos_of_lt_pi hrpos hrpi
      have hp : 0 < (-q) * Real.sin (-q) := mul_pos hrpos hspos
      calc
        0 < (-q) * Real.sin (-q) := hp
        _ = q * Real.sin q := by rw [Real.sin_neg]; ring
    · have hqpi : q < Real.pi := by nlinarith
      exact mul_pos hpos (Real.sin_pos_of_pos_of_lt_pi hpos hqpi)
  have hqsin_nonneg : 0 ≤ q * Real.sin q := by
    by_cases hn : q = 0
    · simp [hn]
    · exact le_of_lt (hqsin_pos hn)
  have hsin_sq_le : (Real.sin q) ^ 2 ≤ q * Real.sin q := by
    by_cases hqzero : q = 0
    · simp [hqzero]
    · rcases lt_or_gt_of_ne hqzero with hneg | hpos
      · have hrpos : 0 < -q := by linarith
        have hrpi : -q < Real.pi := by nlinarith
        have hspos : 0 < Real.sin (-q) :=
          Real.sin_pos_of_pos_of_lt_pi hrpos hrpi
        have hsle : Real.sin (-q) ≤ -q := Real.sin_le (le_of_lt hrpos)
        simp only [Real.sin_neg] at hspos hsle
        have horder : q ≤ Real.sin q := by linarith
        have hsnonpos : Real.sin q ≤ 0 := by linarith
        have hmul := mul_le_mul_of_nonpos_right horder hsnonpos
        nlinarith [hmul]
      · have hqpi : q < Real.pi := by nlinarith
        have hspos : 0 < Real.sin q :=
          Real.sin_pos_of_pos_of_lt_pi hpos hqpi
        have hsle : Real.sin q ≤ q := Real.sin_le (le_of_lt hpos)
        have hmul := mul_le_mul_of_nonneg_left hsle (le_of_lt hspos)
        nlinarith [hmul]
  have hh_sin : h ^ 2 ≤ (Real.sin q) ^ 2 := by
    have hc0 : 0 ≤ Real.cos q := le_of_lt hcpos
    have h1c : 0 ≤ 1 - Real.cos q := sub_nonneg.mpr hcosle
    have hprod : 0 ≤ Real.cos q * (1 - Real.cos q) := mul_nonneg hc0 h1c
    have htrig := Real.sin_sq_add_cos_sq q
    dsimp [h]
    nlinarith
  have hhq : h ^ 2 ≤ q * Real.sin q := le_trans hh_sin hsin_sq_le
  have hD' :
      -(1 / 2 : ℝ) * a ^ 2
        - (1 / 2 : ℝ) * q * Real.sin q
        - (1 / 2 : ℝ) * s ^ 2
        - (1 / 2 : ℝ) * s * h ≥ 0 := by
    dsimp [q, a, s, h]
    ring_nf at hD ⊢
    exact hD
  have hyoung :
      -(1 / 2 : ℝ) * s ^ 2
          - (1 / 2 : ℝ) * s * h
          - (1 / 2 : ℝ) * (q * Real.sin q)
        ≤ -(1 / 4 : ℝ) * s ^ 2
          - (1 / 4 : ℝ) * (q * Real.sin q) := by
    nlinarith [sq_nonneg (s + h), hhq]
  have hbound :
      0 ≤ -(1 / 2 : ℝ) * a ^ 2
        - (1 / 4 : ℝ) * s ^ 2
        - (1 / 4 : ℝ) * (q * Real.sin q) := by
    nlinarith [hD', hyoung]
  have ha0 : a = 0 := by
    nlinarith [sq_nonneg a, sq_nonneg s, hqsin_nonneg]
  have hs0 : s = 0 := by
    nlinarith [sq_nonneg a, sq_nonneg s, hqsin_nonneg]
  have hq0 : q = 0 := by
    by_contra hn
    have hp := hqsin_pos hn
    nlinarith [sq_nonneg a, sq_nonneg s]
  dsimp [q] at hq0
  dsimp [a] at ha0
  dsimp [s] at hs0
  nlinarith

#print axioms verify_lie_negative_af420dcfc775

end LeanBarrier.Generated
