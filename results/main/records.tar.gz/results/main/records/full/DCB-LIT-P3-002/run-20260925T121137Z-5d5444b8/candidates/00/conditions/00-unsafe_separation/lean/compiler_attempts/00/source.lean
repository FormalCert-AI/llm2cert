import LeanBarrier

open scoped BigOperators

namespace LeanBarrier.Generated

-- candidate-sha256: 8fbe56e92cb373a314e652862be92c1c92dcfc32954c99d130aa2af8acb13656
noncomputable def barrier_8fbe56e92cb3 (x : LeanBarrier.State 2) : ℝ := ((((1999999 : ℝ) / (4000000 : ℝ)) * (Real.pi ^ 2)) - ((((((3 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + Real.cos (x 0)) - (1 : ℝ)) + (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((1 : ℝ) / (1000 : ℝ)) * x 0 * x 1)))
@[simp] theorem barrier_unfold_8fbe56e92cb3 (x : LeanBarrier.State 2) : barrier_8fbe56e92cb3 x = ((((1999999 : ℝ) / (4000000 : ℝ)) * (Real.pi ^ 2)) - ((((((3 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + Real.cos (x 0)) - (1 : ℝ)) + (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((1 : ℝ) / (1000 : ℝ)) * x 0 * x 1))) := by
  rfl
def violationSet_unsafe_separation_8fbe56e92cb3 : Set (LeanBarrier.State 2) := {x | ((x 0 ≥ (-4 : ℝ)) ∧ (x 0 ≤ (4 : ℝ)) ∧ (x 1 ≥ (-4 : ℝ)) ∧ (x 1 ≤ (4 : ℝ)) ∧ (((((1999999 : ℝ) / (4000000 : ℝ)) * (Real.pi ^ 2)) - ((((((3 : ℝ) / (2 : ℝ)) * (x 0 ^ 2)) + Real.cos (x 0)) - (1 : ℝ)) + (((1 : ℝ) / (2 : ℝ)) * (x 1 ^ 2)) + (((1 : ℝ) / (1000 : ℝ)) * x 0 * x 1))) ≥ (0 : ℝ)) ∧ (((x 0 < (-Real.pi))) ∨ ((x 0 > Real.pi)) ∨ ((x 1 < (-Real.pi))) ∨ ((x 1 > Real.pi))))}
def unsafeSet_8fbe56e92cb3 : Set (LeanBarrier.State 2) := {x | ((((x 0 < (-Real.pi))) ∨ ((x 0 > Real.pi)) ∨ ((x 1 < (-Real.pi))) ∨ ((x 1 > Real.pi))))}

#print axioms barrier_unfold_8fbe56e92cb3

end LeanBarrier.Generated
