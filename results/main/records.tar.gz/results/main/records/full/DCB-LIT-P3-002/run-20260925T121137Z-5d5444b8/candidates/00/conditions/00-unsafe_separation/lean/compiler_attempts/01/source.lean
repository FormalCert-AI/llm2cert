import LeanBarrier

#check Real.pi
#check Real.cos
#check Real.one_sub_sq_div_two_le_cos
#check Real.pi_pos
