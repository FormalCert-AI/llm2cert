import LeanBarrier.GeneratedCache.Context_581a2f73dcd44637c9cf25d6a78e83d0d35b0db03229e9c6c4c14dbf1372f2c2

open scoped BigOperators

namespace LeanBarrier.Generated

set_option maxHeartbeats 1000000 in
theorem verify_equilibrium_fixed_764d2fbfe832 (hV : ContDiff ℝ 1 barrier_764d2fbfe832) : ¬ ∃ x : LeanBarrier.State 2, x ∈ violationSet_equilibrium_fixed_764d2fbfe832 := by
  rintro ⟨x, hx⟩
  rcases hx with ⟨hx0, hx1, hbad⟩
  norm_num [hx0, hx1] at hbad

#print axioms verify_equilibrium_fixed_764d2fbfe832

end LeanBarrier.Generated
